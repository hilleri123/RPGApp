--
-- PostgreSQL database dump
--

\restrict e5Fvrhllsog5z4zcdbV8Tzc95hHfNFNxGbZNJoJouEtyuDJinI8p0mYLhGOhPmy

-- Dumped from database version 15.12 (Debian 15.12-1.pgdg120+1)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: common; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA common;


ALTER SCHEMA common OWNER TO postgres;

--
-- Name: rule; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA rule;


ALTER SCHEMA rule OWNER TO postgres;

--
-- Name: scenario; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA scenario;


ALTER SCHEMA scenario OWNER TO postgres;

--
-- Name: entitytypeenum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.entitytypeenum AS ENUM (
    'location',
    'character',
    'npc',
    'item',
    'note'
);


ALTER TYPE public.entitytypeenum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: on_use_item; Type: TABLE; Schema: common; Owner: postgres
--

CREATE TABLE common.on_use_item (
    id uuid NOT NULL,
    name character varying,
    item_scheme_id uuid,
    item_id uuid,
    var_limits json,
    formula_id uuid,
    fixed_vars json
);


ALTER TABLE common.on_use_item OWNER TO postgres;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: game_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.game_session (
    id uuid NOT NULL,
    name character varying,
    description character varying,
    scenario_id uuid,
    master_id uuid,
    created_at timestamp with time zone,
    is_active boolean
);


ALTER TABLE public.game_session OWNER TO postgres;

--
-- Name: master_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.master_group (
    id uuid NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.master_group OWNER TO postgres;

--
-- Name: master_group_rule_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.master_group_rule_access (
    master_group_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    permission character varying NOT NULL
);


ALTER TABLE public.master_group_rule_access OWNER TO postgres;

--
-- Name: master_group_scenario_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.master_group_scenario_access (
    master_group_id uuid NOT NULL,
    scenario_id uuid NOT NULL,
    permission character varying NOT NULL
);


ALTER TABLE public.master_group_scenario_access OWNER TO postgres;

--
-- Name: player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player (
    id uuid NOT NULL,
    name character varying,
    color character varying,
    icon_url character varying(256),
    img_url character varying(256),
    user_id uuid,
    game_session_id uuid,
    character_id uuid
);


ALTER TABLE public.player OWNER TO postgres;

--
-- Name: player_action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player_action (
    id uuid NOT NULL,
    description_for_master character varying,
    description_for_players character varying,
    add_time_secs integer,
    triggers_note_id uuid,
    icon_url character varying(256),
    img_url character varying(256),
    location_id uuid,
    npc_id uuid,
    item_scheme_id uuid,
    item_id uuid,
    CONSTRAINT only_one_fk_not_null CHECK (((((
CASE
    WHEN (location_id IS NOT NULL) THEN 1
    ELSE 0
END +
CASE
    WHEN (npc_id IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (item_scheme_id IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (item_id IS NOT NULL) THEN 1
    ELSE 0
END) = 1))
);


ALTER TABLE public.player_action OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id uuid NOT NULL,
    email character varying,
    tg character varying,
    can_be_master boolean,
    full_name character varying,
    hashed_password character varying,
    is_active boolean,
    icon_url character varying(256),
    img_url character varying(256),
    telegram_id bigint,
    is_admin boolean
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_master_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_master_group (
    user_id uuid NOT NULL,
    master_group_id uuid NOT NULL,
    permission character varying NOT NULL
);


ALTER TABLE public.user_master_group OWNER TO postgres;

--
-- Name: rule_character_template; Type: TABLE; Schema: rule; Owner: postgres
--

CREATE TABLE rule.rule_character_template (
    id uuid NOT NULL,
    template_set_id uuid NOT NULL,
    name character varying NOT NULL,
    short_desc character varying,
    story character varying,
    data json,
    icon_url character varying(256),
    img_url character varying(256)
);


ALTER TABLE rule.rule_character_template OWNER TO postgres;

--
-- Name: rule_item_contained_template; Type: TABLE; Schema: rule; Owner: postgres
--

CREATE TABLE rule.rule_item_contained_template (
    id uuid NOT NULL,
    owner_item_template_id uuid NOT NULL,
    item_template_id uuid NOT NULL,
    qty integer NOT NULL
);


ALTER TABLE rule.rule_item_contained_template OWNER TO postgres;

--
-- Name: rule_item_ownership_template; Type: TABLE; Schema: rule; Owner: postgres
--

CREATE TABLE rule.rule_item_ownership_template (
    id uuid NOT NULL,
    character_template_id uuid,
    npc_template_id uuid,
    item_template_id uuid NOT NULL,
    qty integer NOT NULL,
    CONSTRAINT ck_rule_item_owner_exactly_one CHECK (((((character_template_id IS NOT NULL))::integer + ((npc_template_id IS NOT NULL))::integer) = 1))
);


ALTER TABLE rule.rule_item_ownership_template OWNER TO postgres;

--
-- Name: rule_item_template; Type: TABLE; Schema: rule; Owner: postgres
--

CREATE TABLE rule.rule_item_template (
    id uuid NOT NULL,
    template_set_id uuid NOT NULL,
    name character varying NOT NULL,
    description_for_master character varying,
    description_for_players character varying,
    icon_url character varying(256),
    img_url character varying(256),
    data json,
    quest_html_mark text
);


ALTER TABLE rule.rule_item_template OWNER TO postgres;

--
-- Name: rule_npc_template; Type: TABLE; Schema: rule; Owner: postgres
--

CREATE TABLE rule.rule_npc_template (
    id uuid NOT NULL,
    template_set_id uuid NOT NULL,
    name character varying NOT NULL,
    description_for_master character varying,
    description_for_players character varying,
    data json,
    icon_url character varying(256),
    img_url character varying(256)
);


ALTER TABLE rule.rule_npc_template OWNER TO postgres;

--
-- Name: rule_template_set; Type: TABLE; Schema: rule; Owner: postgres
--

CREATE TABLE rule.rule_template_set (
    id uuid NOT NULL,
    rule_id_str character varying NOT NULL,
    scenario_id uuid,
    name character varying NOT NULL
);


ALTER TABLE rule.rule_template_set OWNER TO postgres;

--
-- Name: scenario_template_set_link; Type: TABLE; Schema: rule; Owner: postgres
--

CREATE TABLE rule.scenario_template_set_link (
    id uuid NOT NULL,
    scenario_id uuid NOT NULL,
    template_set_id uuid NOT NULL,
    enabled boolean NOT NULL,
    order_num integer NOT NULL
);


ALTER TABLE rule.scenario_template_set_link OWNER TO postgres;

--
-- Name: tag; Type: TABLE; Schema: rule; Owner: postgres
--

CREATE TABLE rule.tag (
    id uuid NOT NULL,
    code character varying NOT NULL,
    entity_type public.entitytypeenum NOT NULL,
    title character varying NOT NULL,
    color character varying,
    description character varying,
    meta json
);


ALTER TABLE rule.tag OWNER TO postgres;

--
-- Name: character_tag; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.character_tag (
    character_id uuid NOT NULL,
    tag_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE scenario.character_tag OWNER TO postgres;

--
-- Name: counter; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.counter (
    id uuid NOT NULL,
    name character varying NOT NULL,
    description character varying,
    value integer NOT NULL,
    min_value integer,
    max_value integer,
    scenario_id uuid NOT NULL,
    character_id uuid
);


ALTER TABLE scenario.counter OWNER TO postgres;

--
-- Name: game_item; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.game_item (
    id uuid NOT NULL,
    name character varying NOT NULL,
    description_for_master character varying,
    description_for_players character varying,
    erase_on_use boolean,
    is_shown boolean,
    icon_url character varying(256),
    img_url character varying(256),
    item_scheme_id uuid,
    scenario_id uuid,
    npc_id uuid,
    location_id uuid,
    character_id uuid,
    data json,
    quest_html_mark text
);


ALTER TABLE scenario.game_item OWNER TO postgres;

--
-- Name: game_time_event; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.game_time_event (
    id uuid NOT NULL,
    name character varying NOT NULL,
    text character varying,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    icon_url character varying(256),
    img_url character varying(256),
    note_id uuid,
    scenario_id uuid
);


ALTER TABLE scenario.game_time_event OWNER TO postgres;

--
-- Name: item_ownership; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.item_ownership (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    character_id uuid,
    npc_id uuid,
    owner_item_id uuid,
    qty integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_item_ownership_exactly_one_owner CHECK ((((((character_id IS NOT NULL))::integer + ((npc_id IS NOT NULL))::integer) + ((owner_item_id IS NOT NULL))::integer) = 1))
);


ALTER TABLE scenario.item_ownership OWNER TO postgres;

--
-- Name: item_tag; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.item_tag (
    item_id uuid NOT NULL,
    tag_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE scenario.item_tag OWNER TO postgres;

--
-- Name: location; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.location (
    id uuid NOT NULL,
    name character varying NOT NULL,
    description_for_master character varying,
    description_for_players character varying,
    is_shown boolean,
    is_start boolean,
    icon_url character varying(256),
    map_url character varying(256),
    parent_location_id uuid,
    scenario_id uuid,
    data json
);


ALTER TABLE scenario.location OWNER TO postgres;

--
-- Name: location_tag; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.location_tag (
    location_id uuid NOT NULL,
    tag_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE scenario.location_tag OWNER TO postgres;

--
-- Name: map_object_polygon; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.map_object_polygon (
    id uuid NOT NULL,
    name character varying NOT NULL,
    source_location_id uuid,
    target_location_id uuid,
    is_shown boolean,
    is_filled boolean,
    is_line boolean,
    alpha double precision,
    color character varying,
    polygon_list json,
    icon character varying,
    icon_url character varying(256)
);


ALTER TABLE scenario.map_object_polygon OWNER TO postgres;

--
-- Name: note; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.note (
    id uuid NOT NULL,
    name character varying NOT NULL,
    text character varying,
    allowed_character_shown_json json,
    icon_url character varying(256),
    img_url character varying(256),
    scenario_id uuid
);


ALTER TABLE scenario.note OWNER TO postgres;

--
-- Name: npc; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.npc (
    id uuid NOT NULL,
    name character varying NOT NULL,
    description_for_master character varying,
    description_for_players character varying,
    is_dead boolean,
    is_enemy boolean,
    is_shown boolean,
    icon_url character varying(256),
    img_url character varying(256),
    body_id uuid,
    scenario_id uuid,
    unique_body_id uuid,
    data json
);


ALTER TABLE scenario.npc OWNER TO postgres;

--
-- Name: npc_tag; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.npc_tag (
    npc_id uuid NOT NULL,
    tag_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE scenario.npc_tag OWNER TO postgres;

--
-- Name: obstacle; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.obstacle (
    id uuid NOT NULL,
    scenario_id uuid NOT NULL,
    name character varying NOT NULL,
    description_for_master character varying,
    description_for_players character varying,
    data json
);


ALTER TABLE scenario.obstacle OWNER TO postgres;

--
-- Name: player_action; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.player_action (
    id uuid NOT NULL,
    description_for_master character varying,
    description_for_players character varying,
    add_time_secs integer,
    triggers_note_id uuid,
    icon_url character varying(256),
    img_url character varying(256),
    location_id uuid,
    npc_id uuid,
    item_scheme_id uuid,
    item_id uuid,
    action_handler_id uuid,
    CONSTRAINT only_one_fk_not_null CHECK (((((
CASE
    WHEN (location_id IS NOT NULL) THEN 1
    ELSE 0
END +
CASE
    WHEN (npc_id IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (item_scheme_id IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (item_id IS NOT NULL) THEN 1
    ELSE 0
END) = 1))
);


ALTER TABLE scenario.player_action OWNER TO postgres;

--
-- Name: player_character; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.player_character (
    id uuid NOT NULL,
    name character varying NOT NULL,
    short_desc character varying,
    story character varying,
    icon_url character varying(256),
    img_url character varying(256),
    body_id uuid,
    location_id uuid,
    scenario_id uuid,
    unique_body_id uuid,
    data json
);


ALTER TABLE scenario.player_character OWNER TO postgres;

--
-- Name: requirement; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.requirement (
    id uuid NOT NULL,
    skill_value integer,
    threshold boolean,
    skill_id uuid,
    action_id uuid NOT NULL
);


ALTER TABLE scenario.requirement OWNER TO postgres;

--
-- Name: scenario; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.scenario (
    id uuid NOT NULL,
    name character varying NOT NULL,
    intro character varying,
    max_players integer,
    created timestamp with time zone,
    icon_url character varying(256),
    user_id uuid,
    rule_id_str text,
    data json
);


ALTER TABLE scenario.scenario OWNER TO postgres;

--
-- Name: scenario_template_set_link; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.scenario_template_set_link (
    id uuid NOT NULL,
    scenario_id uuid NOT NULL,
    template_set_id uuid NOT NULL,
    enabled boolean NOT NULL,
    order_num integer NOT NULL
);


ALTER TABLE scenario.scenario_template_set_link OWNER TO postgres;

--
-- Name: scene_exposure; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.scene_exposure (
    id uuid NOT NULL,
    scenario_id uuid NOT NULL,
    name character varying NOT NULL,
    order_num integer NOT NULL,
    location_id uuid,
    story_beat_id uuid,
    CONSTRAINT scene_exposure_location_xor_story_beat CHECK (((location_id IS NULL) <> (story_beat_id IS NULL)))
);


ALTER TABLE scenario.scene_exposure OWNER TO postgres;

--
-- Name: scene_exposure_item; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.scene_exposure_item (
    scene_exposure_id uuid NOT NULL,
    item_id uuid NOT NULL
);


ALTER TABLE scenario.scene_exposure_item OWNER TO postgres;

--
-- Name: scene_exposure_npc; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.scene_exposure_npc (
    scene_exposure_id uuid NOT NULL,
    npc_id uuid NOT NULL
);


ALTER TABLE scenario.scene_exposure_npc OWNER TO postgres;

--
-- Name: scene_exposure_obstacle; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.scene_exposure_obstacle (
    scene_exposure_id uuid NOT NULL,
    obstacle_id uuid NOT NULL
);


ALTER TABLE scenario.scene_exposure_obstacle OWNER TO postgres;

--
-- Name: story_beat; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.story_beat (
    id uuid NOT NULL,
    scenario_id uuid NOT NULL,
    name character varying NOT NULL,
    order_num integer NOT NULL,
    text_for_master character varying,
    text_for_players character varying,
    show_once boolean,
    is_shown boolean,
    img_url character varying(256),
    parent_story_beat_id uuid
);


ALTER TABLE scenario.story_beat OWNER TO postgres;

--
-- Name: story_beat_location; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.story_beat_location (
    story_beat_id uuid NOT NULL,
    location_id uuid NOT NULL
);


ALTER TABLE scenario.story_beat_location OWNER TO postgres;

--
-- Name: story_beat_npc; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.story_beat_npc (
    story_beat_id uuid NOT NULL,
    npc_id uuid NOT NULL
);


ALTER TABLE scenario.story_beat_npc OWNER TO postgres;

--
-- Name: unique_body; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.unique_body (
    id uuid NOT NULL,
    name character varying NOT NULL,
    scenario_id uuid
);


ALTER TABLE scenario.unique_body OWNER TO postgres;

--
-- Name: unique_stat; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.unique_stat (
    id uuid NOT NULL,
    body_id uuid,
    skill_id uuid,
    init_value integer
);


ALTER TABLE scenario.unique_stat OWNER TO postgres;

--
-- Name: where_object; Type: TABLE; Schema: scenario; Owner: postgres
--

CREATE TABLE scenario.where_object (
    id uuid NOT NULL,
    npc_id uuid,
    location_id uuid
);


ALTER TABLE scenario.where_object OWNER TO postgres;

--
-- Data for Name: on_use_item; Type: TABLE DATA; Schema: common; Owner: postgres
--

COPY common.on_use_item (id, name, item_scheme_id, item_id, var_limits, formula_id, fixed_vars) FROM stdin;
b533c9fe-532a-4e36-a299-ede3cf83ee7e	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
77bb906e-66b2-4083-98f1-bdf6820e4b98	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4}]
75500f4e-c63e-44cf-8b60-485dfd98d855	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
d6cf5343-0c2f-4416-8a6d-bf3070dc20f1	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
d07552c2-8162-4a02-af23-2fb08135bcd7	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
7dcf2e8f-76f5-43f2-a4f3-0fa1de268c88	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
9a10b5aa-0630-4c90-967e-99a235d4469b	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
97f88bd6-4532-41a6-bbab-486d507463bf	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
0bfadc97-2a06-4b90-a75d-38b232b05070	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
c99c1d80-6ed3-42ad-9c17-c7f9d8dbe962	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
ed677976-1423-41b2-b778-125207da65c5	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
b5ef58a8-97ce-45dd-9da0-8d9ee911f25c	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
87cb673f-eb48-4356-b4cd-882551cca57e	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
0bd5e1b0-8839-46ea-9bea-b0c1a8a1a20f	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
e0ae3626-bc2f-445d-aa20-7ce1f8304a08	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
64d53c6a-c566-4567-ae31-cbbb1104fa4e	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
97572c83-3a48-4bf0-ae78-4c854d826523	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
35818c11-0dcb-4bcb-bb90-a8a916d4eb2a	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
15aac272-9816-40c6-8053-65c200cdaca7	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
068c9978-1442-4320-b20e-bf5e70c16c6c	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
3e8ec003-0f6e-4b82-8e08-3b22203ddb50	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
01281c13-6b25-47d2-b44d-dd3892853583	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
402467d5-bbbb-4c60-8920-c7b74638888f	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
354ba843-347f-4a21-9ee7-22271c315665	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
d07aaba6-c616-4fa2-a8de-6aff2d58342d	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
9de64872-b0b3-4275-836b-2f9376f7a564	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
59e0d432-a64f-47c8-bf1c-49d197a547b6	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
eb34a500-f805-4da7-b594-2f744a1b0c72	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
2db48a0f-17b3-4295-b03a-6b38afb2f720	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
bbf1740b-8645-42b7-85bc-6af2c02640de	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
378aa4f1-a94b-47c7-8199-af4f25cfaf60	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
23497fb7-db6a-4cfb-b5b8-41aafe7aaf3e	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
5f078103-4e79-43a6-8d02-f4f985c0409e	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
d3ca9667-c182-421d-bdc1-b5712cf327c4	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
9a1411f2-a12f-4500-af36-9e779b69136a	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
98d4c4c2-4df2-431e-b75d-be6d610edcd4	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
6e6ef50d-51b1-4e17-bdf9-d32eeeef4ea3	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
ecd1ba38-06ab-4533-b4d0-a2ed34589a67	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
c42eef4a-9b34-4779-b7a5-a608a741656c	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
74237ffe-7a3f-4467-be08-1e9291769b18	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
37181486-d578-4fcc-b358-726846894c56	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
259a2e5c-99f8-4812-90b7-1d3c56c3d966	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 3, "optional_skill": null, "optional_body": null}]
3272c507-fde3-48d3-9f6a-247e75d13955	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
7c6ac648-09d9-4fc7-b476-3599fd4a1efe	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
0c721ca0-814c-4080-b209-a7b7ae2ef5a9	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
4d8497cf-3ac9-4760-ba9f-05a025847f4d	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
f0922463-3413-47db-90b9-6879a190b816	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
2e780339-c791-4133-8677-5838c3b1293a	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 5, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 3, "optional_skill": null, "optional_body": null}]
2e9eae2b-daad-4b48-b6b4-e3f15a1d30fd	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 5, "optional_skill": null, "optional_body": null}]
76f290d6-f8ff-477a-8b57-71c08fe6237f	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 5, "optional_skill": null, "optional_body": null}]
f4e4eaaf-b149-47be-8a61-e89e758ccbd1	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 5, "optional_skill": null, "optional_body": null}]
fb907de0-9745-45f1-bd21-d8e8c7a73d45	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 5, "optional_skill": null, "optional_body": null}]
9d922f56-c10d-46cc-9b0e-f8259905c1fb	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 5, "optional_skill": null, "optional_body": null}]
b8a7dddb-743c-42ed-955f-d8b8c8a24035	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 8, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}]
06865476-d41d-4972-bfa9-0aba604dfb41	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 3, "optional_skill": null, "optional_body": null}]
6304e6a3-4e20-4033-a88b-30802b2acac7	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
3bf11122-7c59-4e2c-8954-8208eec9ba24	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "var_type": "tuple", "value": [1, 10, 20]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
cb15cafc-287e-4191-8e44-4f519221ee2e	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 8, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}]
0b20e085-c5d4-4303-a8c2-7c9b1c2db1ec	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 8, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}]
da6a0310-129d-4ec5-a05d-f29ab7db83c2	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 5, "optional_skill": null, "optional_body": null}]
10a399b7-771b-4a11-9b9f-38253bf49eff	Установить	\N	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u043b\\u0430\\u0431\\u0430\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": true, "optional_skill": null, "optional_body": null}]
d80db13b-20d0-4982-9f21-2a6139bbb6ca	Кинуть	\N	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u043b\\u0430\\u0431\\u0430\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": false, "optional_skill": null, "optional_body": null}]
223fa739-52b2-4801-886e-dbd677ee9b93	Установить	\N	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u043b\\u0430\\u0431\\u0430\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": true, "optional_skill": null, "optional_body": null}]
8ffd3101-4e5c-4c6b-839b-0fc29896c155	Кинуть	\N	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u043b\\u0430\\u0431\\u0430\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": false, "optional_skill": null, "optional_body": null}]
4210cb01-887c-4696-bb3f-8d6e68ce1945	Кинуть	2e6b6bb5-5c2f-471b-8f14-5a46a28f48fb	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u043b\\u0430\\u0431\\u0430\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": false, "optional_skill": null, "optional_body": null}]
fb787fd2-dc2f-4e2a-85c1-ca3dea1dd0c7	Установить	2e6b6bb5-5c2f-471b-8f14-5a46a28f48fb	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u043b\\u0430\\u0431\\u0430\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": true, "optional_skill": null, "optional_body": null}]
481d677c-bd7f-44b9-b88c-35141c4042ad	Кинуть	d7712fa8-a6e2-4f3c-b848-6df78456a480	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u0440\\u0435\\u0434\\u043d\\u044f\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": false, "optional_skill": null, "optional_body": null}]
356ce2dd-2b5b-47ea-b179-7242dabc27f5	Установить	d7712fa8-a6e2-4f3c-b848-6df78456a480	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u0440\\u0435\\u0434\\u043d\\u044f\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": true, "optional_skill": null, "optional_body": null}]
c8d4140c-f03a-41c9-96a3-cc6a7f88b3ea	Кинуть	c0806e4a-1c6e-4833-b34a-8d12f67d9207	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u0438\\u043b\\u044c\\u043d\\u0430\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": false, "optional_skill": null, "optional_body": null}]
648a31ed-f32a-4ca2-a0ce-39cda431b431	Установить	c0806e4a-1c6e-4833-b34a-8d12f67d9207	\N	[]	63d5f75d-9552-4245-aaa7-7508b9d0d193	[{"var_name": "M0", "fixed_value": "\\u0421\\u0438\\u043b\\u044c\\u043d\\u0430\\u044f", "optional_skill": null, "optional_body": null}, {"var_name": "B0", "fixed_value": true, "optional_skill": null, "optional_body": null}]
b0831f09-ec87-4ea6-b402-993823dbf816	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 3, "optional_skill": null, "optional_body": null}]
80e29453-8a4a-4f84-b728-859b4972c832	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 3, "optional_skill": null, "optional_body": null}]
f7e802cf-342c-4d6a-8f02-92538c22a084	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
63f2fa95-8cc0-49cb-b3e3-f00dd9d622c0	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 3, "optional_skill": null, "optional_body": null}]
a140cc66-c712-444d-a012-03341f4fd9ef	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "3d515409-581e-4e22-9221-e577fbb92b99", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 5, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 3, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "74628522-1ba6-4587-aae4-4831a091c5d1", "optional_skill": null, "optional_body": null}]
2a9fb53e-d91e-468d-9956-6735f6d838a6	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 5]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}]
dc5e3b20-dfd6-4908-a47a-a62211049099	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "c12e7fa2-f030-49d1-8aa5-f1ef6047f2a9", "optional_skill": null, "optional_body": null}]
07c68e0a-3b37-4800-8e72-baa359437066	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": null, "formula_id": null, "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 5, "optional_skill": null, "optional_body": null}]
25b551c2-f9a4-4ca5-b441-5779182be4b8	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "c12e7fa2-f030-49d1-8aa5-f1ef6047f2a9", "optional_skill": null, "optional_body": null}]
60825a50-d573-44d0-b338-cf3529336bca	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "3d515409-581e-4e22-9221-e577fbb92b99", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 5, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 3, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "74628522-1ba6-4587-aae4-4831a091c5d1", "optional_skill": null, "optional_body": null}]
245e1f1b-1f6e-456d-a0f5-710372e6a816	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "3d515409-581e-4e22-9221-e577fbb92b99", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 10, 20]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "a6f36f4b-5f81-4e5e-adbf-44925d18d192", "optional_skill": null, "optional_body": null}]
5c0a4b98-28a1-4a3a-947f-c95efce226f2	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "3d515409-581e-4e22-9221-e577fbb92b99", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 6, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "5340cd8c-f850-4179-a305-74e780721d4f", "optional_skill": null, "optional_body": null}]
a11b78b7-b029-4b95-a913-502be0ebe30d	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "3d515409-581e-4e22-9221-e577fbb92b99", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 10, 20]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "a6f36f4b-5f81-4e5e-adbf-44925d18d192", "optional_skill": null, "optional_body": null}]
0f7422be-057f-4f8d-b55a-105fab7498df	Стрелять	cd9a557a-c151-46bb-bdbd-b9d77ea3b650	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "4e2afa4f-5318-42de-8f81-1f2981f376cd", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 5, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 3, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "74628522-1ba6-4587-aae4-4831a091c5d1", "optional_skill": null, "optional_body": null}, {"var_name": "B2", "fixed_value": false, "optional_skill": null, "optional_body": null}]
0072ca01-0a76-4541-8ef9-149cc9ae573a	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "c12e7fa2-f030-49d1-8aa5-f1ef6047f2a9", "optional_skill": null, "optional_body": null}]
3038440d-241d-4bea-b2f7-affa7d16f43e	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "5340cd8c-f850-4179-a305-74e780721d4f", "optional_skill": null, "optional_body": null}, {"var_name": "B2", "fixed_value": false, "optional_skill": null, "optional_body": null}]
1949aa69-9dba-42d8-b424-eb165738029c	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "3d515409-581e-4e22-9221-e577fbb92b99", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 6, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "5340cd8c-f850-4179-a305-74e780721d4f", "optional_skill": null, "optional_body": null}]
89fdc8e8-aa51-459b-8585-7883462b7876	Стрелять	84a37cac-eee3-4363-b42a-9046ed3a6fb8	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "4e2afa4f-5318-42de-8f81-1f2981f376cd", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 10]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 6, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "5340cd8c-f850-4179-a305-74e780721d4f", "optional_skill": null, "optional_body": null}, {"var_name": "B2", "fixed_value": false, "optional_skill": null, "optional_body": null}]
5f0450e9-da3b-4916-aac6-d35e7f3e62aa	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "5340cd8c-f850-4179-a305-74e780721d4f", "optional_skill": null, "optional_body": null}, {"var_name": "B2", "fixed_value": false, "optional_skill": null, "optional_body": null}]
33fb497d-eff5-4b95-b04a-22a4a662accf	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "5340cd8c-f850-4179-a305-74e780721d4f", "optional_skill": null, "optional_body": null}, {"var_name": "B2", "fixed_value": false, "optional_skill": null, "optional_body": null}]
ba79b015-293d-43f4-b92a-b8de3e0eeded	Стрелять	\N	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "c12e7fa2-f030-49d1-8aa5-f1ef6047f2a9", "optional_skill": null, "optional_body": null}, {"var_name": "B2", "fixed_value": false, "optional_skill": null, "optional_body": null}]
1a49f66c-e954-42f2-9efd-15bf06cc9410	Стрелять	\N	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "3d515409-581e-4e22-9221-e577fbb92b99", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 10, 20]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "a6f36f4b-5f81-4e5e-adbf-44925d18d192", "optional_skill": null, "optional_body": null}]
9c6022e8-b4cc-44a4-afe3-1805a483fdfa	Стрелять	9addcf63-4a16-45b1-b3b7-9631392c66cf	\N	[{"name": "\\u041a\\u043e\\u043b-\\u0432\\u043e \\u043f\\u0443\\u043b\\u044c", "var_name": "T0", "id": "4e2afa4f-5318-42de-8f81-1f2981f376cd", "formula_id": "3c449e23-4a43-4885-adaa-c7c4f11a7928", "var_type": "tuple", "value": [1, 10, 20]}]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "a6f36f4b-5f81-4e5e-adbf-44925d18d192", "optional_skill": null, "optional_body": null}, {"var_name": "B2", "fixed_value": false, "optional_skill": null, "optional_body": null}]
77485352-ebcd-4197-82b1-a214832c1470	Стрелять	30c86031-c89a-49d6-bd9b-57d86c4ef4c4	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 4, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "c12e7fa2-f030-49d1-8aa5-f1ef6047f2a9", "optional_skill": null, "optional_body": null}, {"var_name": "B2", "fixed_value": true, "optional_skill": null, "optional_body": null}]
50c4773a-8ef2-41ba-b2d2-31d8dc10da6e	Стрелять	6d805f92-2772-419b-82dd-7e17fe33bf09	\N	[]	3c449e23-4a43-4885-adaa-c7c4f11a7928	[{"var_name": "N0", "fixed_value": 8, "optional_skill": null, "optional_body": null}, {"var_name": "T0", "fixed_value": 1, "optional_skill": null, "optional_body": null}, {"var_name": "S0", "fixed_value": "a6f36f4b-5f81-4e5e-adbf-44925d18d192", "optional_skill": null, "optional_body": null}, {"var_name": "B2", "fixed_value": true, "optional_skill": null, "optional_body": null}]
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
06331a90e04e
\.


--
-- Data for Name: game_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.game_session (id, name, description, scenario_id, master_id, created_at, is_active) FROM stdin;
515d2aaa-768b-4456-a837-bb160cf473a8	Северный полюс	\N	515d2aaa-768b-4456-a837-bb160cf473a8	8be0377e-80f1-4029-9f21-6a57d3d9ad19	2026-02-05 11:14:30.019661+00	t
91979e50-ba6a-410e-93af-71024f0b6c6c	aaa	\N	e7b83145-6dda-43d7-8bf8-295223d2ba30	8be0377e-80f1-4029-9f21-6a57d3d9ad19	2026-02-15 15:28:16.371723+00	t
\.


--
-- Data for Name: master_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.master_group (id, name) FROM stdin;
6e7c1228-d5ec-483a-853e-9e4c22429046	Creators
\.


--
-- Data for Name: master_group_rule_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.master_group_rule_access (master_group_id, rule_id, permission) FROM stdin;
6e7c1228-d5ec-483a-853e-9e4c22429046	a453e635-289d-4f6d-bfdb-b43fb7decaea	all
6e7c1228-d5ec-483a-853e-9e4c22429046	d6f6a784-07d2-4a66-abd6-88d0dcd0b85f	all
6e7c1228-d5ec-483a-853e-9e4c22429046	0e5bf92a-21d2-4bc3-9a41-211dfafbb882	all
\.


--
-- Data for Name: master_group_scenario_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.master_group_scenario_access (master_group_id, scenario_id, permission) FROM stdin;
6e7c1228-d5ec-483a-853e-9e4c22429046	584f6a2a-b5dd-424b-a459-ed291d213995	all
\.


--
-- Data for Name: player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player (id, name, color, icon_url, img_url, user_id, game_session_id, character_id) FROM stdin;
e7f3c8a0-9b72-4fa8-a54b-c74885c2cfe4	string	\N	\N	\N	f11019db-f96b-4a43-b1f7-2c24a9a3b274	\N	\N
a1a38433-a7c6-47cd-b48b-4abf66d1ce92	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
ed2fe99d-237f-4eca-adae-4f5a4b5fc0d1	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
2eec2329-3dcd-4052-8790-867eef784805	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
4a55d6e9-dd7f-4c9a-8357-465e1c6600b5	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
743aef38-3ee8-4e5f-b012-ab0e7018317d	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
8c9b27c3-258a-4382-960c-8911fc06f961	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
bc2507ea-f3dc-49c5-9c45-4e982b315630	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
2504136f-4707-45ed-8676-88c0696c7a25	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
389cc142-9340-41e2-972e-6bc1e00da8f6	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
c0c47eb4-3dd5-4538-8d01-84a9eaf50afa	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
a255ca9c-e85d-4b46-9508-46a1820cbb9b	Pavel Andrusko	\N	\N	\N	fbbbecd7-e085-4bff-a54e-c9ac83a5f884	\N	\N
fc52a224-81ca-4019-8ff4-92bd31632d27	Ольга 	\N	\N	\N	43441fff-34a6-4636-8694-f302e5fd38da	\N	\N
bb1cba8b-f498-4f93-8ee0-41acc204bc65	Алёнка 	\N	\N	\N	f7b2c157-fc75-4e38-bc6e-fc3891b33741	\N	\N
7a7e2e21-d9cc-4f03-bebf-c40e64c7b3b7	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
4959d4ff-5db7-4eec-b494-8c834cd747b2	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
39a42bdf-6260-4cf7-8b9d-a91f4d500dee	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
702a41ca-df23-4e82-88e3-c4e59094e322	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
cec9b794-99d4-4ae2-b0da-ebc2a0ddacc5	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
eef2cab7-29ac-479a-b000-41f671ddca28	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
355537fe-6532-4ed6-a8b6-49ddbce7044b	Авраменко Александр	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
df5ea909-4eef-4f4c-80ce-7fdcca2fdf96	ᅠ ᅠᅠ ᅠ 	\N	\N	\N	73f93850-a127-4f42-84fe-f42d6467d44c	\N	\N
fb8b934f-3a25-4ec4-b0f0-5fc10af9dc86	Матян 	\N	\N	\N	c78f1771-c288-4fb8-8d8b-f4a138c5f667	\N	\N
eca89054-59ed-4fa0-81be-9ecf3da25170	Lil Teen	\N	\N	\N	a9646442-a9a8-4d50-8125-0235e740974f	\N	\N
a1901632-91e3-4e27-8b6d-e622d495abbd	Максончик 	\N	\N	\N	c0364b82-fe12-4706-a8bc-d9c11e490e1a	\N	\N
933cbea3-b7f1-4fb4-af59-2a6c47bf8b0b	evpatiy 	\N	\N	\N	a4ea4844-5b43-46ec-a592-ef88520b39c2	\N	\N
edf540be-fd5c-419f-8e41-e5f193dfed80	hilleri123	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
28ad0dfb-18b5-40ec-b467-001ada7b42ed	hilleri123	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
161bf7e8-f96c-4c2e-99c3-abead0320c79	Александр Авраменко	\N	\N	\N	aa9b7a85-fd11-4a80-8174-ac38225f2db4	\N	\N
e6f07568-502a-42e9-8d27-6679703f87ac	hilleri123	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
2492f0cc-314b-42ed-ad10-c85258904ad1	Ольга 	\N	\N	\N	43441fff-34a6-4636-8694-f302e5fd38da	\N	\N
3d7fa69a-c684-4861-8f7b-a4d824d7b44a	hilleri123	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
e2b352c9-de22-4caf-a535-383b0b601c41	Олька 	\N	\N	\N	45a36e32-1999-4fde-b9b5-308d8413f105	\N	\N
884e436a-d65b-41a3-95cf-0dd51e27dd75	Ольга 	\N	\N	\N	43441fff-34a6-4636-8694-f302e5fd38da	\N	\N
cceba90f-ce30-4805-a6b4-5e6f5a6eefbd	big_boss	\N	\N	\N	c85f75ed-871c-4ef3-ae4e-a6bd04934a93	\N	\N
9264635c-3278-4ee5-baf1-600ca8f3660d	hilleri123	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
fc826d51-ad75-4bcf-b7e9-207998f1c46d	Александр Авраменко	\N	\N	\N	aa9b7a85-fd11-4a80-8174-ac38225f2db4	\N	\N
313f16fa-17bb-4045-871f-cc596d238274	Матян 	\N	\N	\N	c78f1771-c288-4fb8-8d8b-f4a138c5f667	\N	\N
eee0cf61-ac3e-4fca-a3ab-43425a627fcb	Максончик 	\N	\N	\N	c0364b82-fe12-4706-a8bc-d9c11e490e1a	\N	\N
8c5e16ad-e5bb-46d1-9881-8c3028aa4d81	Ванпрайс 	\N	\N	\N	acd48b94-7515-4ce6-900a-99267f8adff3	\N	\N
6c8098dc-832b-4330-96d9-9e89695834b9	Lil Teen	\N	\N	\N	a9646442-a9a8-4d50-8125-0235e740974f	\N	\N
54c4ce45-49d8-42eb-8b6a-52005afc0ded	evpatiy 	\N	\N	\N	a4ea4844-5b43-46ec-a592-ef88520b39c2	\N	\N
3aa8bfa6-b097-43c2-9108-04e67e80044a	ᅠ ᅠᅠ ᅠ 	\N	\N	\N	73f93850-a127-4f42-84fe-f42d6467d44c	\N	\N
d1b7dc24-d540-4481-b6ab-7f0a5c7efd37	Arianna Rozhkova	\N	\N	\N	cfada759-f695-4cf4-aac7-a546cae317b5	\N	\N
39e6e870-8062-43c0-9d9d-bab8dce9f297	Матян 	\N	\N	\N	c78f1771-c288-4fb8-8d8b-f4a138c5f667	\N	\N
c95af0a7-d1b8-4dbc-8521-dff3d1d38d85	Матян 	\N	\N	\N	c78f1771-c288-4fb8-8d8b-f4a138c5f667	\N	\N
b2bb86f9-67a2-4402-8e0a-c92a9959b9c1	hilleri123	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
cc8757bd-b52c-40bd-9f59-9ebca5136fab	Ольга 	\N	\N	\N	43441fff-34a6-4636-8694-f302e5fd38da	\N	\N
ce1db4d7-25c7-4b8a-aa9b-a7211da7b5d4	Алёнка 	#11053b	\N	\N	f7b2c157-fc75-4e38-bc6e-fc3891b33741	\N	b7b28e0e-b136-4e8b-825b-7387fa3530d1
eb0c3159-ac27-45e8-8276-72014728be61	hilleri123	#ffffff	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	489b422b-8932-46dc-9dad-7b173a0eb5a7
be21db4e-fbdd-4778-9f9c-1b93444a89d9	Ольга 	#ff00ff	\N	\N	43441fff-34a6-4636-8694-f302e5fd38da	\N	d2e54b2e-a184-4559-8e0f-5dac77b62ea6
e165d216-9a96-4021-b054-165db78f7abb	hilleri123	#1eeb51	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	489b422b-8932-46dc-9dad-7b173a0eb5a7
8716e33c-0e6a-4654-89e7-b44721d3ab0c	Ольга 	\N	\N	\N	43441fff-34a6-4636-8694-f302e5fd38da	\N	\N
0e71b7d0-985e-4f9e-9e57-d90ed02bb5db	Алёнка 	\N	\N	\N	f7b2c157-fc75-4e38-bc6e-fc3891b33741	\N	\N
a0eb45a4-103a-47ea-a7fe-8475107c2afe	Pavel Andrusko	\N	\N	\N	fbbbecd7-e085-4bff-a54e-c9ac83a5f884	\N	\N
2e0253a2-c7d6-46cb-ab36-c66102313002	Pavel Andrusko	#0061fe	\N	\N	fbbbecd7-e085-4bff-a54e-c9ac83a5f884	\N	1dcb4854-e91c-4ae1-ae08-75cf5d7dcfb7
34d45bec-eca1-4078-a973-b671ea8e1df0	Ольга 	#ffff00	\N	\N	43441fff-34a6-4636-8694-f302e5fd38da	\N	eb882025-6fd7-4120-9778-a81e8e8716f7
58459b87-3971-47f1-bc5b-1cee57816bda	Ольга 	#ffff00	\N	\N	43441fff-34a6-4636-8694-f302e5fd38da	\N	eb882025-6fd7-4120-9778-a81e8e8716f7
c73c2107-d478-4de1-a1e1-206f80a69682	Алёнка 	#11053b	\N	\N	f7b2c157-fc75-4e38-bc6e-fc3891b33741	\N	b7b28e0e-b136-4e8b-825b-7387fa3530d1
d2619e74-66b1-40e6-aff9-a870a7db976e	Pavel Andrusko	#0061fe	\N	\N	fbbbecd7-e085-4bff-a54e-c9ac83a5f884	\N	1dcb4854-e91c-4ae1-ae08-75cf5d7dcfb7
d42f6f59-77c2-46ee-b8c8-feae037cb663	Алёнка 	#11053b	\N	\N	f7b2c157-fc75-4e38-bc6e-fc3891b33741	\N	b7b28e0e-b136-4e8b-825b-7387fa3530d1
1d085105-7dbc-4721-89b8-6b1d906e78c1	hilleri123	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
5f57e024-8657-4d2d-b33a-e45644ae2b07	Ольга 	#ffff00	\N	\N	43441fff-34a6-4636-8694-f302e5fd38da	\N	eb882025-6fd7-4120-9778-a81e8e8716f7
cd020ae2-125f-42ee-ab2a-52fdf01ebf95	Pavel Andrusko	#0061fe	\N	\N	fbbbecd7-e085-4bff-a54e-c9ac83a5f884	\N	1dcb4854-e91c-4ae1-ae08-75cf5d7dcfb7
f29d4447-6eb8-42ef-8c0e-649ad3e1979e	hilleri123	\N	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	\N
17b949de-2396-4a4c-99a0-34a4f3b151af	hilleri123	#ffffff	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	1dcb4854-e91c-4ae1-ae08-75cf5d7dcfb7
c597bad5-eed3-4281-a204-4614049fc869	hilleri123	#ffffff	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	1dcb4854-e91c-4ae1-ae08-75cf5d7dcfb7
7c595a4e-284b-4e19-8ecd-1983d04d8d0b	hilleri123	#00e1ff	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	fdb4855d-9bed-445b-81d2-40c4b626372f
c37d540d-f280-4129-a327-75bc991930b7	hilleri123	#00e1ff	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	908a8799-b033-483a-8bbf-ddb7f7b0db8b
cddb06e5-5f2d-48ff-aff8-4260c2819dc0	hilleri123	#00e1ff	\N	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	fdb4855d-9bed-445b-81d2-40c4b626372f
3669582a-3ea0-4179-9933-efb8a76c8825	test1	\N	\N	\N	6edcc55b-7cb1-4cc4-a543-57081beb84ab	\N	\N
9f5b70b4-58ca-4bdd-87e1-2b29f41eca26	test1	#ffffff	\N	\N	6edcc55b-7cb1-4cc4-a543-57081beb84ab	91979e50-ba6a-410e-93af-71024f0b6c6c	b0cc4329-83b0-45ca-8553-cb28b5abbf37
\.


--
-- Data for Name: player_action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player_action (id, description_for_master, description_for_players, add_time_secs, triggers_note_id, icon_url, img_url, location_id, npc_id, item_scheme_id, item_id) FROM stdin;
a809c04b-269d-4dea-811e-8f87b923dca3	Совладать с управлением	Совладать с управлением	0	\N	\N	\N	4552213d-1f7f-4e93-b458-548a38d0f418	\N	\N	\N
28b9cfdc-b50f-4533-b418-abbabf7c2e3f	test	test	0	\N	\N	\N	c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d	\N	\N	\N
65c04096-16a9-48d3-b7e5-5f8e6772ec86	test	test	0	\N	\N	\N	c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d	\N	\N	\N
c31889d7-c48c-47d3-9c11-9efa1e823a76	test	test	0	\N	\N	\N	c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d	\N	\N	\N
deafd43a-6be5-48b9-8fe1-0397a993ae37	test	test	0	\N	\N	\N	c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d	\N	\N	\N
a18bc138-da59-46e7-9014-9f78cc1b02f7	asd	asd	0	\N	\N	\N	c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d	\N	\N	\N
c70e801d-e0b6-4cb7-81ad-ca531b5aad63	asd	asd	0	\N	\N	\N	c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d	\N	\N	\N
bad94473-30d4-43fb-b5f1-3c096ccbe81a	asd	asd	0	\N	\N	\N	c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d	\N	\N	\N
6e47ca33-2f31-4c66-80b9-d049c60e7bd3	asd	asd	0	\N	\N	\N	c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d	\N	\N	\N
eb2142ca-15d3-4b6e-b6ce-f8a675e3079e	test	test	0	\N	\N	\N	57f336d1-61b1-4260-8e06-9fddb19a4e87	\N	\N	\N
deff42bc-78d8-486f-abfe-838f060895fb	test	test	0	\N	\N	\N	57f336d1-61b1-4260-8e06-9fddb19a4e87	\N	\N	\N
40cc1c26-b036-48bc-9f34-9b734db71cf7	test	test	0	\N	\N	\N	57f336d1-61b1-4260-8e06-9fddb19a4e87	\N	\N	\N
6554c6d1-646b-45c0-8dd0-2e80d4897752	test	test	0	\N	\N	\N	57f336d1-61b1-4260-8e06-9fddb19a4e87	\N	\N	\N
6c7d8528-dfab-44e8-ae64-c46f92d34d00	asd	asd	0	\N	\N	\N	57f336d1-61b1-4260-8e06-9fddb19a4e87	\N	\N	\N
e49afb91-eba0-45f1-aff7-7cf8641565cb	asd	asd	0	\N	\N	\N	57f336d1-61b1-4260-8e06-9fddb19a4e87	\N	\N	\N
f747c42b-c0c2-4747-8025-51d2de320b25	asd	asd	0	\N	\N	\N	57f336d1-61b1-4260-8e06-9fddb19a4e87	\N	\N	\N
b3f42413-ee31-42d7-9c3a-11dd346eb7df	asd	asd	0	\N	\N	\N	57f336d1-61b1-4260-8e06-9fddb19a4e87	\N	\N	\N
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, email, tg, can_be_master, full_name, hashed_password, is_active, icon_url, img_url, telegram_id, is_admin) FROM stdin;
6aac36c0-0d37-4670-a082-61a6ffe39eca	hilleri123@gmail.com	hilleri123	t	hilleri123	$2b$12$k6xrRxvGzP560uTV0sOJZ.jBccnry6yxA1psDNjMztR21U3GATBTm	t	\N	https://t.me/i/userpic/320/BfNwoWMmC1DKs73YHeTGiV7n1zs028_sOwYui14YhbM.svg	301220219	t
45a36e32-1999-4fde-b9b5-308d8413f105	\N	magik_fairy	f	Олька 	\N	t	\N	https://t.me/i/userpic/320/_8aadgb6iB7MEyti94zqbackVS04v1KAOyBFVclbluk.svg	677951802	f
be21c74c-13f9-4f55-9f84-eb02a5628225	isgerasin@mail.ru	\N	f	BigBoss	$2b$12$H6r4dUjFpdOeuQDMDXAAx.oJORPFPrs1XNMO9vO/uYqWT5dAKZ/a6	t	\N	\N	\N	f
c78f1771-c288-4fb8-8d8b-f4a138c5f667	\N	yakimonki	t	Матян 	\N	t	\N	https://t.me/i/userpic/320/lvYRfmutp1cIl9ExmyKPKgaIkjjU4okhY6SiHbz2W7U.svg	408389942	t
dbfb7880-a621-49ad-8d23-3cdd9d11c698	b@b.com	\N	f	BBB	$2b$12$X8lqk24V0LysZtTS4xjBQ.Vq.Iso/K9oSHOZlhRcxlpdWpgtV8ERS	t	\N	\N	\N	f
f11019db-f96b-4a43-b1f7-2c24a9a3b274	user@example.com	\N	f	string	$2b$12$/4oXFD1ZhEJIMhLZU8QxEuA7D05vlM3MY/sBZJKyStIpnuEyboaga	t	\N	\N	\N	f
73f93850-a127-4f42-84fe-f42d6467d44c	\N	vmryv	f	ᅠ ᅠᅠ ᅠ 	\N	t	\N	https://t.me/i/userpic/320/-c4te4vQ9L4DZzZB7zRZt3QF0X8TswznLqAco8_548s.svg	1417823900	f
f7b2c157-fc75-4e38-bc6e-fc3891b33741	\N	alenka_505	f	Алёнка 	\N	t	\N	https://t.me/i/userpic/320/NUUDeRfbd1FIvuvNAmWhMPZWeQquUPJf7l4UuXVhRlU.svg	232199422	f
c85f75ed-871c-4ef3-ae4e-a6bd04934a93	big_boss@a.ru	\N	f	big_boss	$2b$12$1FT05qicZOiWaIHlcAIR1uVr5IN03ZNJaIrWzWpHwuoNSu3IJ8bsy	t	\N	\N	\N	f
acd48b94-7515-4ce6-900a-99267f8adff3	\N	GriffithLox	f	Ванпрайс 	\N	t	\N	https://t.me/i/userpic/320/vIcucsk9MutjQ7u3MoU4jRuL4c-pF366cJVheeppslc.svg	1165749828	f
cfada759-f695-4cf4-aac7-a546cae317b5	\N	rarianna0	f	Arianna Rozhkova	\N	t	\N	https://t.me/i/userpic/320/jPXYuv6CkOS9SrUp-uqNUT9oo-oP0sCz2sRESVrSNRM.svg	170382234	f
fbbbecd7-e085-4bff-a54e-c9ac83a5f884	\N	pavel090909	f	Pavel Andrusko	\N	t	\N	https://t.me/i/userpic/320/6_-ivlgUNf1LmRPUYoI9kxKyS0WO0P_R_czNI7JcATA.svg	229432879	f
a9646442-a9a8-4d50-8125-0235e740974f	\N	deeplyscarred	f	Lil Teen	\N	t	\N	https://t.me/i/userpic/320/Vx93knGQWf6E4D5TH0vDpP4rDQ1tBuUM91NyM5T9WjI.svg	603314482	f
43441fff-34a6-4636-8694-f302e5fd38da	\N	Vs_Olga	t	Ольга 	\N	t	\N	https://t.me/i/userpic/320/tVE6GBPGAUm2HTbXjEG0RMy3eSQ3NohyCtFIzehiZ9k.svg	441442718	f
c0364b82-fe12-4706-a8bc-d9c11e490e1a	\N	zovimenyapapoi	t	Максончик 	\N	t	\N	https://t.me/i/userpic/320/TN8XSJq_vhVKlIUUS1RXFIsW12BOYO7-24GKN_4kWZY.svg	775302053	f
a4ea4844-5b43-46ec-a592-ef88520b39c2	\N	Cybertapokbabki	t	evpatiy 	\N	t	\N	https://t.me/i/userpic/320/zuKmJJUrtvNQd--UeGDbR8QaP1cXms6-y4hy-YHaGjE.svg	2087254285	f
8be0377e-80f1-4029-9f21-6a57d3d9ad19	a@a.ru	\N	t	TEST	$2b$12$1FT05qicZOiWaIHlcAIR1uVr5IN03ZNJaIrWzWpHwuoNSu3IJ8bsy	t	\N	\N	\N	t
aa9b7a85-fd11-4a80-8174-ac38225f2db4	hilleri1231@gmail.com	hilleri1231	t	Александр Авраменко	\N	t	\N	https://t.me/i/userpic/320/li_LZEPEpzJObPE2hVZB-xLohqazSmzSWlGTVkDzFsUSwjQqEp6qW0jlkalnty_c.svg	6382853683	t
6edcc55b-7cb1-4cc4-a543-57081beb84ab	user1@example.com	\N	f	test1	$2b$12$AjdrMWDC4XgK0Kht..MO1emnXi989ziqFLzxhio9D22uOrescxvRm	t	\N	\N	\N	f
\.


--
-- Data for Name: user_master_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_master_group (user_id, master_group_id, permission) FROM stdin;
8be0377e-80f1-4029-9f21-6a57d3d9ad19	6e7c1228-d5ec-483a-853e-9e4c22429046	all
6aac36c0-0d37-4670-a082-61a6ffe39eca	6e7c1228-d5ec-483a-853e-9e4c22429046	member
aa9b7a85-fd11-4a80-8174-ac38225f2db4	6e7c1228-d5ec-483a-853e-9e4c22429046	member
c78f1771-c288-4fb8-8d8b-f4a138c5f667	6e7c1228-d5ec-483a-853e-9e4c22429046	member
c0364b82-fe12-4706-a8bc-d9c11e490e1a	6e7c1228-d5ec-483a-853e-9e4c22429046	member
\.


--
-- Data for Name: rule_character_template; Type: TABLE DATA; Schema: rule; Owner: postgres
--

COPY rule.rule_character_template (id, template_set_id, name, short_desc, story, data, icon_url, img_url) FROM stdin;
d643534c-77e5-4860-b0da-a388ccdbe893	82a87fc7-3100-4cf1-95d8-c275a7151acf	AAA	\N	\N	{"name": "", "skills": {"architecture": 2}, "items": [], "points": {"investigativeMax": 2, "generalMax": 60}, "skill_points": {"investigativeTotal": 2, "generalTotal": 0}}	\N	\N
\.


--
-- Data for Name: rule_item_contained_template; Type: TABLE DATA; Schema: rule; Owner: postgres
--

COPY rule.rule_item_contained_template (id, owner_item_template_id, item_template_id, qty) FROM stdin;
\.


--
-- Data for Name: rule_item_ownership_template; Type: TABLE DATA; Schema: rule; Owner: postgres
--

COPY rule.rule_item_ownership_template (id, character_template_id, npc_template_id, item_template_id, qty) FROM stdin;
6b037c5d-ca9d-41e5-a2a8-4753c333a0b7	\N	60e3f2dc-411b-4b80-b3c6-2b4f4abb8454	a1589e49-bb6a-4b6f-9a14-69a0e31e8a24	1
0fac6600-93ef-466e-a8fb-e40f166d8fcf	\N	b97b362b-ae11-476d-94a8-8b0d2626ee54	f6d00345-2433-4884-bc46-4d7e8d055639	1
\.


--
-- Data for Name: rule_item_template; Type: TABLE DATA; Schema: rule; Owner: postgres
--

COPY rule.rule_item_template (id, template_set_id, name, description_for_master, description_for_players, icon_url, img_url, data, quest_html_mark) FROM stdin;
f366f593-6a29-4a8c-9ad8-0c8b91ff00ca	82a87fc7-3100-4cf1-95d8-c275a7151acf	aaa	\N	\N	\N	\N	{"tags": [], "weapon": {"type": "ranged", "damage": "1"}, "armor": null}	\N
a1589e49-bb6a-4b6f-9a14-69a0e31e8a24	712db641-0f41-4af5-b266-61199dab9061	Ружье с резиновыми пулями	\N	\N	\N	\N	{"tags": [], "quality": null}	\N
f6d00345-2433-4884-bc46-4d7e8d055639	712db641-0f41-4af5-b266-61199dab9061	Резиновая дубинка	\N	\N	\N	\N	{"tags": [], "quality": null}	\N
\.


--
-- Data for Name: rule_npc_template; Type: TABLE DATA; Schema: rule; Owner: postgres
--

COPY rule.rule_npc_template (id, template_set_id, name, description_for_master, description_for_players, data, icon_url, img_url) FROM stdin;
34f3aed6-78ef-4fb2-9514-ffa4b6ec2409	82a87fc7-3100-4cf1-95d8-c275a7151acf	TEMP	\N	\N	{"items": [], "skills": {"athletics": 11, "burglary": 0, "disguise": 0, "driving": 0, "filch": 0, "fleeing": 0, "infiltration": 0, "piloting": 0, "riding": 0, "shadowing": 0, "stealth": 0, "tinkering": 0, "scuffling": 0, "shooting": 0, "weapons": 0, "health": 0, "stability": 0, "preparedness": 0, "sense_trouble": 0}, "health": null, "stability": null, "armor": null, "hitThreshold": null}	\N	\N
60e3f2dc-411b-4b80-b3c6-2b4f4abb8454	712db641-0f41-4af5-b266-61199dab9061	Эльф-охранник Курильщик	\N	\N	{}	\N	\N
b97b362b-ae11-476d-94a8-8b0d2626ee54	712db641-0f41-4af5-b266-61199dab9061	Эльф-охранник Алкоголик	\N	\N	{}	\N	\N
\.


--
-- Data for Name: rule_template_set; Type: TABLE DATA; Schema: rule; Owner: postgres
--

COPY rule.rule_template_set (id, rule_id_str, scenario_id, name) FROM stdin;
82a87fc7-3100-4cf1-95d8-c275a7151acf	gumshoe	52978346-3a5d-4a67-b39b-bb666fe70aed	Default templates for test
712db641-0f41-4af5-b266-61199dab9061	blades_in_the_dark	515d2aaa-768b-4456-a837-bb160cf473a8	Default templates for Северный полюс
be5940a7-5d7d-40f6-91a4-d59e92d11a50	im_bitter_and_i_keep_records	6e80882a-4f37-4970-b475-d1650e8b32dc	Default templates for Тест Дворфы
9f94679b-e3c5-4b53-98b3-27b11e0157d0	everyone_is_john	e7b83145-6dda-43d7-8bf8-295223d2ba30	Default templates for TEST John
\.


--
-- Data for Name: scenario_template_set_link; Type: TABLE DATA; Schema: rule; Owner: postgres
--

COPY rule.scenario_template_set_link (id, scenario_id, template_set_id, enabled, order_num) FROM stdin;
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: rule; Owner: postgres
--

COPY rule.tag (id, code, entity_type, title, color, description, meta) FROM stdin;
24991caa-573b-424b-96d3-968f6719ffa0	story	note	История	\N	\N	\N
8ed4b04b-1dd3-4ac4-9878-5f11c5372138	task	note	Задание	\N	\N	\N
ac71f08c-a145-48aa-8b6d-6d9a2e894fe2	info	note	Информация	\N	\N	\N
cb32a3cf-8ce9-4f79-84e7-fb5187c86530	enemy	npc	Враг	\N	\N	\N
263396da-6645-484d-887f-e6620cf9b090	dead	npc	Мертвый	\N	\N	\N
b5a357d2-1661-41b4-bc7f-9d1633d7dd96	friendly	npc	Friendly	#34c759	Дружелюбный NPC	null
\.


--
-- Data for Name: character_tag; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.character_tag (character_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: counter; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.counter (id, name, description, value, min_value, max_value, scenario_id, character_id) FROM stdin;
ce30f758-6efe-4443-a77e-debb10eb9700	Эвакуация	Дней до эвакуации.	10	0	10	584f6a2a-b5dd-424b-a459-ed291d213995	\N
340fd53d-4717-409b-a7ca-6b1a0068ce79	aaa	\N	0	\N	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N
\.


--
-- Data for Name: game_item; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.game_item (id, name, description_for_master, description_for_players, erase_on_use, is_shown, icon_url, img_url, item_scheme_id, scenario_id, npc_id, location_id, character_id, data, quest_html_mark) FROM stdin;
77a490e6-b6fa-4f52-b1b2-7f95883bb8b2	ultra_test	asfasd	1	f	f	\N	\N	16b6b0f0-4f57-4a64-b9d1-10375636e5d1	\N	\N	153c743a-e31c-40ec-8d44-8d7177c79d41	\N	\N	\N
a5593720-2627-47fd-b240-058f299a7ae8	asd	asd	asd	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/gameitem/img/20250731_183242_a5593720-2627-47fd-b240-058f299a7ae8.png	92849e23-2813-40df-ae44-8c98b0a2980c	\N	\N	\N	\N	\N	\N
cae34b3b-428d-45fd-8f02-8a1b2a9bca75	asda	123	11	f	f	\N	\N	92849e23-2813-40df-ae44-8c98b0a2980c	\N	\N	\N	\N	\N	\N
f5f43ac5-03b0-480c-9440-d2d305c05e2b	Супер пилюля	Хе хе	Опа и выпил	t	f	\N	\N	59d3384f-68f9-4eb9-8141-c650d327207c	\N	\N	\N	\N	\N	\N
a98e2727-c09a-4f9d-b6dd-35c7bf167be4	aaa	\N	\N	\N	\N	https://rpgzona.ru/minio-api/rpg-assets/entity/character/icon/20260122_091558_05bd5768-6e03-4c83-9def-cfa7dc86ea56.png	\N	\N	52978346-3a5d-4a67-b39b-bb666fe70aed	\N	\N	\N	{"tags": [], "weapon": null, "armor": null}	\N
7ab21c8a-69a6-470a-b71e-2fd48c818b51	jjj	\N	\N	\N	\N	https://rpgzona.ru/minio-api/rpg-assets/item_scheme/icon/20251004_084303_1da7bf78-a991-4569-b407-1192792f378d.webp	https://rpgzona.ru/minio-api/rpg-assets/item/img/20260124_194144_7ab21c8a-69a6-470a-b71e-2fd48c818b51.png	\N	52978346-3a5d-4a67-b39b-bb666fe70aed	\N	\N	\N	{"tags": [], "weapon": {"type": "ranged", "damage": "3"}, "armor": null}	\N
1592b6bc-c993-48e8-8d09-554ad325630e	aaa	\N	\N	\N	\N	\N	\N	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	\N	\N	{"tags": [], "quality": null}	<span style="\n  display:inline-flex;\n  width:32px;height:32px;\n  align-items:center;justify-content:center;\n  border-radius:9999px;\n  background:#3b82f6;\n  color:#0b0b0b;\n  font-weight:800;\n  font-family:ui-sans-serif,system-ui;\n  font-size:18px;\n  line-height:1;\n">Q</span>\n
fa75849e-18cd-4263-8a55-d9030b2c18e1	fff	\N	\N	\N	\N	\N	\N	\N	6e80882a-4f37-4970-b475-d1650e8b32dc	\N	\N	\N	{"type": "weapon", "requiredTags": ["two_handed", "thrust", "cleave"], "keyTags": [], "tags": [], "defense": 0, "damage": [{"dtype": "slashing", "base": 2, "notes": ""}], "masteryRules": {"noviceAt": 2, "trainedAt": 3, "masterAt": null, "legendAt": null, "note": "Mastery is computed by tag matches (character tags + equipped/tools + passives)."}}	\N
\.


--
-- Data for Name: game_time_event; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.game_time_event (id, name, text, start_time, end_time, icon_url, img_url, note_id, scenario_id) FROM stdin;
\.


--
-- Data for Name: item_ownership; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.item_ownership (id, item_id, character_id, npc_id, owner_item_id, qty, created_at) FROM stdin;
f4e47dcd-27b5-41a2-a418-9f2749aa5c28	a98e2727-c09a-4f9d-b6dd-35c7bf167be4	\N	316149e8-c48c-4348-b04e-48481e887d63	\N	1	2026-01-24 19:42:43.346481+00
\.


--
-- Data for Name: item_tag; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.item_tag (item_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: location; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.location (id, name, description_for_master, description_for_players, is_shown, is_start, icon_url, map_url, parent_location_id, scenario_id, data) FROM stdin;
8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	_ Завод Санты Клауса	<p>Это не веселая «фабрика чудес», а тоталитарный трудлагерь под маркой Санты, где дети‑эльфы из списка «плохих» превращены в стандартизированную рабочую силу, а сама система устроена как идеальная машина по перемолу желаний и тел в ресурс.</p><h2>Общая картина и цикл работы</h2><ul><li><p>Эльфы полностью обезличены: все на одно лицо, различаются только номером на форме и цветным браслетом цеха (по этапам производства — почти радуга).</p></li><li><p>Завод — замкнутая экосистема: всё, что входит (письма, случайные артефакты Реактора), перерабатывается в подарки и одновременно подпитывает саму систему (через Ресурсный Реактор, утилизацию брака и трупов).</p></li></ul><h2>Люди, инструменты и правила</h2><ul><li><p>Эльфы‑рабочие</p><ul><li><p>Не едят и не устают магически, не нуждаются во сне: режим выстроен так, чтобы они были всегда выжаты, но работоспособны.</p></li><li><p>Внешне одинаковые, отличия только по номеру и браслету цеха.</p></li></ul></li><li><p>Охранники‑эльфы</p><ul><li><p>Выродившиеся «плохиши», с лицами, испорченными курением и алкоголем.</p></li><li><p>Без номеров, но с уникальным «дыханием»: для доступа в охранные зоны и систему нужен запах табака/перегара.</p></li><li><p>Наказания регулируются документами; если из‑за набора запретов конкретного эльфа нельзя наказать, охрана запрашивает общий ордер на снятие части этих запретов.</p></li></ul><ul><li><p>Каждый цех имеет свой бюрократический блок, склад инструментов, архив и комнату отдыха охраны; это «нервные узлы», через которые проходят любые изменения статуса.</p></li></ul></li></ul><p>Эта памятка может быть твоей «карточкой завода»: от неё легко прыгать в конкретный цех, событие или хейст, всегда помня общий цикл — письмо → план → ресурс → детали/ткань → товар → мешки → рейс.</p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_104550_8c5b9a7b-bdac-4721-b0b6-d4b7740a150d.png	\N	515d2aaa-768b-4456-a837-bb160cf473a8	{}
e73b35be-cc8c-4482-9fc6-da52a698991a	1. Цех сырьевой обработки	<p>Это первая производственная стадия после загадочного реактора.</p><p><strong>Назначение:</strong> превратить поток «сырого чуда» (энергия, материалы) в стандартизированные полуфабрикаты: порошки, сплавы, заготовки, волокна.</p><p><strong>Как выглядит:</strong></p><ul><li><p>Огромные залы с магическими тиглями, ваннами и дробилками. Пол — в разводах от разноцветных реакций, воздух — в свете и пыли.</p></li><li><p>Над каждой линией — магический экран, показывающий «образ» процесса, но не финального продукта.</p></li><li><p>С конвейеров внизу сходят стандартизированные контейнеры: слитки, брикеты, бобины нитей, кристаллы.</p></li></ul><p></p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_104935_e73b35be-cc8c-4482-9fc6-da52a698991a.png	8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	515d2aaa-768b-4456-a837-bb160cf473a8	{}
73aaf7df-86f7-4cea-aaa5-5b92cb0135f2	3. Ткацкий цех 	<p>Ткацкий цех — это место, где фабрика делает кожу и одежду для своих чудес и узников. Здесь меньше грубой механики, зато гораздо больше визуальных и «магических» штук, которые можно обыгрывать в сценах.</p><h2>Общий профиль ТЦ</h2><p>Задача ТЦ:</p><ul><li><p>ткать ткани и наполнители;</p></li><li><p>шить оболочки игрушек, элементы формы, упаковку;</p></li><li><p>разрабатывать и хранить стандарты кроя и внешнего вида (включая форму эльфов и охранников).</p></li></ul><p>Инструментов мало и в основном категории 1 (ножницы, иглы, мелкий ручной инструмент), но вокруг много магических приспособлений, облегчающих именно шитьё, подгонку и работу с размерами.</p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_105037_73aaf7df-86f7-4cea-aaa5-5b92cb0135f2.png	8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	515d2aaa-768b-4456-a837-bb160cf473a8	{}
aced96f1-0caa-4214-8eb8-1b835753e380	5. Центр отправки	<p>Центр отправки — это витрина фабрики и последняя граница, за которой начинается «мир детей». Для игры это и финальный боссовый уровень, и огромный логистический узел, где ошибки почти не прощаются.</p><h2>Общий профиль ЦО</h2><p>Задача Центра отправки (ЦО):</p><ul><li><p>принять промаркированные мешки из СЦ;</p></li><li><p>распределить их по рейсам;</p></li><li><p>погрузить в сани с оленьими упряжками и к роботам‑Сантам;</p></li><li><p>настроить маршруты и отдать разрешение на вылет.</p></li></ul><p>Структурно ЦО состоит из:</p><ul><li><p>зоны приёма и распределения мешков;</p></li><li><p>основного ангара саней;</p></li><li><p>залов роботов‑Сант и техобслуживания;</p></li><li><p>диспетчерской и узла маршрутов;</p></li><li><p>дока подлёдных/альтернативных маршрутов (если нужен);</p></li><li><p>охранно‑контрольного блока.</p></li></ul><p></p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_105104_aced96f1-0caa-4214-8eb8-1b835753e380.png	8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	515d2aaa-768b-4456-a837-bb160cf473a8	{}
a1ab2206-752d-4152-be84-718700bb6bc4	2.4. Административное здание МЦ	<p>Стоит боком от производственных залов, связано коридорами со складом и линиями.</p><h2>Бюро инструментов и допусков</h2><ul><li><p>Окошки выдачи/приёма инструментов:</p><ul><li><p>учёт кат.1 (по шкафчикам),</p></li><li><p>строгий учёт кат.2 и, если есть, кат.3.</p></li></ul></li><li><p>Журналы и магические таблички с текущими допусками: кто сейчас имеет право пользоваться каким типом инструмента и станком.</p></li></ul><p><strong>Бланки:</strong></p><ul><li><p>МЦ‑ИНСТ‑1 — сообщение о поломке инструмента и запрос на замену.</p></li><li><p>МЦ‑ДОП‑2 — заявка на допуск к конкретному механизированному инструменту или группе станков.</p></li><li><p>МЦ‑ПЕР‑ЛИНИЯ — запрос на временное изменение профиля работника (перевод на другой пост/станок).</p></li></ul><h2>Кабинеты мастеров и начальника цеха</h2><ul><li><p>Комнаты с планами цеха, графиками смен, таблицами выработки.</p></li><li><p>Здесь решают:</p><ul><li><p>кого послать на стажировку в другой цех;</p></li><li><p>кого «поднять» в кандидаты на игры за повышение;</p></li><li><p>кого включить в аудит чужого цеха.</p></li></ul></li></ul><p>В шкафах — локальные распоряжения, внутренние отчёты, списки «проблемных» номеров.</p><h2>Малый архив МЦ</h2><ul><li><p>Папки с:</p><ul><li><p>техкартами изделий (механическая часть),</p></li><li><p>журналами несчастных случаев именно в МЦ,</p></li><li><p>изменениями в технологиях (например, новая модель шурупа, новый корпус).</p></li></ul></li></ul><p>Полезное место для игроков, чтобы понять, какие девайсы вообще проходят через МЦ и как устроены узлы, которые они хотят сломать/угнать.</p><h2>Комната отдыха охраны МЦ</h2><ul><li><p>Аналогично РР:</p><ul><li><p>столы, стулья, пепельницы, алкоголь;</p></li><li><p>личные ящики стражей.</p></li></ul></li><li><p>Здесь охрана обсуждает, кто плохо работает, кто «слишком умный», кто часто подаёт странные заявки.</p></li></ul><p></p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_105019_a1ab2206-752d-4152-be84-718700bb6bc4.png	bf2dd9d9-8001-44f1-85e3-86d61720509f	515d2aaa-768b-4456-a837-bb160cf473a8	{}
3c75bbcb-accd-4be3-bbb6-fe766d95c19b	1.2.1. Бар	<p>Тут можно познакомиться с барыгой, который хочет, перепродавать имущество со склада.<br>Тут же подраться с местными. Подцепить девушек и прочее, что можно сделать в баре.</p>		f	f	\N	\N	5d67269e-17e7-44dc-9676-14c8de528bd8	584f6a2a-b5dd-424b-a459-ed291d213995	{}
b84a761f-4475-4ab7-88a8-d2ede64740b2	0.2. Здание			f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_104909_b84a761f-4475-4ab7-88a8-d2ede64740b2.png	257a2632-3a25-4716-9ae8-444346e8b369	515d2aaa-768b-4456-a837-bb160cf473a8	{}
1a70b648-d9c2-45d6-ba34-0d84e8fec34c	4. Центр сортировки	<p>Центр сортировки — это место, где хаос готовых изделий превращается в аккуратные мешки с подарками и маршрутами для отправки. Он выглядит как огромная карусель конвейеров, окружённая бюрократией и контрольными постами.</p><h2>Общий профиль Сортировочного Центра</h2><p>Задача СЦ:</p><ul><li><p>принять готовые товары из разных цехов;</p></li><li><p>собрать их в наборы по письмам/заказам;</p></li><li><p>упаковать в мешки;</p></li><li><p>промаркировать мешки и назначения;</p></li><li><p>передать всё в Центр Отправки.</p></li></ul><p>Центр делится на:</p><ol><li><p>Зону приёма с цехов.</p></li><li><p>Круговой главный конвейер.</p></li><li><p>Радиальные линии укомплектования мешков.</p></li><li><p>Узел маркировки и фото.</p></li><li><p>Малый склад ожидания отправки.</p></li><li><p>Административный блок.</p></li></ol><p></p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_105052_1a70b648-d9c2-45d6-ba34-0d84e8fec34c.png	8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	515d2aaa-768b-4456-a837-bb160cf473a8	{}
153c743a-e31c-40ec-8d44-8d7177c79d41	aaa	<p><del>Новый текст</del></p>\n	<p><em>Очень</em> новый <strong>текст</strong></p>\n	f	f	\N	\N	\N	\N	{}
9a932465-b372-46e3-bbbe-515cde20f668	6. ЖД Станция	<p></p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_105129_9a932465-b372-46e3-bbbe-515cde20f668.png	8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	515d2aaa-768b-4456-a837-bb160cf473a8	{}
7afc0381-b181-42ce-9c83-b32d65e08712	2.1.3. Причал	<p><strong>Лодки:</strong> 5 плоскодонок, 20 плетеных (корзинок) и катер.</p>\n		f	f	\N	\N	01541e3e-e37c-43c1-8920-fc0031824dc7	584f6a2a-b5dd-424b-a459-ed291d213995	{}
bad25b26-ab37-45ea-ac95-f2f9fbd69f61	1.3.3. Ферма	<p>На ферме есть трактор, на котором можно тренироваться, если его угнать, за удачный угон <strong>+2 вождение гусинечной техники</strong>.</p><p>Фермер гонит самогон; можно выменять/украсть/договориться” — и привязать это либо к универсальным очкам (уважение/слава).<br></p>	<p></p>	f	f	\N	\N	483bf45b-248f-464e-b62b-901692055cf1	584f6a2a-b5dd-424b-a459-ed291d213995	{}
e6e66461-a98b-4b74-be47-815755112c88	1.6. Здание управления РР	<p>В стороне от залов, но связанное с ними коридорами: административно‑служебный корпус.</p><h2>Бюрократический отсек (подача заявлений)</h2><p>Помещение с несколькими окошками и столами:</p><ul><li><p>Окна приёма заявок:</p><ul><li><p>на замену инструмента;</p></li><li><p>на допуск к кат.2 и кат.3 инструментам;</p></li><li><p>на участие в стажировках/повышениях, связанных с РР;</p></li><li><p>на фиксацию аномалий и «рационализаторских предложений» по утилизации.</p></li></ul></li><li><p>Столы для заполнения форм:</p><ul><li><p>вешала с образцами бланков;</p></li><li><p>стенды с инструкциями, как правильно подать заявку.</p></li></ul></li></ul><p><strong>Типы бланков:</strong></p><ul><li><p>Форма РР‑ИНСТ‑1 — «сообщение о поломке инструмента и запрос на замену».</p></li><li><p>Форма РР‑ДОП‑2 — «заявка на допуск к механизированному инструменту (кат.2)».</p></li><li><p>Форма РР‑ДОП‑3 — «заявка на допуск к экзоскелетам/спецоборудованию (кат.3)».</p></li><li><p>Форма РР‑АНОМ — «сообщение об аномалии» (для официального признания и статистики).</p></li><li><p>Форма РР‑СТАЖ — «заявка на стажировку/перевод в другой участок РР или в другой цех».</p></li></ul><p>Оформленные бланки попадают в лотки, откуда их забирают клерки‑эльфы и несут в архив или начальнику.</p><h2>Склад инструментов</h2><p>Отдельная запираемая комната:</p><ul><li><p>стеллажи с:</p><ul><li><p>инструментами кат.1 (по ячейкам, под номера шкафчиков);</p></li><li><p>инструментами кат.2 (отмечены как «выдаётся только по разрешению»);</p></li><li><p>единичными экземплярами кат.3 (если в РР вообще есть экзоскелеты/тяжёлые риги).</p></li></ul></li><li><p>учёт ведётся по журналам и/или магическим табло:</p><ul><li><p>номер эльфа, время выдачи, предполагаемый срок возврата.</p></li></ul></li></ul><p>Здесь же хранятся запасные очки с бровями, тепло‑стойкие перчатки, спецкостюмы.</p><h2>Архив РР</h2><p>Небольшой, но насыщенный бумагами зал:</p><ul><li><p>шкафы с папками:</p><ul><li><p>отчёты по сменам,</p></li><li><p>акты об аномалиях,</p></li><li><p>списки допусков к инструментам и зонам,</p></li><li><p>внутренние инструкции по обращению с ядром (формально — «для вида»).</p></li></ul></li><li><p>отдельный шкаф с <strong>журналами несчастных случаев</strong>, где фиксируется:</p><ul><li><p>кто погиб/пострадал,</p></li><li><p>на какой линии,</p></li><li><p>как утилизированы останки.</p></li></ul></li></ul><p>Архив — золотая жила для шантажа, поиска «дыр» в системе и понимания реальной смертности.</p><h2>Комната отдыха охраны</h2><p>Помещение рядом с входом/выходом, чуть в стороне от потока рабочих:</p><ul><li><p>столы, стулья, шкафчики для личных вещей, вешалки для курток и дубинок.</p></li><li><p>пепельницы (переполненные), бутыли/канистры с алкоголем, кружки.</p></li><li><p>на стенах:</p><ul><li><p>пропагандистские плакаты в стиле «Охрана — щит Санты»;</p></li><li><p>доска «особо отличившихся» (охрана, особенно жестоко наказавшая нарушителей).</p></li></ul></li></ul><p>Охранники здесь:</p><ul><li><p>курят и пьют (поддерживая «дыхательную подпись»),</p></li><li><p>обсуждают смены, делятся слухами,</p></li><li><p>могут хранить «личные» трофеи (зажигалки, ножи, мелкие артефакты, которые не провели по учёту).</p></li></ul><p></p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_104953_e6e66461-a98b-4b74-be47-815755112c88.png	e73b35be-cc8c-4482-9fc6-da52a698991a	515d2aaa-768b-4456-a837-bb160cf473a8	{}
98b7bd04-ce44-4d93-b0e7-1f299c9c2f59	1.1.8. Стоянка	<p>На стоянке стоит БМП, под которой мехвод хранит алкоголь; завести и откатить её может только он, но игроки могут что-то дургое придумать. За сдвиг <strong>+2 вождение гусеничной техники</strong>.</p>	<p>Тут стоят машины учебной части. В том числе машины офицеров, на которых они сюда приезжают утром.</p>	f	f	\N	\N	3fde77d0-afa5-4343-8535-d6fc4301ef4f	584f6a2a-b5dd-424b-a459-ed291d213995	{}
f57058d3-8b24-4166-aaa8-a3aeb8fce695	6.2. Служебные коридоры и подсобки			f	f	\N	\N	9a932465-b372-46e3-bbbe-515cde20f668	515d2aaa-768b-4456-a837-bb160cf473a8	{}
6b1c0559-b5db-4045-bca3-1a148944fb36	6.3. Платформы			f	f	\N	\N	9a932465-b372-46e3-bbbe-515cde20f668	515d2aaa-768b-4456-a837-bb160cf473a8	{}
54aa67ac-23a4-453e-a96b-d4a5b23748a9	8. Техтоннели			f	f	\N	\N	8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	515d2aaa-768b-4456-a837-bb160cf473a8	{}
2c5eac95-c1f0-444c-8dec-7cb85753b395	2.1.1. Склад	<p></p>	<p></p>	f	f	\N	\N	9b07b8de-a319-42b9-875c-146f56213c74	584f6a2a-b5dd-424b-a459-ed291d213995	{}
ddf7a71d-abaa-4cfa-8110-1507a4548e01	3.4. Административное здание ТЦ	<h2>Бюро норм, формы и выдачи экипировки</h2><ul><li><p>Окошки, где выдают:</p><ul><li><p>базовую униформу эльфов по цехам (по номеру и браслету),</p></li><li><p>спецодежду для определённых операций (например, утеплённые вещи для ЦО).</p></li></ul></li><li><p>Здесь же принимают заявки на замену формы (износ, повреждения, смена цеха).</p></li></ul><p>Бланки:</p><ul><li><p>ТЦ‑ФОРМ‑1 — запрос на выдачу/замену формы.</p></li><li><p>ТЦ‑ЭКИП‑2 — заявка на спецэкипировку (например, утеплённые сапоги, перчатки, маскировочные плащи для наружных работ).</p></li></ul><h2>Отдел проектирования кроя и стандартов</h2><p>Самое вкусное место для игроков.</p><ul><li><p>Комната/несколько комнат с:</p><ul><li><p>большими столами для черчения;</p></li><li><p>стенами, завешанными лекалами и схемами кроя;</p></li><li><p>манекенами разных размеров (для Санты, охранников, разных типов игрушек).</p></li></ul></li><li><p>Здесь эльфы‑конструкторы:</p><ul><li><p>разрабатывают новые модели формы и упаковки;</p></li><li><p>подгоняют стандарты под изменившиеся требования (например, новая эмблема, другой цвет цеха).</p></li></ul></li></ul><p>Интерес:</p><ul><li><p>тут можно:</p><ul><li><p>найти или создать чертёж любой формы/предмета из ткани;</p></li><li><p>спроектировать одежду для побега (маскировку, зимний комплект, скрытые карманы);</p></li><li><p>подделать стандарты так, чтобы форма охраны или рабочих получила «случайно» другие элементы (например, дополнительные карманы или менее заметные номера).</p></li></ul></li></ul><h2>Малый архив ТЦ</h2><ul><li><p>Хранит:</p><ul><li><p>стандарты кроя по годам;</p></li><li><p>старые образцы формы (в том числе уже не используемые ранги/должности);</p></li><li><p>техкарты по тканям и нитям (какая ткань выдерживает мороз, какая плохо горит, какая почти не промокает).</p></li></ul></li></ul><p>Интерес:</p><ul><li><p>здесь можно обнаружить забытые виды формы (например, «инспектор» или «контролёр внешних работ»), под которые можно подделаться;</p></li><li><p>информация о свойствах тканей — важный ресурс для планирования выхода в мороз, прятания, защиты от воды/огня.</p></li></ul><h2>Комната отдыха охраны ТЦ</h2><ul><li><p>Менее суровая, чем в РР и МЦ, но с теми же сигаретами/алкоголем.</p></li><li><p>На стенах могут висеть конфискованные «неправильные» образцы: слишком яркие, слишком мрачные, с неутверждёнными символами — как предупреждение.</p></li></ul><p>Интерес:</p><ul><li><p>охрана обсуждает «странные заказы» ЦО и ЦП (например, особые костюмы для визитов Санты);</p></li><li><p>иногда здесь можно найти куски необычной формы, отложенные как трофеи.</p></li></ul><p></p>		f	f	\N	\N	73aaf7df-86f7-4cea-aaa5-5b92cb0135f2	515d2aaa-768b-4456-a837-bb160cf473a8	{}
ac3c5789-fef6-4a56-bfb8-59286c08c63a	2.2. Окружение	<p></p>	<p></p>	f	f	\N	\N	01541e3e-e37c-43c1-8920-fc0031824dc7	584f6a2a-b5dd-424b-a459-ed291d213995	{}
257a2632-3a25-4716-9ae8-444346e8b369	0. Центр сортировки писем	<p>Центр сортировки писем — это мозг всей фабрики: здесь сырое «хочу подарок» превращается в цифры, категории и планы производства. Он выглядит как огромный храм бумаги и папок.</p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_104854_257a2632-3a25-4716-9ae8-444346e8b369.png	8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	515d2aaa-768b-4456-a837-bb160cf473a8	{}
6f2a7114-bf23-4221-a6e8-6c54b59a86c5	_ Интро	<p>Первая ночь декабря. По белой пустыне летит маленький паровоз, облепленный новогодними гирляндами. Серый снег вокруг дрожит в разноцветных отражениях, а над ним тихо переливается северное сияние зелёными и фиолетовыми полосами.</p><p>Когда‑то вы были детьми. Вас похитили, лишили имён и лиц, переписали тела, и теперь вы — одинаковые эльфы. Отличия всего два: номер, крупно вышитый на яркой праздничной зелёной униформе, и цвет браслета на правой руке — метка того, в каком цехе вы будете работать на конвейере Санты.</p><p>Это не первый год. В прошлый раз после Нового года вас собрали в эшелон и отвезли обратно, в подземные тюрьмы под льдом, где вы ждали нового сезона работ. Магия, что сделала вас эльфами, забрала у вас голод и усталость, но не забрала возможность умереть: если вас разорвёт станком или забьёт охрана — вы умрёте, а тело пойдёт в топку ресурсного реактора, как любой другой брак.</p><p>Будто в подтверждение мыслей, в соседнем вагоне что‑то происходит: крик, скрежет, хлопок двери. Несколько фигур в таких же ярких новогодних зелёных куртках бросаются в белую пустыню. На мгновение вы видите их в свете гирлянд и сияния — маленькие, хрупкие, одинаковые. Через пару секунд пустыня отвечает глухими хлопками. Бах. Бах. Бах. Вдалеке взлетают фонтанчики снега, и силуэты исчезают. Весь путь к заводу — сплошное минное поле; побег с ходу — просто другой способ погибнуть.</p><p>В коридоре между вагонами дежурят эльфы‑охранники. Они не такие, как вы: лица одутловатые, глаза мутные, жесты резкие. Когда‑то они были отъявленными плохишами, за это их сделали надсмотрщиками. Теперь магия держит их на крючке: они курят и пьют не ради удовольствия, а потому что не могут иначе — дым и перегар стали частью их сущности, их своеобразным «паролем» для системы. Они вооружены дубинками, кастетами и ружьями с резиновыми пулями. Для взрослого это игрушки, но для маленького эльфа — более чем достаточно.</p><p>Новогодний паровозик мчит вперёд по серому снегу. Гирлянды мерцают, отбрасывая цветные блики на одинаковые лица. Вы сидите в одном купе. Но вы всё равно поворачиваетесь друг к другу и впервые по‑настоящему смотрите в чьи‑то глаза. Сейчас вы ещё вместе. Сейчас у вас есть несколько часов дороги, пока двери не откроются и вас не разбросят по цехам.</p><p>Вам необходимо сбежать, вернуть себе имена и жизнь — план нужен не на заводе, а уже сейчас. Пока поезд стучит колёсами, пока мины молчат под снегом, пока охранники курят в коридоре, вам нужно решить главное:</p><p>как вы наладите связь и узнаете друг друга, когда станете только номерами в ярких зелёных куртках на фабрике Санты?</p>		f	f	\N	\N	\N	515d2aaa-768b-4456-a837-bb160cf473a8	{}
f0b26a81-6853-49fa-b3d2-146ae5d25b81	ASDA1	<p>aaaa <strong>bbbaaaaaaaaaaaaaaaaaaaaaaaaaaaa12345678901234567890123<em>456789012345678901234567890123456789012345678901234567890123</em>4567890</strong></p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260124_194532_f0b26a81-6853-49fa-b3d2-146ae5d25b81.png	\N	52978346-3a5d-4a67-b39b-bb666fe70aed	{"name": "", "skills": {}, "items": [], "points": {"investigativeMax": 0, "generalMax": 0}, "skill_points": {"investigativeTotal": 0, "generalTotal": 0}}
8fadcf1e-fb0d-4c77-b1f3-6488a80c1b60	1.1.5. Полигон	<p>Игрок приходит на полигон в свободное время. Успешная серия стрельб — <strong>+2 к снайперскому делу</strong>. </p><p>На машину Хартмана постоянно садятся и гадят птицы если ты их перестреляешь, то <strong>+2 к снайперскому делу</strong>, если облажаешься, попадешь в машину.</p>	<p>Открытая или крытая площадка на окраине части, оборудована мишенями, укрытиями, смотровой будкой.</p>\n	f	f	\N	\N	3fde77d0-afa5-4343-8535-d6fc4301ef4f	584f6a2a-b5dd-424b-a459-ed291d213995	{}
dba9f3b2-23a3-4973-bbdd-a900c4a6ba3f	1.1.3. Столовая	<p>Повар: “Нужна рыба на кухню. Официально — ‘добыча’, неофициально — чтобы закрыть недостачу и не попасться.” На это выдаются деньги. <strong>+2 универсальных.</strong></p><p></p><p></p>	<p>Просторное помещение с длинными столами, промышленными буфетами, большим кухонным блоком. В зале часто шумно, действует строгий порядок раздачи.&nbsp;</p>\n	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251227_094425_dba9f3b2-23a3-4973-bbdd-a900c4a6ba3f.png	3fde77d0-afa5-4343-8535-d6fc4301ef4f	584f6a2a-b5dd-424b-a459-ed291d213995	{}
c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d	2.1.2 Дом на пригорке	<p>Если игроки выбирают дом на пригорке как место ночлега, они избегают постоянного давления со стороны солдат в штабе, но чаще становятся свидетелями мистики (ночёвки жителей в полях, странные огни, движения на улице).</p>	<p>На пригорке чуть в стороне от деревни стоит небольшой дом. Окна частично заколочены, дверь покосилась, но внутри сухо и относительно чисто. С холма открывается вид на реку, рисовые поля и крыши деревни — отсюда удобно наблюдать за всем, что происходит внизу.</p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251227_094540_c0a5e803-32e9-4aa5-b8c6-dd98bec99b5d.png	01541e3e-e37c-43c1-8920-fc0031824dc7	584f6a2a-b5dd-424b-a459-ed291d213995	{}
edafce06-67b8-4c2c-8ed3-6dec8369486f	2.1.1.3. Тюрьма			f	f	\N	\N	2c5eac95-c1f0-444c-8dec-7cb85753b395	584f6a2a-b5dd-424b-a459-ed291d213995	{}
57f336d1-61b1-4260-8e06-9fddb19a4e87	1.1.2. Казармы	<blockquote><p>Слухи:<br>- Говорят, под БМП на стоянке есть нычка, но только мехвод её «оживляет».</p><ul><li><p>- Кладовщик пьёт чай с корицей — единственный, кто так делает.</p></li></ul></blockquote><p>-</p>	<p>Большое одноэтажное здание с длинными рядами кроватей и запертыми шкафчиками.</p>\n	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251227_094419_57f336d1-61b1-4260-8e06-9fddb19a4e87.png	3fde77d0-afa5-4343-8535-d6fc4301ef4f	584f6a2a-b5dd-424b-a459-ed291d213995	{}
e3b15e52-d0c4-431e-bf6d-633c03b0c3f9	7.2. Диспетчерская погрузчиков			f	f	\N	\N	62af27f3-1376-4d44-b085-910706567134	515d2aaa-768b-4456-a837-bb160cf473a8	{}
01541e3e-e37c-43c1-8920-fc0031824dc7	2. Задание	<p><span style="color: rgb(10, 10, 10); font-size: medium;"><strong>Так вы попали в деревню</strong>.</span> Возвращаясь с задания на вертолетах, вас встретил грозовой фронт. Пилот обращается к вам по рации и с матом говорит, что будет искать площадку, чтоб посадить вертолет. Но вам не везет и под вами расстилаются джунгли и только джунги. Грозовое облако вас настигло и в этот же мемент вы видите рисовые поля, куда и направляете пилота. Вам повезло вы на земле, осталось только прийти в себя после жесткой посадки. Звон в ушах сменяется шумом ливня и треском догорающего вертолета ваших сослуживцев. Они упали в 100 метрах от вас влетев в дерево. Ваш же вертолет на первый взгляд выглядит, как перед началом миссии, разве что его пилот теперь матерится сильнее.</p><p>Через 5 минут прибегают вьетнамцы (2 мужчин и 3 женщин), а еще через 5 прибегают (3 солдата).<br>Под вертолетом 2 трупа вьетнамцев.</p><p></p><p>После приземления<strong> все должны кинуть Атлетику, </strong>чтоб не упасть в рисовые поля. Если игрок упал, то у него<strong> -1 Самообладания</strong>, тк ему кажется, что его потрогал мертвый вьетнамец под водой.</p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251205_125223_01541e3e-e37c-43c1-8920-fc0031824dc7.png	\N	584f6a2a-b5dd-424b-a459-ed291d213995	{}
82b2e48e-4f5a-4260-b360-1c60531ea520	2.1.1.1. Склад (командный пункт) Этаж 1	<p>Это фактический центр власти в деревне: здесь живут и дежурят сержанты и рядовые, отсюда организуется охрана, распределяется оружие и принимаются решения. Подвал используется как тюрьма и место «обработки» тех, кто сопротивляется метаморфозе.</p>	<p>Двух этажное кирпичное колониальное здание.</p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251227_094518_82b2e48e-4f5a-4260-b360-1c60531ea520.png	2c5eac95-c1f0-444c-8dec-7cb85753b395	584f6a2a-b5dd-424b-a459-ed291d213995	{}
1d9a4e14-438f-461e-8dc6-3bc5001680de	2.1.1.2. Склад Этаж 2 (командный пункт) 	<p>Это фактический центр власти в деревне: здесь живут и дежурят сержанты и рядовые, отсюда организуется охрана, распределяется оружие и принимаются решения. Подвал используется как тюрьма и место «обработки» тех, кто сопротивляется метаморфозе.</p>	<p>Двух этажное кирпичное колониальное здание.</p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251227_094523_1d9a4e14-438f-461e-8dc6-3bc5001680de.png	2c5eac95-c1f0-444c-8dec-7cb85753b395	584f6a2a-b5dd-424b-a459-ed291d213995	{}
0f103740-ffce-4b39-b2e7-7b50ff2f9f88	0.2.1. Маркировочный коридор	<p>После первичной сортировки письма идут по длинному <strong>маркировочному коридору</strong>:</p><ul><li><p>ряды столов/станций по обе стороны ленты;</p></li><li><p>каждый стол отвечает за свой критерий:</p><ul><li><p>предполагаемая <strong>ценность подарка</strong> (дёшево/средне/дорого/уникально),</p></li><li><p><strong>масса/объём</strong> (сколько места в мешке займёт),</p></li><li><p><strong>сложность производства</strong> (один цех/несколько цехов, серийное/штучное).</p></li></ul></li></ul><p>Эльфы‑оценщики:</p><ul><li><p>ставят на письма дополнительные штампы и коды:</p><ul><li><p>«массовый стандартный»,</p></li><li><p>«индивидуальный сложный»,</p></li><li><p>«особый случай» и т.п.</p></li></ul></li><li><p>иногда прикалывают служебные стикеры: «нет точного аналога, подобрать замену», «требуется консультация проектировщиков».</p></li></ul><p></p>		f	f	\N	\N	b84a761f-4475-4ab7-88a8-d2ede64740b2	515d2aaa-768b-4456-a837-bb160cf473a8	{}
9e80aac9-18e6-4fd2-a2c5-fa1274359c4a	3 Конференц-зал C-2	<p>Персонажи находят три трупа, включая выпотрошенного ритуального "трапезу" и двух погибших в драке. Важные улики — рюкзаки, в одном из которых (оставленный Кларой Джонс) — расписание и зацепки к её местонахождению. По комнате разбросаны свитки заклинаний на древневавилонском языке.</p>\n	<p>Небольшое помещение внутри комплекса, свет выключен, в комнате беспорядок и следы жутких событий, пол в крови, на брезенте — мистические символы.</p>\n	f	f	\N	\N	a8e63607-dae8-4bfc-a5cf-eaad6a401b08	6dab957a-c992-4e42-a23c-598cb3eb1893	{}
5d67269e-17e7-44dc-9676-14c8de528bd8	1.2. Колорадо-Спрингс	<p>Город по соседству</p>	<p></p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251204_153541_5d67269e-17e7-44dc-9676-14c8de528bd8.png	419a1309-ea5f-4778-8945-5a0e048e9fcd	584f6a2a-b5dd-424b-a459-ed291d213995	{}
bc7da00a-e5de-4cb5-8bb1-112aa4fff024	1 Торговый центр	<p>Неожиданно мимо вас проносится залитый кровью кричащий человек. Толпа расступается, кто‑то даже аплодирует, но вы сразу понимаете - что‑то не так. Вы видели настоящую кровь, и этот мужчина действительно покрыт ею. Вам удаётся догнать его только на крыше торгового центра. Он бормочет и машет на вас руками. Это молодой парень, его борода залита кровью, а на его футболке вы разбираете надпись: «Убивая, не забудь обчистить труп!»</p>\n	<p>Многоэтажное здание, лабиринт коридоров, напичканный толпой LARP-игроков и тематической ярмаркой. Центральная площадка событий — здесь проходит фестиваль.</p>\n	f	f	\N	\N	a8e63607-dae8-4bfc-a5cf-eaad6a401b08	6dab957a-c992-4e42-a23c-598cb3eb1893	{}
a8e63607-dae8-4bfc-a5cf-eaad6a401b08	Фестиваль ролевых игр	<p>Вы гоняетесь по всей стране за рукописью с ритуалом призыва демона. Вам удалось удалить её копии из Интернета, но она продолжает всплывать в самых неожиданных местах. Сейчас вы находитесь на фестивале ролевых игр, проходящем в [любой крупный город], под личиной полицейских или других служителей правопорядка. Согласно легенде, которую знает местное руководство, вы ищете пропавшее произведение искусства. Фестиваль проходит в огромном торговом центре, занимая несколько этажей, опутанных лабиринтом коридоров. Фойе забито толпой, закупающейся на тематической ярмарке. Всё здание просто кишит странными людьми в странных костюмах. И хотя все они говорят на том же языке, что и вы, вам их очень непросто понять.</p>\n	<p></p>\n	f	f	\N	\N	\N	6dab957a-c992-4e42-a23c-598cb3eb1893	{}
8386be19-a500-419f-9d6c-eb88c1737116	2 Крыша торгового центра	<p>Сцена погонь: сюда убегает молодой человек, покрытый кровью. Здесь агенты догоняют его, проводят допрос и выясняют детали происшествия, используя психологическое давление и беседу на тему игр, чтобы вернуть к рациональности.</p>\n	<p>Изолированная, ветреная площадка наверху здания, труднодоступная для большинства посетителей, куда можно попасть только по лестнице или лифту.</p>\n	f	f	\N	\N	a8e63607-dae8-4bfc-a5cf-eaad6a401b08	6dab957a-c992-4e42-a23c-598cb3eb1893	{}
4269f9c9-adbe-4043-84da-ce20bd262ac5	1.3.2. Лес	<p>Чтоб пройти лес насквозь надо прокидывать кубик, иначе ты заблудишься и проведешь много времени в лесу. Если тебя в итоге пойдут искать, то еще и выговор получишь.</p>	<p></p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251205_125055_4269f9c9-adbe-4043-84da-ce20bd262ac5.png	483bf45b-248f-464e-b62b-901692055cf1	584f6a2a-b5dd-424b-a459-ed291d213995	{}
2d8bad06-a5d6-49fe-bc46-5c9a8fb07b79	1.3.1. Ограда	<p>“Пересечь ограду” → успех +2 скрытность (или разведчик), провал +1 и “патруль поднял шум/выговор”</p>	<p>Высокая сетка с колючей проволокой и воротами, обходится патрулем.</p>\n	f	f	\N	\N	419a1309-ea5f-4778-8945-5a0e048e9fcd	584f6a2a-b5dd-424b-a459-ed291d213995	{}
85a5a55a-7964-493d-aa64-9a2b16c0ce39	1.2.2. Рынок	<p>Рынок, тут можно что-то покупать.</p>		f	f	\N	\N	5d67269e-17e7-44dc-9676-14c8de528bd8	584f6a2a-b5dd-424b-a459-ed291d213995	{}
0e2fceb9-de8c-4ecf-a9c5-adeca588665b	1.2.4. Аптека	<p>Тут можно купить медикаменты и химию.</p>		f	f	\N	\N	5d67269e-17e7-44dc-9676-14c8de528bd8	584f6a2a-b5dd-424b-a459-ed291d213995	{}
483bf45b-248f-464e-b62b-901692055cf1	1.3. Местность	<p></p>	<p></p>	f	f	\N	\N	419a1309-ea5f-4778-8945-5a0e048e9fcd	584f6a2a-b5dd-424b-a459-ed291d213995	{}
85376fd3-e098-4497-b51a-9cbaae403f88	1.1.4. Склад	<p>Склад уже есть, но здесь можно усилить акцент на технике и взрывчатке. Это источник:</p><p>учебных взрывчатых средств/муляжей для сапёров;</p><p>деталей и инструментов для механиков;</p><p>социальных сцен с кладовщиком/сторожем («любителем радио» или музыки).</p><p></p>	<p>Сарай или большое помещение, заваленное ящиками, ящичками, коробками с формой, инструментами и непонятным железом. Проходы узкие, в углу стоит стол дежурного кладовщика, рядом висит список выдачи снаряжения.</p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251227_094435_85376fd3-e098-4497-b51a-9cbaae403f88.png	3fde77d0-afa5-4343-8535-d6fc4301ef4f	584f6a2a-b5dd-424b-a459-ed291d213995	{}
24e61179-1f76-4ac8-9e35-0985d0c99d6a	1.2.5. Городской пляж	<p>Пляж</p>	<p></p>	f	f	\N	\N	5d67269e-17e7-44dc-9676-14c8de528bd8	584f6a2a-b5dd-424b-a459-ed291d213995	{}
3dc3b868-dc6c-4b0c-aa23-60aa4f20b08b	1.1.7. Радиоклуб части	<p>Здесь тусуются радисты и один пожилой сержант‑радиолюбитель. Локация — главный хаб для получения очков по радиосвязи/радиотехнике и немного свободных очков за социальное взаимодействие. Через радиоклуб удобно:</p><ul><li><p>- давать тренировочные радиоигры;</p></li><li><p>- устраивать «ночные сеансы»;</p></li><li><p>- подсветить тему радиопомех.</p></li></ul><p></p>	<p>Небольшая комнатка в одном из служебных зданий. На столах — радиоприёмники, паяльники, катушки провода, на стенах висят схемы и плакаты с позывными. В углу стоит старый армейский шкаф с разной техникой, над дверью — самодельная табличка «Радиоклуб».</p><p></p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251227_094455_3dc3b868-dc6c-4b0c-aa23-60aa4f20b08b.png	3fde77d0-afa5-4343-8535-d6fc4301ef4f	584f6a2a-b5dd-424b-a459-ed291d213995	{}
c6e7f6ef-f05d-45b8-8fa8-b2dc9700f58c	1.3.4. Река	<p>Тут можно рыбачить, глушить рыбу динамитом или сплавляться на лодке.</p>	<p></p>	f	f	\N	\N	483bf45b-248f-464e-b62b-901692055cf1	584f6a2a-b5dd-424b-a459-ed291d213995	{}
3fde77d0-afa5-4343-8535-d6fc4301ef4f	1.1. Учебный лагерь	<p>Обучение</p>	<p></p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251226_124922_3fde77d0-afa5-4343-8535-d6fc4301ef4f.png	\N	584f6a2a-b5dd-424b-a459-ed291d213995	{}
fff7633e-ca1c-4416-b6bb-c459414acb6a	1.1.1. Администрация	<p>Тут можно:</p><ul><li><p>подглядеть за начальником (например, с журналом Playboy);</p></li><li><p>занести компромат с пляжа;</p></li><li><p>выпросить «благосклонность» в виде универсальных очков, влияющих на дальнейшее обучение.</p></li></ul><p></p>	<p>Небольшое административное здание с кабинетом начальника части и кучи бумаг. В коридоре всегда кто‑то сидит «на ковре» или ждёт подписей.</p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251227_094403_fff7633e-ca1c-4416-b6bb-c459414acb6a.png	3fde77d0-afa5-4343-8535-d6fc4301ef4f	584f6a2a-b5dd-424b-a459-ed291d213995	{}
6c1b61b2-823f-43f8-a158-e52588ed6aa8	4 Турнирная зона (D&D, игровая площадка фестиваля)	<p>Здесь находится Клара Джонс — обладательница оригинала рукописи и ритуала изгнания демона. Герои подходят к ней для выяснения судьбы артефакта, получения ритуала изгнания, а также вынуждены принять драматическое решение о том, кого "принести в жертву", чтобы уничтожить демона.</p>\n	<p>Открытая зона внутри торгового центра, где проходит турнир по настольным ролевым играм, столы, толпа игроков.</p>\n	f	f	\N	\N	a8e63607-dae8-4bfc-a5cf-eaad6a401b08	6dab957a-c992-4e42-a23c-598cb3eb1893	{}
08c08b86-b2d8-477f-a073-9c78c33f0f5a	2.2.3. Статуя	<p>В глубине искажённых джунглей стоит высокая каменная статуя с размытыми чертами, в которых угадываются щупальца и волны. Она является фокусом влияния К’Тулху в этом районе: искривляет пространство (закольцованная река), создаёт мощные радиопомехи и усиливает шёпоты, которые слышат уже затронутые персонажи. Пока статуя цела, любые сильные радиостанции дают лишь всплески шума и голоса, неразборчивые для игроков. Уничтожение статуи снижает<strong> счётчик дней до эвакуации на 2</strong> и снимает основную помеху, позволяя радисту и механику наладить нормальную связь.<br>Вокруг всегда плотный туман, который глушит звуки, от чего <strong>сапер</strong> может <strong>тихо</strong> взорвать статую.</p>	<p>Между корней деревьев и лиан поднимается каменное изваяние ростом с дом. Его лицо стёрто, но по телу проходят вырезанные линии, похожие на переплетённые щупальца и волнистые узоры. Воздух вокруг статуи тяжёлый и влажный, звук будто глохнет в густом тумане.</p>	f	f	\N	\N	0d199f8e-a306-4722-a1fb-a441caac65fc	584f6a2a-b5dd-424b-a459-ed291d213995	{}
c179df04-8bff-42d0-9222-3a23231a852e	2.2.4. Река	<p>Если попытаться поплыть не на катере, то в какой-то момент тебя перевернет волна (взявшаяся из ниоткуда) и попав в воду ты увидишь 3 утопленных катера на дне.</p>\n	<p><span style="color: rgb(10,10,10);background-color: rgb(255,255,255);font-size: medium;font-family: Inter, "Inter Fallback;">Река абсолютно спокойная, ширина реки 50 м, а может и больше. Не понять, тк много мелких островков с джунглями.</span></p>\n	f	f	\N	\N	7afc0381-b181-42ce-9c83-b32d65e08712	584f6a2a-b5dd-424b-a459-ed291d213995	{}
4552213d-1f7f-4e93-b458-548a38d0f418	2.1.3.1. Катер PBR 31 MK II "Pibber"	<p>Если ты механник и залесть к двигателю, то можно увидеть, что он весь в соли. Чинить ничего не надо, все заводится и так, против всех закнов физики. Радиостанция работает только в пределах километра из-за недостатка мощности, <strong>механик такое может починить</strong>. </p><p>Выплывая на лодке при вождении человеком без навыка надо бросать успешное вождение, иначе лодка попадает в джунгли или пристань. Если выплыть, то через час плутания ты вернешься на место, но заметишь, что рядом в джунглях есть какая-то статуя.</p>	<p>Длина: 9.8 м, ширина: 3.5 м, осадка: 0.6 м, скорость: до 53 км/ч, моторы: 2 по 205 л.с.<br></p>	f	f	\N	\N	7afc0381-b181-42ce-9c83-b32d65e08712	584f6a2a-b5dd-424b-a459-ed291d213995	{}
6da7f6cf-97ad-48bc-bda8-3c0184cce0b3	2.1.4. Дом командира	<p>Дом пустует.  Внутри можно найти старые документы по личному составу, журналы радиосвязи и следы того, что здесь долгое время жил офицер — а потом с ним что‑то случилось. В одной из комнат под брезентом и досками спрятан <strong>M113</strong>, замаскированный под разваливающийся сарай. При тщательном осмотре (или если игроки решат вскрыть запертые помещения) они могут обнаружить труп бывшего командира части или явные следы его насильственной смерти, что подталкивает к мысли о мятеже или культе.</p><p></p>	<p>Дом командира выглядит крепче и солиднее остальных построек, но кажется странно пустым. Внутри пыль, разбросанные бумаги и несколько комнат, словно оставленных в спешке. </p>	f	f	\N	\N	9b07b8de-a319-42b9-875c-146f56213c74	584f6a2a-b5dd-424b-a459-ed291d213995	{}
29bc9a83-1124-430c-9d9d-40aaf25d9d29	1.1.6. Санитарная часть	<p>Запись на курсы доступна, только после успешного флирта с медсестрой.</p>\n	<p>Отдельное здание с белыми стенами, медкроватями, кабинетом главного врача, шкафчиками с медикаментами.&nbsp;</p>\n	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251227_094448_29bc9a83-1124-430c-9d9d-40aaf25d9d29.png	3fde77d0-afa5-4343-8535-d6fc4301ef4f	584f6a2a-b5dd-424b-a459-ed291d213995	{}
2fc56772-6edb-4ee3-b903-f29c2dba1ba3	1.2.3. Магазин радиотехники	<p>Место для городской вылазки и «гражданского» радиоквеста. Игроки могут пытаться купить, выпросить или вытащить детали для своих проектов в части. Сцена хороша для радиста, механика, переговорщика, вора. Даёт как профильные очки, так и свободные.<br>Здесь лежит <strong>схема для прослушки телефона</strong>, если найти для нее детали и собрать<strong> +2 радиотехника</strong>.</p><p></p>	<p>Небольшой магазинчик в Колорадо‑Спрингс. Витрины заставлены радиодеталями, проводами, динамиками, на полках — коробки с лампами, транзисторами и какими‑то загадочными приборами.</p>	f	f	\N	\N	5d67269e-17e7-44dc-9676-14c8de528bd8	584f6a2a-b5dd-424b-a459-ed291d213995	{}
b341a03d-5e6c-4908-84e7-b8d4ed818147	1.4. Линия Б: переплавка	<p>Это линия для всего, что решили не разбирать (слишком опасно, слишком однообразно, уже измельчено и т.п.).</p><p><strong>Станции:</strong></p><ol><li><p><strong>Подача в тигли</strong></p><ul><li><p>большие ковши, ленты, которые сбрасывают материал в плавильные ёмкости.</p></li><li><p>здесь важно только следить за объёмами и соблюдать норму подачи.</p></li></ul></li><li><p><strong>Плавильные печи</strong></p><ul><li><p>огромные ванны с расплавом, температура регулируется магомеханикой.</p></li><li><p>эльфы в очках с бровями и защитной экипировке следят за уровнем, перемешивают, снимают шлак (кат.2 инструменты, тепло‑стойкие крюки).</p></li></ul></li><li><p><strong>Литьё в заготовки</strong></p><ul><li><p>расплав сливают в формы (слитки, брикеты, гранулы).</p></li><li><p>каждый тип ресурса получает свой стандартный вид.</p></li></ul></li><li><p><strong>Охлаждение и маркировка</strong></p><ul><li><p>охлаждённые заготовки маркируют кодами материала и партии.</p></li><li><p>затем отправляют на промежуточный склад.</p></li></ul></li></ol><p><strong>Персонал линии Б:</strong></p><ul><li><p>Плавильщики — эльфы в специальных очках и костюмах, обязаны работать строго по инструкциям.</p></li><li><p>Операторы печей — полу‑техническая роль, следят за показаниями панелей.</p></li><li><p>Надзиратели‑охранники контролируют дисциплину и применение защитных средств.</p></li></ul><p></p>		f	f	\N	\N	e73b35be-cc8c-4482-9fc6-da52a698991a	515d2aaa-768b-4456-a837-bb160cf473a8	{}
18de5043-d847-44b3-bdd5-b404a5d1df84	1.3.5. Горы	<p>Тут можно попробовать добыть динамитом золото, тут есть золото искатели</p>	<p></p>	f	f	\N	\N	483bf45b-248f-464e-b62b-901692055cf1	584f6a2a-b5dd-424b-a459-ed291d213995	{}
c8db4e53-d137-4e8f-8988-f08c44f79afe	1.1. Ресурсный Реактор	<p>само ядро: огромный купол - растрескавшийся инопланетный «двигатель», окружённый слоями защитных полей и металлоконструкций. Никто не управляет тем, что он выдаёт:</p><ul><li><p>периодически из него «выплёвываются» предметы:</p><ul><li><p>игрушки чужих миров, обломки техники, странные монолиты, куски неизвестных биологических масс;</p></li><li><p>иногда - уже частично собранные вещи (оружие, артефакты, непонятные приборы).</p></li></ul></li><li><p>всё это попадает на <strong>главный сортировочный лоток</strong>, откуда уже механикой разбрасывается на рабочие линии.</p></li></ul><p><strong>Прямого физического контакта с ядром нет</strong> - только наблюдение, измерения, отчёты.</p><p></p><p></p>		f	f	\N	\N	e73b35be-cc8c-4482-9fc6-da52a698991a	515d2aaa-768b-4456-a837-bb160cf473a8	{}
f4b53888-2395-48df-91e0-e1c60db9ccc0	1.5. Промежуточный склад сырья	<p>Это узел, где уже стандартизированный ресурс ждёт отправки в другие цеха.</p><p><strong>Зоны склада:</strong></p><ul><li><p>Секторы по типу материала:</p><ul><li><p>металлы (подтипы по маркам),</p></li><li><p>пластики,</p></li><li><p>ткани/волокна (если их тоже перерабатывают),</p></li><li><p>«аномальные» материалы (хранятся отдельно, под замком).</p></li></ul></li><li><p>Площадка отгрузки</p><ul><li><p>рельсовые тележки, палеты, погрузчики;</p></li><li><p>отсюда ресурс уходит в механический и ткацкий цеха, иногда — напрямую в СЦ для спецпроектов.</p></li></ul></li></ul><p><strong>Предметы:</strong></p><ul><li><p>Погрузчики (кат.2), ручные тележки (кат.1).</p></li><li><p>Маркировочные устройства (штампы, печати, клейма).</p></li><li><p>Контейнеры разных размеров с кодами.</p></li></ul><p><strong>Персонал:</strong></p><ul><li><p>Эльфы‑кладовщики (учёт ячеек, маркировка).</p></li><li><p>Погрузчики‑водители (с допуском к кат.2).</p></li><li><p>Один старший склада (ведёт журналы движения, подписывает накладные).</p></li></ul><p></p>		f	f	\N	\N	e73b35be-cc8c-4482-9fc6-da52a698991a	515d2aaa-768b-4456-a837-bb160cf473a8	{}
419a1309-ea5f-4778-8945-5a0e048e9fcd	1. Интро	<p>Игроки в первой части набирают очки специализации через <strong>успешные/неуспешные</strong> действия.</p><p>За успешное действие: +2 очка, за неудачу: +1 очко, при этом очки могут быть либо в конкретную специализацию, либо в «универсальные очки уважения».</p><p>Если к концу первой части у персонажа набрано 5 очков в одном треке, он получает ровно одну специализацию (даже если набрал 5+ в нескольких — выбирает одну).<br>Если несколько игроков учавствуют в действии после чего должны получить очки, то очки делятся поровну или случайно.</p><p><br><strong>Универсальные очки</strong> получаются за каждую <strong>коллективную попойку</strong> (+2 за успешную, +1 если поймали). <br><strong>Саперные очки</strong> за каждое <strong>применение взрывчатки </strong>(+2 за отсутвие последствий для игроков, +1 иначе).<br><strong>Очки разведки</strong> за каждый <strong>акт воровства</strong> (+2 если не поймали, +1 иначе). Считается только проникновение + воровство.<br><strong>Снайперские очки</strong> за <strong>меткую стрельбу</strong> (+2 успешную, +1 иначе). Считается стрельба одиночным выстрелом по сложной цели.</p><p><strong>Очки механика-водителя</strong> за <strong>маневры</strong> при вождении <strong>гусеничной техники</strong> (+2 без поломок и непреднамеренных повреждений, +1 иначе).</p><p><strong>Очки радиста</strong> за <strong>настройку/ремонт/сборку/прослушку/связь</strong> (+2 если удалось получить рабочий сигнал/результат, +1 иначе).<br><strong>Очки полевого</strong> медика за <strong>использования медикаментов на других людях</strong> (не игроках) для достижения своей цели (+2 успешно, +1 иначе).</p>	<p></p>\n	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251204_153625_419a1309-ea5f-4778-8945-5a0e048e9fcd.png	\N	584f6a2a-b5dd-424b-a459-ed291d213995	{}
30278575-71e6-4fc9-b4c0-5bc9c4489142	1.2. Зал выпадения	<p>Помещение вокруг ядра:</p><ul><li><p>несколько уровней галерей, откуда видно зону выпадения;</p></li><li><p>основной приёмный конвейер, куда падают артефакты;</p></li><li><p>датчики, которые:</p><ul><li><p>грубо классифицируют объект по материалу (металл/органика/разное);</p></li><li><p>отбрасывают особо опасное сразу в обратно в реактор.</p></li></ul></li></ul><p>Здесь работают <strong>приёмщики артефактов</strong>:</p><ul><li><p>их задача — не оценивать, «что это», а убедиться, что каждый объект ушёл по одному из двух направлений:</p><ul><li><p>на линию распила/разбора;</p></li><li><p>на линию переплавки (если явно нецелесообразно разбирать поштучно).</p></li></ul></li></ul><p></p>		f	f	\N	\N	e73b35be-cc8c-4482-9fc6-da52a698991a	515d2aaa-768b-4456-a837-bb160cf473a8	{}
bf2dd9d9-8001-44f1-85e3-86d61720509f	2. Механический цех	<p>Здесь из полуфабрикатов делают формы будущих игрушек: корпуса, шестерёнки, рамы, детали.</p><p><strong>Как выглядит:</strong></p><ul><li><p>Ряды станков и магических прессов, где эльфы выполняют точные однообразные операции.</p></li><li><p>На магическом экране перед рабочим местом — строго пошаговая анимация движения: «Возьми деталь → вставь в паз → поверни до значка». Нет ни слова о том, что это за деталь.</p></li><li><p>Каждый станок оборудован датчиками: он «знает», есть ли в руках у эльфа нужный инструмент и имеет ли тот право его использовать.</p></li><li><p><strong>Инструменты и процесс:</strong></p><ul><li><p>Набор высокоспециализированных инструментов 1 категории: ключи-форматоры, калибраторы, магические отвёртки.</p></li><li><p>Утрата или поломка: та же схема — руки вверх, глаза закрыты, досмотр, заявка.</p></li><li><p>Заявка заполняется в бюрократическом кабинете: описать тип инструмента, объяснить, что произошло. После этого конвейер настраивается так, как будто этого поста временно нет.</p></li></ul><p><strong>Магия и супервизоры:</strong></p><ul><li><p>Для «нестандартных» операций (например, поднимать слишком тяжёлую деталь, работать в зоне сверхтемператур) требуется особое разрешение на магию.</p></li><li><p>Эльф пишет аналитическую записку: «в таком-то процессе, на таком-то шаге, стандартных инструментов недостаточно → предлагается использовать заклинание X, влияющее на Y».</p></li><li><p>Супервизор (охранник‑маги) рассматривает её, задаёт вопросы; если одобряет, оформляет временное разрешение. Если нет — отправляет «на защиту» в бухгалтерию</p></li></ul></li></ul><p></p>		f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_105004_bf2dd9d9-8001-44f1-85e3-86d61720509f.png	8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	515d2aaa-768b-4456-a837-bb160cf473a8	{}
bf1322cc-c72d-4e07-858c-59f7caa78287	2.3. Линия сборки устройств	<p>Функция: из комплектующих собрать конечные механические штуки — от детских машинок до корпусов инструментов, баз роботов‑Сант, оснастки для других цехов.</p><h2>Помещения и станции</h2><ul><li><p>Зал предварительной сборки модулей</p><ul><li><p>На рабочих столах собирают подузлы:</p><ul><li><p>редукторы, шарнирные блоки, блоки крепления, каретки.</p></li></ul></li><li><p>Инструменты: в основном кат.1 (отвёртки, ключи, пассатижи), иногда кат.2 (механические отвёртки, шуруповёрты).</p></li></ul></li><li><p>Основной конвейер сборки девайсов</p><ul><li><p>Лента, по которой двигаются ещё «безликие» устройства.</p></li><li><p>На каждом посту эльф делает один шаг (прикрутить деталь, вставить модуль, проверить ход).</p></li><li><p>Экраны показывают только руки и детали, общая форма часто неочевидна до конца линии.</p></li></ul></li><li><p>Участок интеграции с другими цехами</p><ul><li><p>Места, где в механические девайсы вставляются текстильные элементы (из ТЦ) или интерфейсы под будущие электронные/магические блоки (если они будут где‑то ещё).</p></li><li><p>Тут появляются вещи, похожие на готовые игрушки: машинки с шасси, куклы со скелетом, оболочки для роботов.</p></li></ul></li><li><p>Тестовый пост механики</p><ul><li><p>Проверка хода, прочности, базовой функциональности (крутится ли, ездит ли, открывается ли).</p></li><li><p>Некий минимальный «качественный фильтр» перед отправкой в СЦ.</p></li></ul></li></ul><h2>Персонал</h2><ul><li><p>Сборщики‑конвейерщики.</p></li><li><p>«Модулисты» — эльфы, отвечающие за один тип узла.</p></li><li><p>Мастер сборочной линии (следит за тактом, переназначает рабочих).</p></li></ul><p></p>		f	f	\N	\N	bf2dd9d9-8001-44f1-85e3-86d61720509f	515d2aaa-768b-4456-a837-bb160cf473a8	{}
9b07b8de-a319-42b9-875c-146f56213c74	2.1. Деревня	<p>Часть жителей уже мутировала: у них появляются жабры, припухшие веки, странно блестящие глаза, тянущиеся к воде привычки. Остальные — на разных стадиях, что можно показать через мелкие детали (они слишком долго держат руки в воде, облизывают кристаллы соли, сторожат колодец). Можно найти дорогу к <strong>Дому Командира</strong>, где спрятан M113. Жители никогда не ведут себя полностью «нормально»: слишком долго держат руки в воде, облизывают кристаллы соли, смотрят чуть мимо собеседника, иногда молча замирают посреди фразы. При любых социальных сценах подчёркивай лёгкую неуместность их реакций — будто они пытаются копировать обычных людей и иногда забывают, как это делается.</p><p>(Мастер: при первом обычном взгляде — просто тёмная вода и запах сырости. При более длительном всматривании, особенно у персонажей с уже сниженным счётчиком, можно дать слабые шёпоты, отражения, которые двигаются с задержкой, или руку, мелькнувшую в глубине. Это хороший триггер для сдвига счётчика превращения и ночных кошмаров.)</p><p></p>	<p>Деревня — десяток низких одноэтажных домов из дерева и кирпича, крыши из жести и пальмовых листьев. В центре — колодец, вокруг которого днём всегда кто‑то толпится. </p>	f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/location/map/20251205_125200_9b07b8de-a319-42b9-875c-146f56213c74.png	01541e3e-e37c-43c1-8920-fc0031824dc7	584f6a2a-b5dd-424b-a459-ed291d213995	{}
245f4b87-27cb-4592-9006-15ae75b7d95f	1.3. Линия А	<p>Это линия для всего, что ещё можно разобрать на детали перед finалкой.</p><p><strong>Станции:</strong></p><ol><li><p><strong>Пост первичного осмотра</strong></p><ul><li><p>эльфы быстро смотрят на форму/структуру:</p><ul><li><p>если есть потенциально полезные узлы (механика, крепления, необычный материал) — отправляют на детальный разбор;</p></li><li><p>если это просто «глыба мусора» — метят на прямую переплавку.</p></li></ul></li><li><p>инструменты: ломики, молотки, простые пилы, метки‑мелки (категория 1).</p></li></ul></li><li><p><strong>Пост грубого разлома</strong></p><ul><li><p>использование пил, кувалд, ручных прессов (кат.1 и немного кат.2);</p></li><li><p>задача — разломать объект на куски, удобные для сортировки.</p></li></ul></li><li><p><strong>Пост тонкого распила и вскрытия</strong></p><ul><li><p>ножовки, резаки, ручные дрели, иногда небольшие стационарные пилы (кат.2 по бумаге).</p></li><li><p>здесь отбирают:</p><ul><li><p>пригодные пластины, балки, корпуса;</p></li><li><p>непонятные, но «интересные» куски, отправляемые на отдельный контроль.</p></li></ul></li></ul></li><li><p><strong>Пост сортировки фракций</strong></p><ul><li><p>каждый элемент кладут в соответствующие контейнеры: «металл», «пластик», «композит», «органика», «аномальное».</p></li><li><p>органику почти всегда отправляют в плавильные печи/ядро позже.</p></li></ul></li></ol><p><strong>Персонал линии А:</strong></p><ul><li><p>Рабочие‑ломщики (кат.1 инструмент) — масса эльфов, постоянный тяжёлый физический труд.</p></li><li><p>Рабочие‑резчики (кат.2 инструмент) — те, у кого есть разрешение на стационарные пилы и резаки.</p></li><li><p>Один‑два старших смены, которые подписывают акты о «рациональной утилизации».</p></li></ul><p></p>		f	f	\N	\N	e73b35be-cc8c-4482-9fc6-da52a698991a	515d2aaa-768b-4456-a837-bb160cf473a8	{}
18988cd9-ecd4-42ff-b67b-88b437d65526	2.1. Линия деталей	<p>Функция: превратить сырьё из РР в стандартизированные элементы — винты, шестерни, оси, корпуса, рычаги.</p><h2>Помещения и станции</h2><ul><li><p>Зал резки и формовки заготовок</p><ul><li><p>Пилы, прессы, штампы (кат.1 и кат.2), из слитков и брусков режут базовые формы: полосы, кубики, прутки.</p></li><li><p>Экраны показывают только схему движения: «положи → задвинь → отведи руку».</p></li></ul></li><li><p>Участок токарных и сверлильных станков</p><ul><li><p>Здесь делают винты, оси, отверстия, резьбу.</p></li><li><p>Инструменты 2 категории: стационарные станки, дрели, фрезы, упорные приспособления.</p></li><li><p>Эльфы закреплены за конкретными станками, номер и браслет привязаны к профилю станка.</p></li></ul></li><li><p>Участок штамповки и гибки</p><ul><li><p>Прессы делают шестерёнки, скобы, кронштейны, корпуса.</p></li><li><p>Процесс максимально автоматизирован, но запуск/остановка пресса привязана к действиям эльфа по инструкциям.</p></li></ul></li><li><p>Контроль размеров и сортировка деталей</p><ul><li><p>Измерительные посты с шаблонами и калибрами.</p></li><li><p>Здесь отделяют годные детали от брака (брак обратно в РР или в переплав).</p></li></ul></li></ul><h2>Персонал</h2><ul><li><p>Рабочие‑станочники (кат.1+2).</p></li><li><p>Мастера‑наладчики (могут менять режимы станков по приказам сверху).</p></li><li><p>Один‑два контролёра размеров на смену.</p></li></ul><p></p>		f	f	\N	\N	bf2dd9d9-8001-44f1-85e3-86d61720509f	515d2aaa-768b-4456-a837-bb160cf473a8	{}
872d9572-f00f-4dc8-80a4-324838c7b560	2.2. Промежуточный склад комплектующих	<p>Это «промежуточная кровь» МЦ: всё, что произведено на первой линии, идёт сюда, прежде чем попадёт на сборку.</p><h2>Зоны склада</h2><ul><li><p>Секция стандартных мелких деталей</p><ul><li><p>Ячейки с чёткой маркировкой: винты по длине/диаметру, шестерёнки по модулю, оси по длине.</p></li><li><p>Доступ по принципу «возьми‑верни по накладной».</p></li></ul></li><li><p>Секция корпусов и рам</p><ul><li><p>Крупные элементы: корпуса игрушек, рамы для инструментов, платформы для роботов‑Сант.</p></li><li><p>Хранятся на стеллажах и палетах.</p></li></ul></li><li><p>Секция «нестандартных деталей»</p><ul><li><p>Короткие партии необычных элементов: спецкрепления, шарниры с ограниченным ходом, детали для экспериментальных устройств.</p></li><li><p>Закрывается на замок, доступ только по отдельным бумагам.</p></li></ul></li><li><p>Площадка отгрузки на линию сборки</p><ul><li><p>Погрузчики и тележки переносят комплекты деталей на вторую линию.</p></li><li><p>Каждая партия сопровождается накладной: что именно и для какого изделия.</p></li></ul></li></ul><h2>Персонал и предметы</h2><ul><li><p>Кладовщики‑учётчики.</p></li><li><p>Погрузчики‑водители (кат.2, иногда с доступом к простым ридам/тележкам‑автоматам).</p></li><li><p>Маркировочные устройства, накладные, стеллажи, погрузчики, палеты.</p></li></ul><p></p>		f	f	\N	\N	bf2dd9d9-8001-44f1-85e3-86d61720509f	515d2aaa-768b-4456-a837-bb160cf473a8	{}
69668981-68c6-4124-abff-175fe315db03	3.1. Зал ткацких станков 	<h2>Зал ткацких станков</h2><ul><li><p>Ряды станков, которые из волокон делают полотно.</p></li><li><p>Эльфы следят за натяжением, цветом и плотностью ткани, реагируют, если нитка рвётся или ткань идёт с браком.</p></li><li><p>На стенах — образцы допустимых тканей: от грубых мешков до мягкого плюша.</p></li></ul><p>Интерес:</p><ul><li><p>доступ к рулонам разных свойств (толщина, тепло, цвет),</p></li><li><p>возможность «случайно» изменить цвет/рисунок партии (под будущую маскировку).</p></li></ul><p></p>		f	f	\N	\N	73aaf7df-86f7-4cea-aaa5-5b92cb0135f2	515d2aaa-768b-4456-a837-bb160cf473a8	{}
4af1dceb-fa00-46fc-a4f0-2b2472a4efec	3.3. Участок отделки и украшений	<h2>Участок отделки и украшений</h2><ul><li><p>Здесь делают банты, вышивку, декоративные элементы, нашивки с символикой Санты и цехов.</p></li><li><p>Часто именно тут в последний момент наносится «идеологический слой» — логотипы, лозунги.</p></li></ul><p>Интерес:</p><ul><li><p>отличное место, чтобы внедрять тайные знаки и «код» в вышивку или рисунок;</p></li><li><p>можно подменять нашивки, меняя визуальный статус персонажей (например, сделать «почётного» или наоборот «штрафника»).</p></li></ul><p></p>		f	f	\N	\N	73aaf7df-86f7-4cea-aaa5-5b92cb0135f2	515d2aaa-768b-4456-a837-bb160cf473a8	{}
5d87416d-86f2-4502-9aa6-11069ec37184	3.2. Швейно‑сборочный зал 	<h2>Швейно‑сборочный зал</h2><ul><li><p>Столы и швейные машины, где:</p><ul><li><p>шьют оболочки для мягких игрушек,</p></li><li><p>делают элементы униформы,</p></li><li><p>собирают чехлы для коробок/саней.</p></li></ul></li><li><p>Эльфы часто работают двоём‑втроём над одной деталью.</p></li></ul><p>Инструменты:</p><ul><li><p>ножницы, напёрстки, иглы, мелкие ножички (кат.1).</p></li><li><p>Местами — полуавтоматические швейные машины (кат.2, по бумаге).</p></li></ul><p>Интерес:</p><ul><li><p>много мест, куда можно зашить тайники, заметки, мелкие предметы;</p></li><li><p>возможность поменять элементы формы (значки, полосы, нашивки), влияя на статус и доступ.</p></li></ul><p></p>		f	f	\N	\N	73aaf7df-86f7-4cea-aaa5-5b92cb0135f2	515d2aaa-768b-4456-a837-bb160cf473a8	{}
b372dcb9-afc5-47ea-b853-e3d215fda5d1	4.1. Зона приёма с цехов	<p>Сюда сходятся конвейеры и тележки из МЦ, ТЦ и других сборочных участков.</p><ul><li><p><strong>Пункты входного контроля</strong></p><ul><li><p>Проверяют: целостность упаковки, соответствие накладным, отсутствие явного брака.</p></li><li><p>Рабочие сверяют коды на коробках с планами смены и заказов.</p></li></ul></li><li><p><strong>Буферные ленты и карманы</strong></p><ul><li><p>Если поток слишком большой, часть коробок временно задерживается на боковых лентах.</p></li><li><p>Здесь можно «подловить» груз, который ещё не ушёл на главный круг.</p></li></ul></li></ul><p>Персонал: приёмщики, контролёры, несколько охранников для досмотра и пресечения самовольного вскрытия коробок.</p>		f	f	\N	\N	1a70b648-d9c2-45d6-ba34-0d84e8fec34c	515d2aaa-768b-4456-a837-bb160cf473a8	{}
5dd8cfd1-68c6-4419-a444-7f5a97c5afe9	4.2. Главный круговой конвейер	<p>Сердце центра — широкий круговой конвейер, по которому непрерывно движутся коробки с товарами.</p><ul><li><p>Вдоль окружности стоят <strong>станции отбора</strong>, каждая связана с радиальной линией укомплектования.</p></li><li><p>На экранах у каждой станции отображается:</p><ul><li><p>какие товары и в каком количестве нужны для текущих мешков на её радиальной линии;</p></li><li><p>какие коробки с нужным содержимым сейчас приближаются (по фото и кодам).</p></li></ul></li></ul><p>Эльфы‑операторы:</p><ul><li><p>следят за потоком;</p></li><li><p>по сигналу снимают нужную коробку с круга и передают на свою радиальную линию;</p></li><li><p>не имеют права самовольно вскрывать коробку до появления команды на их локальном экране.</p></li></ul><p>Интерес для игры: круговой конвейер даёт постоянный поток «случайных возможностей» — нужная коробка может проскочить мимо, если не успели; можно намеренно пропустить или взять «лишнее».</p>		f	f	\N	\N	1a70b648-d9c2-45d6-ba34-0d84e8fec34c	515d2aaa-768b-4456-a837-bb160cf473a8	{}
a0f370f3-788d-45a5-895e-8dbef697efa1	4.3. Радиальные линии укомплектования мешков	<p>От круга радиально расходятся линии, каждая из которых отвечает за формирование определённых мешков.</p><h2>Участок распаковки и раскладки</h2><ul><li><p>Здесь эльфы открывают коробки (по команде системы), раскладывают содержимое по лоткам:</p><ul><li><p>по типам товаров (игрушки, инструменты, одежда, сладости);</p></li><li><p>по «профилям» заказов (для какого возраста, региона, особых категорий).</p></li></ul></li></ul><p>Инструменты: ножи, ножницы (кат.1), иногда маленькие механизированные резаки (кат.2 по бумаге).</p><h2>Столы комплектования мешков</h2><ul><li><p>На каждом столе лежит несколько полупустых мешков — каждый соответствует одному адресу/заказу или группе заказов.</p></li><li><p>Экраны показывают:</p><ul><li><p>список того, что ещё нужно доложить в каждый мешок;</p></li><li><p>какие изделия уже учтены системой.</p></li></ul></li></ul><p>Эльфы‑комплектовщики:</p><ul><li><p>берут товар из лотков, кладут в мешок, отмечают это на панели;</p></li><li><p>должны строго следовать списку, не имея права «доложить от себя».</p></li></ul><p>Интерес:</p><ul><li><p>именно здесь можно «подсадить» в мешок что‑то лишнее (игрушку‑артефакт, инструмент, бумагу);</p></li><li><p>или наоборот — вынуть и спрятать, если знать, где и как.</p></li></ul><h2>Узел закрытия и первичной маркировки мешков</h2><ul><li><p>Когда мешок набран, его:</p><ul><li><p>затягивают специальной лентой/нитями;</p></li><li><p>снабжают первичным кодом (идентификатор содержимого и назначения).</p></li></ul></li><li><p>Далее мешки уходят по отдельной ветке в зону маркировки и фотографирования.</p></li></ul><p></p>		f	f	\N	\N	1a70b648-d9c2-45d6-ba34-0d84e8fec34c	515d2aaa-768b-4456-a837-bb160cf473a8	{}
31170ad7-64e1-4481-bc9c-2b3f3cea7a5b	4.4. Узел маркировки и фотографирования	<p>Здесь каждому мешку придают окончательную «личность».</p><ul><li><p><strong>Станции фотографирования мешков</strong></p><ul><li><p>Камеры/магические глаза снимают мешок с разных сторон.</p></li><li><p>Изображение привязывается к его коду и манифесту.</p></li></ul></li><li><p><strong>Посты назначения</strong></p><ul><li><p>Терминалы, где мешок получает:</p><ul><li><p>указание точки назначения (регион, город, иногда конкретный адрес);</p></li><li><p>пометку о типе рейса (сани, подлодка, спецдоставка);</p></li><li><p>приоритет (обычный, срочный, особый).</p></li></ul></li></ul></li></ul><p>Рабочие‑маркировщики:</p><ul><li><p>следят, чтобы код, фото и реальные признаки мешка совпадали;</p></li><li><p>вносят корректировки по приказам Планового отдела или ЦП.</p></li></ul><p>Интерес:</p><ul><li><p>если получить доступ к этим терминалам/станциям, можно изменить:</p><ul><li><p>куда мешок реально отправится;</p></li><li><p>как он будет идентифицироваться на ЦО;</p></li><li><p>с каким рейсом его свяжут.</p></li></ul></li></ul><p></p>		f	f	\N	\N	1a70b648-d9c2-45d6-ba34-0d84e8fec34c	515d2aaa-768b-4456-a837-bb160cf473a8	{}
91030495-d866-443c-a215-5910109f0c93	4.5. Административный блок СЦ	<h2>Планово‑маршрутный отдел</h2><ul><li><p>Комнаты с картами маршрутов, таблицами рейсов, списками отправок.</p></li><li><p>Сотрудники определяют:</p><ul><li><p>сколько мешков и каких типов пойдёт на каждый рейс;</p></li><li><p>какие рейсы объединять, какие отменять или задерживать.</p></li></ul></li></ul><p>Бланки:</p><ul><li><p>СЦ‑МАР‑1 — приказ о формировании рейса (состав, маршрут, сроки).</p></li><li><p>СЦ‑КОР‑2 — корректировка маршрута/приоритета (перенос мешков между рейсами).</p></li></ul><p>Интерес:</p><ul><li><p>завладев такими приказами, можно легально «перенаправить» целый набор мешков.</p></li></ul><h2>Бюро манифестов и отчётности</h2><ul><li><p>Здесь составляют и хранят:</p><ul><li><p>манифесты каждой отправки (список мешков, краткое описание содержимого, коды);</p></li><li><p>сводные отчёты о выполнении планов (сколько отправлено, куда, с какими задержками).</p></li></ul></li></ul><p>Архив:</p><ul><li><p>папки/книги с прошлыми манифестами;</p></li><li><p>отдельные полки для «особых рейсов».</p></li></ul><p>Интерес:</p><ul><li><p>можно найти рейсы с особыми условиями (секретные, военные, служебные), под которые проще маскироваться;</p></li><li><p>есть шанс заметить несостыковки, если кто‑то уже тайно чудит в маршрутах.</p></li></ul><h2>Бюро заявок на тестирование и рекламации</h2><ul><li><p>Принимает запросы на:</p><ul><li><p>тестирование продукции (служебные прогоны, проверки качества);</p></li><li><p>внутренние возвраты (если где‑то по пути выявили брак);</p></li><li><p>спецпоставки для других цехов (образцы, демонстрационные наборы).</p></li></ul></li></ul><p>Интерес:</p><ul><li><p>через этот бюро можно добиться, чтобы конкретный тип товара или конкретные мешки вернулись/задержались;</p></li><li><p>можно оформить «служебный тест» для партии, которая важна игрокам.</p></li></ul><h2>Комната отдыха охраны СЦ</h2><ul><li><p>Обычный для твоей фабрики уголок: столы, стулья, сигареты, алкоголь.</p></li><li><p>На доске могут висеть:</p><ul><li><p>«особо подозрительные» номера эльфов;</p></li><li><p>маршруты, где чаще всего «происходят ошибки» (в глазах охраны — саботаж).</p></li></ul></li></ul><p>Интерес:</p><ul><li><p>источник слухов о проблемных рейсах и проверках;</p></li><li><p>место, где можно подслушать, как охрана собирается усилить контроль.</p></li></ul><p></p>		f	f	\N	\N	1a70b648-d9c2-45d6-ba34-0d84e8fec34c	515d2aaa-768b-4456-a837-bb160cf473a8	{}
d61cf43a-f550-40f9-ad80-12f0e6d19180	5.1. Зона приёма мешков	<p>Это «ворота» между СЦ и аэродромом.</p><ul><li><p>Пандусы/порталы, по которым мешки приходят со склада ожидания СЦ (тележки, погрузчики, конвейеры).</p></li><li><p><strong>Пост входного сканирования</strong>:</p><ul><li><p>сверяет коды мешков и их назначение с манифестами рейсов;</p></li><li><p>всё, что не бьётся, отправляет в сторону на дополнительную проверку.</p></li></ul></li></ul><p>Персонал:</p><ul><li><p>кладовщики ЦО,</p></li><li><p>элитные погрузчики,</p></li><li><p>охрана, которая проверяет, чтобы никто не «прыгнул» вместе с мешками.</p></li></ul><p>Интерес:</p><ul><li><p>здесь можно подменить мешок между рейсами, если хотя бы на минуту отвлечь операторов;</p></li><li><p>можно попытаться въехать в ЦО на тележке с грузом, если есть правильные бумаги и маскировка.</p></li></ul><p></p>		f	f	\N	\N	aced96f1-0caa-4214-8eb8-1b835753e380	515d2aaa-768b-4456-a837-bb160cf473a8	{}
7dcf74e6-e9bf-415c-bd4f-3a1fcfc440e0	5.2. Основной ангар саней	<p>Гигантский зал, где:</p><ul><li><p>в ряд или по кругу стоят сани разных типов:</p><ul><li><p>малые (для локальных доставок),</p></li><li><p>стандартные (основные рейсы),</p></li><li><p>крупные (массовая доставка или спецрейсы);</p></li></ul></li><li><p>каждая упряжка с оленями (живыми или магическими) закреплена за конкретным комплектом саней и роботом‑Сантой.</p></li></ul><h2>Площадки погрузки</h2><p>У каждого дока:</p><ul><li><p><strong>рампа</strong> для погрузчиков и рабочих,</p></li><li><p>крюки, направляющие, системы фиксации мешков,</p></li><li><p>экран/панель, где видно:</p><ul><li><p>список мешков для этого рейса;</p></li><li><p>текущее состояние загрузки;</p></li><li><p>таймер до контрольного времени вылета.</p></li></ul></li></ul><p>Рабочие‑погрузчики:</p><ul><li><p>принимают мешки из зоны приёма;</p></li><li><p>раскладывают их по отсекам саней согласно плану;</p></li><li><p>подтверждают загрузку на панели.</p></li></ul><p>Интерес:</p><ul><li><p>можно «подсадить» себя или объект в тот отсек, который в норме никто не открывает до места назначения;</p></li><li><p>можно намеренно «забыть» мешок или переложить его на соседние сани.</p></li></ul><h2>Техзоны ангара</h2><ul><li><p>запасы «чуда‑топлива» для саней,</p></li><li><p>ремкомплекты для упряжей и креплений,</p></li><li><p>инструменты кат.2 для мелкого ремонта (но под учётом и бумагами).</p></li></ul><p></p>		f	f	\N	\N	aced96f1-0caa-4214-8eb8-1b835753e380	515d2aaa-768b-4456-a837-bb160cf473a8	{}
ef06941a-5724-4be8-9103-04e4942e9da7	5.3. Зал роботов‑Сант и обслуживание	<p>Отдельный зал, примыкающий к ангару.</p><ul><li><p>Ряды док‑станций, где стоят роботы‑Санты:</p><ul><li><p>без мешков, с отключёнными лицами;</p></li><li><p>подключённые к калибровочным терминалам.</p></li></ul></li></ul><p>Функция:</p><ul><li><p>загрузка в них маршрутных программ,</p></li><li><p>тесты механики (подъём мешков, шаг, реакция),</p></li><li><p>плановый ремонт.</p></li></ul><p>Персонал:</p><ul><li><p>техники‑механики (часто переходят сюда из МЦ),</p></li><li><p>операторы программ/маршрутчиков (связаны с СЦ и ЦП).</p></li></ul><p>Интерес:</p><ul><li><p>здесь можно вмешаться в поведение робота (например, заставить его сойти с маршрута или «ошибиться» в точке разгрузки);</p></li><li><p>можно попытаться переадресовать его «обратный путь» (вместо возвращения на фабрику увести куда‑то ещё).</p></li></ul><p></p>		f	f	\N	\N	aced96f1-0caa-4214-8eb8-1b835753e380	515d2aaa-768b-4456-a837-bb160cf473a8	{}
b826a78d-d7e8-4093-9f5a-c942ca01eee2	5.4. Диспетчерская и узел маршрутов	<p>Над ангаром или в отдельной башне — мозг ЦО.</p><ul><li><p><strong>Панорамная диспетчерская</strong> с окнами на взлётные полосы;</p></li><li><p>пульты, на которых отображаются:</p><ul><li><p>все текущие и плановые рейсы;</p></li><li><p>состояние погоды/магического фона;</p></li><li><p>статус каждой упряжки и робота.</p></li></ul></li></ul><p>Здесь работают:</p><ul><li><p>диспетчеры‑эльфы (строго отобранные, с высоким «доверительной» оценкой);</p></li><li><p>старший смены, который даёт «добро на взлёт».</p></li></ul><p>Функции:</p><ul><li><p>назначение точного времени взлёта;</p></li><li><p>финальная привязка рейса к конкретным саням, пилоту (если не только роботы), полосе и маршруту;</p></li><li><p>экстренные изменения (задержка рейса, отмена, перенаправление).</p></li></ul><p>Интерес:</p><ul><li><p>если получить доступ к терминалам маршрутов, можно:</p><ul><li><p>переназначить рейс на другие сани;</p></li><li><p>изменить часть пути (например, добавить «промежуточную точку» побега);</p></li><li><p>«потерять» один рейс в общей массе.</p></li></ul></li></ul><p>Это, конечно, вершина риска: охрана и контроль здесь максимальные.</p>		f	f	\N	\N	aced96f1-0caa-4214-8eb8-1b835753e380	515d2aaa-768b-4456-a837-bb160cf473a8	{}
a8d99059-1f6a-4549-bbe3-8fe213f60313	5.5. Контрольный пост и безопасность	<p>ЦО — самый охраняемый участок завода.</p><ul><li><p><strong>Контрольные ворота персонала</strong></p><ul><li><p>все, кто входит/выходит, проходят через:</p><ul><li><p>сканеры браслетов;</p></li><li><p>проверку номера;</p></li><li><p>дыхательную авторизацию для охранников.</p></li></ul></li></ul></li><li><p><strong>Посты вокруг полос и ангара</strong></p><ul><li><p>охранники с правом немедленного применения наказаний;</p></li><li><p>системы мгновенного оповещения (если кто‑то пытается попасть на полосу без доступа).</p></li></ul></li></ul><p>Интерес:</p><ul><li><p>любые попытки проникнуть сюда «как рабочий» требуют идеальной формы, номера, браслета и документов;</p></li><li><p>более реалистичный путь — через официальное назначение:</p><ul><li><p>погрузчик,</p></li><li><p>техник МЦ, переведённый в ЦО,</p></li><li><p>испытатель/тестировщик саней.</p></li></ul></li></ul><p></p>		f	f	\N	\N	aced96f1-0caa-4214-8eb8-1b835753e380	515d2aaa-768b-4456-a837-bb160cf473a8	{}
a1191e5a-8404-4b8d-acf5-727e929b1df7	0.1. Гора писем и конвейеры	<p>Вход в центр — зал, где письма со всего мира падают в одну гигантскую «снеговую» кучу.</p><ul><li><p>Огромный цилиндрический или амфитеатровый зал, в центре — гора конвертов, открыток, рисунков.</p></li><li><p>Сверху — отверстия/«дыры в небе», из которых сыплются новые письма (почта, магия, трубопроводы).</p></li><li><p>Внизу от основания горы расходятся <strong>несколько приёмных конвейеров</strong>, на которые письма скатываются и начинают движение.</p></li></ul><p>Вдоль конвейеров стоят <strong>первичные сортировщики‑эльфы</strong>:</p><ul><li><p>их задача — быстро:</p><ul><li><p>снять конверт,</p></li><li><p>машинально прочитать ключевые слова,</p></li><li><p>пометить его базовыми маркерами: возраст, тип желания (игрушки, одежда, еда, «особые просьбы»), страна/регион.</p></li></ul></li><li><p>Маркировка делается штампами, цветными значками, иногда — быстрым «переписыванием» ключевых фраз на служебный бланк.</p></li></ul><p></p>		f	f	\N	\N	257a2632-3a25-4716-9ae8-444346e8b369	515d2aaa-768b-4456-a837-bb160cf473a8	{}
1c222f3d-4fab-4df6-a2a9-a81681fef240	0.2.2. Архивы оценки «достоинства»	<p>Дальше письма отправляются в <strong>зону архивов</strong>, где решается, насколько ребёнок заслуживает желаемое.</p><h2>Зал досье</h2><ul><li><p>Стены завалены шкафами и картотеками.</p></li><li><p>На каждого ребёнка — карточка/папка с:</p><ul><li><p>именем, адресом,</p></li><li><p>историей прошлых лет (получал/не получал, жалобы, «послушность»),</p></li><li><p>пометками о поведении (из других магических систем наблюдения Санты — «он видит всё»).</p></li></ul></li></ul><p>Эльфы‑архивариусы:</p><ul><li><p>находят нужное досье по данным из письма;</p></li><li><p>сверяют пожелание с «профилем ребёнка»:</p><ul><li><p>если ребёнок идеальный по стандартам Санты — письмо получает высокий приоритет;</p></li><li><p>если «спорный» или из списка «штрафников» — на письме появляются пометки о сокращении/изменении подарка;</p></li><li><p>если совсем «непослушный» — на письмо ставят особую отметку (например, «уголь» или «воспитательная мера»).</p></li></ul></li></ul><h2>Хранилище решений</h2><p>После обработки в досье на письме появляются:</p><ul><li><p>код уровня «достоинства» (от «максимум» до «минимум/наказание»),</p></li><li><p>ссылки на доп. указания (например, «заменить дорогой подарок на более дешёвый аналог»).</p></li></ul><p>Письма с этими кодами едут дальше — в <strong>вердиктный зал</strong>.</p>		f	f	\N	\N	b84a761f-4475-4ab7-88a8-d2ede64740b2	515d2aaa-768b-4456-a837-bb160cf473a8	{}
0d199f8e-a306-4722-a1fb-a441caac65fc	2.2.2. Джунги	<p>Джунгли вокруг деревни делятся на два типа. Обычные участки минированы: движение по ним без сапёра грозит подрывами. Тот сектор, который ведёт к статуе, подвержен мистическому искажению: деревья там не имеют колец роста, звуки глушатся, а пространство «сворачивается», возвращая заблудившихся к точке входа. Пройти к статуе можно тремя путями:</p><ul><li><p>- <strong>сапёрное дело </strong>— осторожное разминирование и поиск проходов;</p></li></ul><ul><li><p>- <strong>ориентация на местности/следопытство </strong>(ренджер) — найти единственную рабочую тропу;</p></li></ul><ul><li><p>- персонаж с низким счётчиком превращения (1) — его интуитивно «тянет» к источнику влияния.</p></li></ul><p>Без этого игроки будут блуждать и возвращаться назад, пока не поймут, что с лесом что‑то не так.</p><p></p>	<p>Джунгли вокруг деревни кажутся одинаковыми стенами зелени и влажного воздуха.</p>	f	f	\N	\N	ac3c5789-fef6-4a56-bfb8-59286c08c63a	584f6a2a-b5dd-424b-a459-ed291d213995	{}
cf7df1d6-0c3b-4d2c-89f4-e88e84cb49d2	0.2.3. Вердиктный зал	<p>Это формальный «суд» над желаниями.</p><ul><li><p>Большой зал с несколькими круглыми или амфитеатровыми столами.</p></li><li><p>За столами сидят <strong>вердиктор‑эльфы</strong> — как бы «судьи Санты».</p></li></ul><p>Функция:</p><ul><li><p>на основе всех кодов и пометок определить <strong>конкретный тип подарка</strong>:</p><ul><li><p>«автомобиль игрушечный, стандарт, серия N»;</p></li><li><p>«комплект одежды, зимний, тип М»;</p></li><li><p>«ничего / уголь / воспитательная продукция».</p></li></ul></li><li><p>иногда несколько писем объединяют в одну группу (например, «дети из одного дома/класса»), чтобы задать для них общий тип поставки.</p></li></ul><p>Вердикты фиксируются:</p><ul><li><p>на письме (служебные значки);</p></li><li><p>в служебной форме (для планового отдела).</p></li></ul><p>Письма после вердикта попадают в <strong>канал планирования</strong>.</p>		f	f	\N	\N	b84a761f-4475-4ab7-88a8-d2ede64740b2	515d2aaa-768b-4456-a837-bb160cf473a8	{}
9d56ea54-2a74-4ceb-a61d-6a434a58211d	0.2.4. Зал планирования выпуска	<p>Здесь письма уже не рассматриваются как «письма», а как строки в огромных таблицах.</p><ul><li><p>Столы с картами, схемами цехов, диаграммами загрузки производства.</p></li><li><p>Магические/механические панели, куда стекаются данные со всех предыдущих этапов.</p></li></ul><p>Планировщики:</p><ul><li><p>группируют письма по типам подарков, ценности, срокам (например, ближе к празднику — срочные, раньше — плановые);</p></li><li><p>считают:</p><ul><li><p>сколько единиц каждого типа нужно произвести;</p></li><li><p>какие цеха задействовать;</p></li><li><p>в какой последовательности запускать партии.</p></li></ul></li></ul><p>Результат — <strong>производственные планы</strong>:</p><ul><li><p>набор приказов для РР, МЦ, ТЦ и др.:</p><ul><li><p>«произвести X тысяч заготовок и корпусов типа А»;</p></li><li><p>«выпустить Y рулонов ткани тип B»;</p></li><li><p>«подготовить партию Z особых изделий».</p></li></ul></li><li><p>и <strong>логистические планы</strong> для СЦ:</p><ul><li><p>«ожидается такой‑то объём таких‑то товаров в такие‑то дни»;</p></li><li><p>«сформировать мешки по этим профилям для таких‑то регионов».</p></li></ul></li></ul><p>Планы уходят:</p><ul><li><p>в производственные цеха — как сменные задания;</p></li><li><p>в Сортировочный центр — как <strong>матрица ожиданий</strong>, чтобы он понимал, <strong>что</strong> и <strong>для кого</strong> он собирает в мешки.</p></li></ul><p></p>		f	f	\N	\N	b84a761f-4475-4ab7-88a8-d2ede64740b2	515d2aaa-768b-4456-a837-bb160cf473a8	{}
6f118747-a3ef-44f8-8c17-be9a28ea7c5c	2.2.1. Рисовые поля	<p>Под водой в канавках и между кустами риса спят жители-амфибии; при свете дня они кажутся обычными крестьянами, но в темноте из воды видны только головы и странно блестящие глаза. Вода в полях ощутимо солёная, на кромке почвы остаются белёсые кристаллы соли. Здесь можно:</p><ul><li><p>- показать игрокам, что «что-то не так» (ночующие в воде, жабры, изменённые лица при близком осмотре);</p></li><li><p>- подбрасывать проверки на влияние (нахождение в солёной воде, шёпоты, тянущиеся руки из ила);</p></li><li><p>- устроить ночные сцены слежки и первых атак мутировавших жителей.</p></li></ul><p></p>	<p>Перед деревней тянутся широкие рисовые поля, залитые водой по щиколотку или по колено.</p>	f	f	\N	\N	01541e3e-e37c-43c1-8920-fc0031824dc7	584f6a2a-b5dd-424b-a459-ed291d213995	{}
b311deb0-e7bc-49b4-9bf2-6b7bc526ae90	0.2.5. Административные и служебные элементы ЦП	<ul><li><p><strong>Бюро переписки</strong></p><ul><li><p>официально отвечает за «ответные письма» (благодарности, «ты был непослушным, постарайся лучше»),</p></li><li><p>на деле — ещё один инструмент контроля и давления.</p></li></ul></li><li><p><strong>Архив писем</strong></p><ul><li><p>хранит выборочные письма как примеры для идеологии и отчётности;</p></li><li><p>имеются «почётные» письма и «показательные» (особо мерзкие/опасные).</p></li></ul></li><li><p><strong>Комната идеологической обработки персонала</strong></p><ul><li><p>семинары на тему «как правильно интерпретировать желания»,</p></li><li><p>стенды с цитатами Санты‑Большого Брата, объясняющие, почему некоторым детям «нельзя давать слишком много».</p></li></ul></li></ul><p></p>		f	f	\N	\N	b84a761f-4475-4ab7-88a8-d2ede64740b2	515d2aaa-768b-4456-a837-bb160cf473a8	{}
9303cdc5-0204-4929-8bc1-3e15555d6d15	7.3. Мастерская ремонта и склад запчастей			f	f	\N	\N	62af27f3-1376-4d44-b085-910706567134	515d2aaa-768b-4456-a837-bb160cf473a8	{}
1aba9ce6-9ca9-4f72-ad08-5a3f0d6f90c3	7.1. Ангар погрузчиков			f	f	\N	\N	62af27f3-1376-4d44-b085-910706567134	515d2aaa-768b-4456-a837-bb160cf473a8	{}
392b7a3e-4c24-4aa1-99df-1549489fffc2	6.1. Главный зал ожидания			f	f	\N	\N	9a932465-b372-46e3-bbbe-515cde20f668	515d2aaa-768b-4456-a837-bb160cf473a8	{}
62af27f3-1376-4d44-b085-910706567134	7. База погрузчиков			f	f	\N	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260131_105139_62af27f3-1376-4d44-b085-910706567134.png	8c5b9a7b-bdac-4721-b0b6-d4b7740a150d	515d2aaa-768b-4456-a837-bb160cf473a8	{}
90a952c0-bbc7-4d23-97b8-ac9efe274bd5	Снежные горы			f	f	\N	\N	\N	6e80882a-4f37-4970-b475-d1650e8b32dc	{"temperatureC": 0, "illumination": 50, "tags": []}
1d38e750-c8d8-42e9-9c40-5e6a58d2e25f	test			f	f	\N	\N	\N	e7b83145-6dda-43d7-8bf8-295223d2ba30	{}
\.


--
-- Data for Name: location_tag; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.location_tag (location_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: map_object_polygon; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.map_object_polygon (id, name, source_location_id, target_location_id, is_shown, is_filled, is_line, alpha, color, polygon_list, icon, icon_url) FROM stdin;
9821db79-28cc-482a-8b88-0461bbf61ddd	Полигон 1	153c743a-e31c-40ec-8d44-8d7177c79d41	\N	t	t	f	0.5	#ff0000	[{"x": 347.84946236559136, "y": 60.21505376344086}, {"x": 307.5268817204301, "y": 177.9569892473118}, {"x": 419.89247311827955, "y": 202.68817204301075}, {"x": 486.02150537634407, "y": 108.6021505376344}, {"x": 423.1182795698924, "y": 72.04301075268816}]	none	\N
55db1fae-47e1-4e7f-9547-a535520582e0	AAAA	f0b26a81-6853-49fa-b3d2-146ae5d25b81	\N	t	t	f	0.5	#ff0000	[{"x": 149.57624831309042, "y": 72.87745864732925}, {"x": 180.60188933873144, "y": 143.42032797762926}, {"x": 271.719298245614, "y": 112.06794160860704}, {"x": 254.08367071524964, "y": 49.03658151255193}]	\N	\N
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.note (id, name, text, allowed_character_shown_json, icon_url, img_url, scenario_id) FROM stdin;
d515ab9d-8fc1-4993-882a-b60902b467dd	Вербовка К'Тулху	<p>Вы сошли с ума и начали слышать очень зловещие, но такие приятные голоса: убей их... предай их... съешь их... восславь К'Тулху... Ну разве не милаш этот К'Тулху, разве можно такому противиться! <strong>Вы проиграте, только если в живых останется кто-то из неверных. </strong>А победив ваш ждет вечная жизнь, увлекательные ритуалы, бесплатное кабельное телевиденье и таааакой ДМС!</p>	[]	\N	\N	584f6a2a-b5dd-424b-a459-ed291d213995
0a7935fc-38a1-440f-b09c-869cdcfbf2e6	Магические средства и разрешения	<ul><li><p><strong>Любое применение магии на территории завода допускается только при наличии действующего разрешения.</strong></p></li><li><p><strong>Для получения нового разрешения на использование магии эльф обязан:</strong></p><ul><li><p>составить аналитическую записку с обоснованием необходимости магии для конкретной операции;</p></li><li><p>согласовать записку с ответственным супервизором;</p></li><li><p>при необходимости выступить с защитой записки в бухгалтерии/администрации.</p></li></ul></li><li><p><strong>Супервизоры имеют право выдавать разрешения на магию только в объёме и целях предписанных для их цеха/места работы.</strong></p></li><li><p><strong>Самовольное применение магии, не предусмотренной текущим регламентом, карается дисциплинарным взысканием.</strong></p></li></ul><p></p>	[]	\N	\N	515d2aaa-768b-4456-a837-bb160cf473a8
8dd83d94-ac13-467d-a39e-4967cc03ffa6	Движение продукции и коробок	<ul><li><p><strong>Продукция между цехами перемещается в закрытых коробках. Открывать коробки до появления соответствующего указания на рабочем экране запрещено.</strong></p></li><li><p><strong>На каждой коробке размещается фотографическое изображение содержимого и служебная маркировка.</strong></p></li><li><p><strong>Рабочий обязан сверять:</strong></p><ul><li><p>фотографию;</p></li><li><p>маркировку;</p></li><li><p>указания на экране.</p></li></ul></li><li><p><strong>При обнаружении несоответствия фотографического изображения, маркировки и фактического содержимого:</strong></p><ul><li><p>немедленно прекратить операции с коробкой;</p></li><li><p>уведомить старшего по смене;</p></li><li><p>действовать по его распоряжению.</p></li></ul></li><li><p><strong>Самовольное изменение содержимого коробки, фотографии или маркировки запрещено и рассматривается как саботаж.</strong></p></li></ul><p></p>	[]	\N	\N	515d2aaa-768b-4456-a837-bb160cf473a8
8c25b509-b915-46f0-a4a1-2b568e93a68b	Несчастные случаи и смерть на производстве	<ul><li><p><strong>В случае, если на рабочем месте наступила смерть эльфа (придавило, разорвало, сгорел и т.п.), рабочие обязаны:</strong></p><ul><li><p>не покидать свои позиции;</p></li><li><p>продолжать выполнение операций, если это возможно;</p></li><li><p>сообщить о происшествии ближайшему надзирателю.</p></li></ul></li><li><p><strong>Остановка конвейера или производственной линии по инициативе рабочих запрещена.</strong></p></li><li><p><strong>Специализированная бригада уборщиков осуществляет:</strong></p><ul><li><p>сбор останков;</p></li><li><p>очистку рабочей зоны;</p></li><li><p>передачу биологических материалов в ресурсное ядро.</p></li></ul></li><li><p><strong>Обсуждение несчастных случаев между рабочими во время смены запрещено.</strong></p></li></ul><p></p>	[]	\N	\N	515d2aaa-768b-4456-a837-bb160cf473a8
\.


--
-- Data for Name: npc; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.npc (id, name, description_for_master, description_for_players, is_dead, is_enemy, is_shown, icon_url, img_url, body_id, scenario_id, unique_body_id, data) FROM stdin;
316149e8-c48c-4348-b04e-48481e887d63	aaaa	\N	\N	\N	\N	\N	https://rpgzona.ru/minio-api/rpg-assets/entity/character/icon/20260122_091613_05bd5768-6e03-4c83-9def-cfa7dc86ea56.png	https://rpgzona.ru/minio-api/rpg-assets/npc/img/20260123_105023_316149e8-c48c-4348-b04e-48481e887d63.jpg	\N	52978346-3a5d-4a67-b39b-bb666fe70aed	\N	{"items": [], "skills": {"athletics": 0, "burglary": 0, "disguise": 0, "driving": 0, "filch": 0, "fleeing": 0, "infiltration": 0, "piloting": 0, "riding": 0, "shadowing": 0, "stealth": 0, "tinkering": 0, "scuffling": 0, "shooting": 0, "weapons": 0, "health": 0, "stability": 0, "preparedness": 0, "sense_trouble": 0}, "health": null, "stability": null, "armor": null, "hitThreshold": null}
7922c9c4-bc66-4ecf-b5b1-f4dee2ef243a	aaa			f	t	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20250805_174155_7922c9c4-bc66-4ecf-b5b1-f4dee2ef243a.png	\N	\N	\N	{}
ae7abd5e-4ef7-4d14-ac57-12b3d73e2ee0	Охранник ТЦ			f	f	f	\N	\N	ae3a2d38-22f5-4007-b440-c9f2e0b924f1	6dab957a-c992-4e42-a23c-598cb3eb1893	\N	{}
37bf032e-c160-4366-9a1c-46d25fa10361	Охранник ТЦ			f	f	f	\N	\N	ae3a2d38-22f5-4007-b440-c9f2e0b924f1	6dab957a-c992-4e42-a23c-598cb3eb1893	\N	{}
999f9354-3b0e-4362-8211-cdc90ab12d06	Боб Энджел			f	f	f	\N	\N	94bad869-e8e6-496e-9496-1866ce92e262	6dab957a-c992-4e42-a23c-598cb3eb1893	\N	{}
058e8324-7bf0-426c-9b0f-495107817afe	Клара Джонс			f	t	f	\N	\N	5a599a0c-0be2-4186-bf7f-f3ed16074ee4	6dab957a-c992-4e42-a23c-598cb3eb1893	\N	{}
31fe002f-6e22-4a20-b959-d22596db3f53	2. Сержант первой статьи Джон «Ред» Харкер			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_211101_31fe002f-6e22-4a20-b959-d22596db3f53.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
70642f84-12dd-4478-9373-6923e336b838	1. Сержант Хартман		инструктор по строевой и боевой подготовке	f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20250808_112220_70642f84-12dd-4478-9373-6923e336b838.png	f20bf8d0-fc4c-4c35-99ab-789df2f55046	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
bc69f807-fdb8-48d6-9252-49109c7c32ec	2. Младший сержант Сэмюэл Грин			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_211142_bc69f807-fdb8-48d6-9252-49109c7c32ec.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
1e4ac5a0-ba1c-4971-b635-e2b5dc354d25	1. Медсестра Лиза МакКарти		медсестра	f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_182316_1e4ac5a0-ba1c-4971-b635-e2b5dc354d25.png	f20bf8d0-fc4c-4c35-99ab-789df2f55046	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
b6323c5f-23be-451f-bc4c-9f6d489afb17	1. Доктор Эдвард Хилл		главный врач медпункта	f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_182326_b6323c5f-23be-451f-bc4c-9f6d489afb17.png	f20bf8d0-fc4c-4c35-99ab-789df2f55046	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
0cb5139e-36f4-4bb8-9893-8ff94946acab	1. Повар Эндрю Скотт		повар столовой	f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_182356_0cb5139e-36f4-4bb8-9893-8ff94946acab.png	f20bf8d0-fc4c-4c35-99ab-789df2f55046	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
d2281f56-6535-4434-8ac0-b70b882cffe3	1. Сэм	Аферист		f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_182403_d2281f56-6535-4434-8ac0-b70b882cffe3.png	f20bf8d0-fc4c-4c35-99ab-789df2f55046	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
4dfdc4e9-c324-4e1b-9dc3-e0c6101e7c3b	1. Срежант Стивен О’Коннер		заведующий складом	f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_182414_4dfdc4e9-c324-4e1b-9dc3-e0c6101e7c3b.png	f20bf8d0-fc4c-4c35-99ab-789df2f55046	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
f6d498b6-209c-4532-8d37-f9e289421590	1. Лейтенант 4-ой дивизии Том Беннетт		главный техник соседнего подразделения, алкоголик	f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_182424_f6d498b6-209c-4532-8d37-f9e289421590.png	f20bf8d0-fc4c-4c35-99ab-789df2f55046	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
4528fe70-cf0f-4e1c-b54e-566be29ff782	Патрульный			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_182435_4528fe70-cf0f-4e1c-b54e-566be29ff782.png	608780ee-bb2e-4c41-92ef-6f7a15e38e27	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
d3252266-7308-4537-9cb6-26dfd8ffbf03	2. Рядовой первого класса Билли Тейлор			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_211216_71a46179-d826-43d8-90df-7162f659016d.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
45391d4a-64d5-4954-a488-5a621e140174	2. Младший сержант Чарльз «Чак» Джонсон			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_211148_45391d4a-64d5-4954-a488-5a621e140174.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
ef3cb871-6393-4ad8-9938-b1041d53333a	2. Рядовой Джерард Роквелл			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_211158_ef3cb871-6393-4ad8-9938-b1041d53333a.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
a8fad81a-4b77-43bb-9b37-c388e95a8159	2. Рядовой Дональд Смит			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_211205_a8fad81a-4b77-43bb-9b37-c388e95a8159.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
71a46179-d826-43d8-90df-7162f659016d	2. Рядовой Марк Эллис			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_211216_71a46179-d826-43d8-90df-7162f659016d.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
e5200fff-37f8-4b06-b3b5-5f23b5c9caa1	2. Специалист Томас Бэрнс			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_211228_e5200fff-37f8-4b06-b3b5-5f23b5c9caa1.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
adc6f718-0090-4448-af64-bd5a892278ab	2. Рядовой первого класса Кристофер «Крис» Филлипс			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_211216_71a46179-d826-43d8-90df-7162f659016d.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
27e0ee98-3e58-4fbf-be2a-b9f9d88f02ef	2. Рядовой Стив Уилсон			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_182435_4528fe70-cf0f-4e1c-b54e-566be29ff782.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
ef481936-98b4-48c2-be25-6200760f2c0e	2. Специалист Фрэнк Льюис			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251010_182424_f6d498b6-209c-4532-8d37-f9e289421590.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
415d83e8-1e75-455d-91b3-ac2b0456b44d	2. Сержант Джейкоб Миллер			f	f	f	\N	https://www.rpgzona.ru/minio-api/rpg-assets/character/img/20251011_083930_415d83e8-1e75-455d-91b3-ac2b0456b44d.png	bdeb4522-327b-4ee2-9c8f-5d41f6beb283	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
\.


--
-- Data for Name: npc_tag; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.npc_tag (npc_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: obstacle; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.obstacle (id, scenario_id, name, description_for_master, description_for_players, data) FROM stdin;
e9e89d7f-703b-421e-94bb-7a33f2d4e74a	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
d014fc66-1385-4858-a52d-c2ba0aaa6920	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
c3481da1-6b43-48d9-aca7-b8708f163c38	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
e0214240-fc62-4521-af75-0721c18dbdec	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
5cde8f3e-c972-4857-aea6-deeba92c908e	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
e2778ce7-40ad-4820-bb4d-8cca66f89547	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
b4d6d1dd-afa9-41c5-9ef8-08a2054138df	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
0816ced3-d474-4aa3-ab01-b46135ac315c	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
f090fa00-2892-431e-a6fc-9549061dc5fe	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
b257f0c8-f745-44c7-8b75-06a31f455637	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
95d8d0b6-7e94-4a49-b313-409af8267ca2	52978346-3a5d-4a67-b39b-bb666fe70aed	22asd	<p>11</p>	<p>111</p>	{"type": "clue", "name": "sdf", "description": "", "investigative_skills": [], "spend_cost": 2, "reward": "123"}
\.


--
-- Data for Name: player_action; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.player_action (id, description_for_master, description_for_players, add_time_secs, triggers_note_id, icon_url, img_url, location_id, npc_id, item_scheme_id, item_id, action_handler_id) FROM stdin;
dba4f501-5233-41b8-9bd1-586a0853cefb	Нормас	Сделать нормас	0	\N	\N	\N	153c743a-e31c-40ec-8d44-8d7177c79d41	\N	\N	\N	\N
a1bfea2e-ba0b-4488-b37e-0e67ce33d8db	разговор об играх приведёт парня в чувство. Последнее, что помнит Боб Энджел, — это его игра с приятелями. Они вчетвером участвовали в соревновательном квесте «Кристалл Мил-Лара», где их персонажи заплатили некроманту-игротехнику* для того, чтобы тот вызвал тень, которая должна была рассказать им о местонахождении кристалла.	Разговор	0	\N	\N	\N	8386be19-a500-419f-9d6c-eb88c1737116	\N	\N	\N	\N
94ca68b8-1723-45de-a9f4-ea9ebd3ed2b9	вы понимаете, что этот парень насылает жуткие проклятья на вас и ваш род.	Знание языков, древневавилонский.	0	\N	\N	\N	8386be19-a500-419f-9d6c-eb88c1737116	\N	\N	\N	\N
c667ca67-50c0-4d7e-a39a-54f37b25713d	этот парень одержим. Демона можно\nподавить, обратившись к основе личности его жертвы, к тому, что действи‑\nтельно для неё важно. Потратив 2 пункта, вы вспомните, что даже подавлен‑\nный демон может вернуться к управлению, если жертва испытает сильное\nпотрясение.	Оккультные науки	0	\N	\N	\N	8386be19-a500-419f-9d6c-eb88c1737116	\N	\N	\N	\N
1e04a99e-2f82-4480-9b27-ffd116805e59	позволит получить ключевую\nулику, так как вы поймёте, что беседа на тему игр, возможно, успокоит этого\nпарня.	Успокоение	0	\N	\N	\N	8386be19-a500-419f-9d6c-eb88c1737116	\N	\N	\N	\N
9d65928f-ce83-4f51-961a-c45ab2f4bba2	в комнает три трупа, живой Боб и пять\nрюкзаков. Оставшийся рюкзак принадлежит Кларе Джонс. В нём она забыла\nсвоё расписание мероприятия, где пометила те игры, в которых она собира‑\nлась поучаствовать. Сейчас она должна быть на турнире по D&D.	Сбор улик	0	\N	\N	\N	9e80aac9-18e6-4fd2-a2c5-fa1274359c4a	\N	\N	\N	\N
60e55ef7-83fd-40da-a71a-c88837b10982	оккультные принадлежности указывают на вавилонский ритуал вызова демона, похожий на ритуал из Некрономикона Симона (Schlangekraft, Inc., 1977). Обычно такие ритуалы использовались во время войны.	Оккультные науки	0	\N	\N	\N	9e80aac9-18e6-4fd2-a2c5-fa1274359c4a	\N	\N	\N	\N
2ddd1dc4-799a-4ff0-8819-5ac38e06d968	0 пунктов (если язык известен), свитки написаны на вавилонском языке. Если потрачен 1 пункт, то персонаж узнает следующее: сложно понять природу заклинания, написанного транскрипцией, но, скорее всего, это заклинание призыва демона, вселяющегося сразу в нескольких солдат, чтобы те расправились с врагами.	Язык	0	\N	\N	\N	9e80aac9-18e6-4fd2-a2c5-fa1274359c4a	\N	\N	\N	\N
450b739e-1f8e-49d1-8c09-56eb2808f845	Позволяет заметить солёность воды, белые кристаллы на земле, странные цилиндрические ямки, как от чьих-то лежащих тел. Можно дать намёк на ночёвку жителей в воде и кинуть первый слабый эффект на счётчики превращения при длительном контакте.	Осмотреть поля днём	0	\N	\N	\N	6f118747-a3ef-44f8-8c17-be9a28ea7c5c	\N	\N	\N	\N
024a1f0a-fad9-4f59-99c9-24e1e1982226	Сцена, где игроки понимают масштаб «ненормальности». Можно провести проверки на рассудок/стресс, на скрытность (если подходят ближе) и дать одному-двум персонажам первые «шёпоты из глубины», влияющие на счётчик превращения.	Наблюдать за полями ночью	0	\N	\N	\N	6f118747-a3ef-44f8-8c17-be9a28ea7c5c	\N	\N	\N	\N
270da9ca-6ae6-4ee6-99aa-405ce3cc99a0	Если несколько игроков соревнуются то, тут как в беге. Кто дольше.\nмедсестра становится лояльной, игрок получает +2 универсальных очка за «уважение внутри части». При провале можно дать +1 и осложнение — слухи, ревность, лишние проверки со стороны начальства.	Флирт с медсестрой	0	\N	\N	\N	29bc9a83-1124-430c-9d9d-40aaf25d9d29	\N	\N	\N	\N
2749a041-bfd8-4dc8-86e3-a22094df53e7	Успех — у игроков есть спирт, +2 универсальных очка тому, кто провернул план. Провал, но с интересной попыткой — +1 и возможные проблемы (выговор, наблюдение за ними медперсоналом).	Украсть спирт	0	\N	\N	\N	29bc9a83-1124-430c-9d9d-40aaf25d9d29	\N	\N	\N	\N
ed00cfac-a11d-436b-9fa0-13c87ab14186	игрок приходит на полигон в свободное время. Успешная серия стрельб или хорошее решение задачки на меткость — +2 к снайперскому делу. Если стрелял плохо, но старался и не сдался — +1. Можно учитывать самообладание и импровизацию	Дополнительные занятия по стрельбе	0	\N	\N	\N	8fadcf1e-fb0d-4c77-b1f3-6488a80c1b60	\N	\N	\N	\N
4cb9b350-9ac0-4c1c-9262-565f18071e28	если игрок притащил детали со склада/из города и пытается чинить сам, проведи одну‑две проверки. Успех — реально рабочая станция и +2 к радиотехнике. Провал — детали испорчены, станция всё ещё не работает, но игрок получает +1 к радиотехнике за опыт.	Самостоятельный ремонт с найденными деталями	0	\N	\N	\N	3dc3b868-dc6c-4b0c-aa23-60aa4f20b08b	\N	\N	\N	\N
517b71a8-432e-4109-842f-015e66a0212c	игрок с интересом к радиотехнике узнаёт, что сильные станции в части не работают или работают нестабильно. Это даёт крючок: «если раздобыть детали, можно починить». Успешная диагностика — +2 к радиотехнике, неудачная, но осмысленная попытка — +1.	Проверить состояние радиостанций	0	\N	\N	\N	3dc3b868-dc6c-4b0c-aa23-60aa4f20b08b	\N	\N	\N	\N
0bd0903f-c081-482f-9f5a-7180c213cf3b	игрок приносит спирт, уговаривает, льстит или помогает на складе. Успех — получает нужные детали и +2 универсальных очка. Провал, но с хорошей отыгровкой — +1 и, возможно, «отложенную услугу» от кладовщика	Выпросить или выторговать детали	0	\N	\N	\N	85376fd3-e098-4497-b51a-9cbaae403f88	\N	\N	\N	\N
7cd26283-292f-45e0-89fc-eb89d4a2d89f	сцена на скрытность/воровство. Успех — игроки получают форму или заряд и +2 к выбранной специализации (сапёр, механик, разведчик) или +2 универсальных, если это больше про наглость/славу. Провал — +1 очко и последствия: тревога, проверка, пометка в деле.	Украсть форму или динамит	0	\N	\N	\N	85376fd3-e098-4497-b51a-9cbaae403f88	\N	\N	\N	\N
670dcf4c-e1cf-4dd0-88e5-a90c70521edd	Ночной выход в город через лес	при успехе на скрытность и ориентирование — группа выходит в город и получает +2 к разведке. При провале с блужданием, но без поимки — +1 к разведке и возврат к части/казармам. При поимке — наказание по отыгрышу, но опыт остаётся	0	\N	\N	\N	4269f9c9-adbe-4043-84da-ce20bd262ac5	\N	\N	\N	\N
541935a7-e09d-4611-9040-2afb5194e879	если игрок/группа решает «зажечь», отыгрывается драка, проверки на драку/самообладание. За удачное выступление, ставшее темой для слухов, игрок получает +2 универсальных очка «славы». При фейлах — +1 и последствия: синяки, возможные выговоры.	Устроить громкую пьянку с дракой	0	\N	\N	\N	3c75bbcb-accd-4be3-bbb6-fe766d95c19b	\N	\N	\N	\N
f960976c-d187-491b-82f0-1644faa1a543	проверка скрытности/разведки. Успех — качественные фотографии, +2 к разведке. При передаче этих снимков начальству части игрок получает +2 универсальных очка как «ценный материал». Провал — +1 к разведке и проблемы: кто‑то заметил, возможный конфликт в городе.	Скрытно фотографировать отдыхающих	0	\N	\N	\N	24e61179-1f76-4ac8-9e35-0985d0c99d6a	\N	\N	\N	\N
8ae1e361-5162-4f1a-83d9-b3c5103b9fa3	игрок, заглянувший в кабинет, может заметить, что начальник расслабляется с журналом Playboy или чем‑то компрометирующим. Удачная скрытность — +2 универсальных очка (рычаг влияния, понимание, что командование — тоже люди). Фейл — +1 и неловкая сцена, возможный выговор.	Подглядеть за начальником части	0	\N	\N	\N	fff7633e-ca1c-4416-b6bb-c459414acb6a	\N	\N	\N	\N
9eb6bdec-ecbc-48ca-adec-2a2ae1289461	когда игрок приносит фото с пляжа или другую деликатную информацию, начальство может дать ему +2 универсальных очка за «услугу» и чуть более мягкое отношение в будущем.	Передать компромат/фото начальнику	0	\N	\N	\N	fff7633e-ca1c-4416-b6bb-c459414acb6a	\N	\N	\N	\N
38f1a111-81e8-4aec-9e85-dba5b569779d	проверка скрытности и вождения. Успех — весёлая ночная покатушка, +2 к вождению. Фейл — +1 к вождению и неприятности (шум, разбудили половину части, разборки с дежурными).	Угнать трактор ночью	0	\N	\N	\N	bad25b26-ab37-45ea-ac95-f2f9fbd69f61	\N	\N	\N	\N
00c0666b-8ea7-4500-8dc3-8dd45d5fab08	Не упасть при падении вертолета	Не упасть	0	\N	\N	\N	01541e3e-e37c-43c1-8920-fc0031824dc7	\N	\N	\N	\N
\.


--
-- Data for Name: player_character; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.player_character (id, name, short_desc, story, icon_url, img_url, body_id, location_id, scenario_id, unique_body_id, data) FROM stdin;
05bd5768-6e03-4c83-9def-cfa7dc86ea56	asd			https://rpgzona.ru/minio-api/rpg-assets/entity/character/icon/20260122_091613_05bd5768-6e03-4c83-9def-cfa7dc86ea56.png	https://rpgzona.ru/minio-api/rpg-assets/entity/character/image/20260117_152900_05bd5768-6e03-4c83-9def-cfa7dc86ea56.jpeg	\N	\N	52978346-3a5d-4a67-b39b-bb666fe70aed	\N	{"name": "", "skills": {"anthropology": 1}, "items": [], "points": {"investigativeMax": 1, "generalMax": 60}, "skill_points": {"investigativeTotal": 1, "generalTotal": 0}}
9c64c12b-b529-4e9c-8fac-d813be07a8d7	Джимми «Базз» Базоли	Бывший бандит	Участник программы защиты свидетелей	\N	\N	c32498bc-5753-48a7-a9c8-5190520c9731	\N	6dab957a-c992-4e42-a23c-598cb3eb1893	\N	{}
3b69d1e0-91dc-43f1-a1b8-2581736b5a9e	asd2		<p>asd</p>	https://rpgzona.ru/minio-api/rpg-assets/item_scheme/icon/20251004_084334_18983da2-fddb-426b-897b-02445ffb308e.png	https://rpgzona.ru/minio-api/rpg-assets/character/img/20260122_100724_3b69d1e0-91dc-43f1-a1b8-2581736b5a9e.jpeg	\N	\N	52978346-3a5d-4a67-b39b-bb666fe70aed	\N	{"name": "", "skills": {"anthropology": 19}, "items": [], "points": {"investigativeMax": 1, "generalMax": 0}, "skill_points": {"investigativeTotal": 0, "generalTotal": 0}}
68b3d841-3f68-4be3-b4ec-814bf689d893	Сэм Прековски	Член команды SWAT		\N	\N	2a7103f9-e08f-401a-b67e-616106401c40	\N	6dab957a-c992-4e42-a23c-598cb3eb1893	\N	{}
f64ebbcf-8d00-4014-8c40-a6a514db7166	Др. Эгди Вайдкомб	Бывший криминалист ФБР		\N	\N	25755164-8776-4710-a5e2-ac0050fb3ff3	\N	6dab957a-c992-4e42-a23c-598cb3eb1893	\N	{}
cdc217d8-5206-4d0e-b807-5e8313cc8fd5	Волтер Смит	Студент Йельского университета, участник олимпийской сборной США		\N	\N	fe68d3df-4636-4fef-aad1-911de4dc1d40	\N	6dab957a-c992-4e42-a23c-598cb3eb1893	\N	{}
3dfbab91-2a16-46fd-911d-96098212229a	Алекс Сомерсет	Продюсер ТВ-сериалов, Шпион ЦРУ		\N	\N	40ebb002-62de-4721-8069-0d739ee5e247	\N	6dab957a-c992-4e42-a23c-598cb3eb1893	\N	{}
a7fa9dc2-7123-4c99-8bca-45e97de2a816	Джокер	военный корреспондент, аналитик с склонностью к исследованию.	Джокер начал службу как репортёр в подразделении морской пехоты, но быстро освоился с бюрократическими и правовыми механизмами армии. Его знание истории, лингвистики и аналитический склад ума помогали не только понимать, но и разоблачать пропаганду.	\N	https://byury.online/minio-api/rpg-assets/character/img/20251011_084134_a7fa9dc2-7123-4c99-8bca-45e97de2a816.png	5425050a-8092-4ba7-8b7c-3ca922d23021	\N	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
7105397e-e120-4d91-919d-09dab23625c0	Джуниор Дик			\N	https://byury.online/minio-api/rpg-assets/character/img/20251011_084502_7105397e-e120-4d91-919d-09dab23625c0.png	b5aa046d-4b82-4293-8816-6ed77d627e3b	\N	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
00a77b3c-f8d6-4b77-9a5b-81ad15245a42	Изабель Крамер	химик и бывший армейский оператор связи.		\N	https://byury.online/minio-api/rpg-assets/character/img/20251011_084519_00a77b3c-f8d6-4b77-9a5b-81ad15245a42.png	21bd901e-9f8c-40ee-8523-d46586c13100	\N	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
489b422b-8932-46dc-9dad-7b173a0eb5a7	Эльф 4509 (Юна)		<p>Я была отличницей. У меня всё должно было быть правильно: расписание, подписи, аккуратные поля. В ночь похищения я не спала — дописывала список дел на каникулы, чтобы не тревожиться. На стол упала снежинка. Потом ещё одна. Я подняла голову — окно закрыто. И тогда из‑под кровати выехал маленький санный полоз, сам по себе. Я наклонилась, чтобы потрогать, и полоз “зацепил” меня — как крюк. Меня потянуло вниз, в пространство между полом и… чем-то ещё.</p><p>На фабрике я сразу поняла: я могу считать наперёд. Видеть, где сорвётся ремень, где загорится лампа, где охрана повернёт. Я не ем. Не сплю. Я планирую.</p>	\N	\N	9847746c-4c9e-4c94-a5eb-23cabd0405ac	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 0, "study": 1, "survey": 1, "tinker": 0, "finesse": 0, "prowl": 0, "skirmish": 0, "wreck": 0, "attune": 0, "command": 1, "consort": 2, "sway": 2}, "playbookId": "spider", "abilities": ["foresight"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 2, "prowess": 0, "resolve": 3}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
908a8799-b033-483a-8bbf-ddb7f7b0db8b	Эльф 3091 (Сами)		<p>Я боялся темноты, но никому не говорил. В ту ночь я всё-таки встал за водой. В коридоре стоял силуэт — высокий, неправильный, как на плохом рисунке. Он не двигался, но я понял: он знает, что я смотрю. Я прошептал: “Уходи”, а воздух ответил тихим звоном. Потом меня как будто вытянули из собственного тела и свернули.</p><p>Очнулся на фабрике и понял: я чувствую что-то рядом, всегда. Как будто призраки — это просто шум на другом канале, и я научился его слышать. Голод исчез. Сон исчез. Страх тоже стал другим: он больше не парализует.</p>	\N	\N	2d1dd277-b325-4bd9-a3d2-76b6a0640efe	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 0, "study": 2, "survey": 1, "tinker": 0, "finesse": 0, "prowl": 1, "skirmish": 1, "wreck": 0, "attune": 2, "command": 0, "consort": 0, "sway": 0}, "playbookId": "whisper", "abilities": ["ghost_mind"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 2, "prowess": 2, "resolve": 1}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
a80fd2f9-4415-4e7f-810f-f13f02ac8129	Ковбой	офицер, лидер подразделения	уроженец Техаса, Ковбой всегда умел держать людей вместе. Он не самый сильный боец, но идеальный командир. Благодаря уверенности, харизме и умению читать людей, его уважают даже те, кто его боится. 	\N	https://byury.online/minio-api/rpg-assets/character/img/20251011_084544_a80fd2f9-4415-4e7f-810f-f13f02ac8129.png	63e3e3b6-7e77-45a1-81a8-496125e0382c	\N	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
e0e2c780-4c53-47a4-942d-fec9e092e770	Animal Mother	агрессивный, но эффективный техник-разведчик и стрелок		\N	https://byury.online/minio-api/rpg-assets/character/img/20251011_084551_e0e2c780-4c53-47a4-942d-fec9e092e770.png	7d81eb4b-abf7-4e24-9efd-c2be948fae67	\N	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
d3d6f292-7149-47c4-bb69-a5071601c082	Private Pyle	нестандартный археолог и мистик, прошедший тяжёлую душевную трансформацию.		\N	https://byury.online/minio-api/rpg-assets/character/img/20251011_084558_d3d6f292-7149-47c4-bb69-a5071601c082.png	db868c11-8142-4ff2-978e-79772b97f5d7	\N	584f6a2a-b5dd-424b-a459-ed291d213995	\N	{}
b6157b06-fb59-47b4-8756-ab43c2b48084	AAA			\N	\N	3cef29d1-0dfa-4a02-a65c-ae0de694894c	\N	\N	\N	{}
ccc8b2af-ada2-41c0-87f4-3446da126f0a	Эльф 9006 (Илья)		<p>Я был “трудным”, так меня называли взрослые. Мне проще было решить вопрос силой, чем объяснять, почему мне больно. В ту ночь я услышал в подъезде шаги — тяжёлые, уверенные. Я выглянул в глазок и увидел красный рукав. Меня как будто подожгло изнутри: кто это заходит к нам? Я распахнул дверь, готовый ударить, но вместо человека — мешок. Мешок ударил меня первым.</p><p>На фабрике я понял: моё тело стало меньше, но злость — острее. И странное: усталости нет. "Какой я удобный работник", думают они, только есть нюанс. Я могу драться бесконечно.</p>	\N	\N	99264cc0-3cd5-4f19-a7a3-d8390b13eb6e	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 1, "study": 0, "survey": 0, "tinker": 0, "finesse": 1, "prowl": 0, "skirmish": 2, "wreck": 0, "attune": 0, "command": 2, "consort": 0, "sway": 0}, "playbookId": "cutter", "abilities": ["battleborn"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 1, "prowess": 2, "resolve": 1}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
734280b2-b658-4e00-b5cc-60b71de90954	Эльф 0137 (Мина)		<p>«Хорошая девочка должна быть тихой», — говорила бабушка, и я научилась ходить так, чтобы не скрипнула ни одна доска. Ночью я проснулась от того, что дома слишком… ровно. Ни холодильника, ни труб, ни ветра. Я вышла в коридор и увидела у ёлки коробку без ленты — как будто забыли оформить. Я присела, потянула за крышку, и внутри был не подарок, а темнота. Я только успела подумать: “так не бывает”, как кто‑то накрыл меня сверху чем-то пахнущим корицей и пылью. Кричать было бесполезно: звук глох, словно в вате.</p><p>Очнулась уже на фабрике. Не помню, как меня перекинули через небо. Помню только отражение в металле станка: уши острые, глаза блестят, и в животе — пусто, но не голодно. Спать тоже не хочется. Страшно то, что голова работает слишком быстро, как будто меня сделали удобной для работы.</p>	\N	\N	f1c6aca7-3f98-4f2f-b0dd-de7dca6f2a8d	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 0, "study": 0, "survey": 1, "tinker": 0, "finesse": 2, "prowl": 2, "skirmish": 0, "wreck": 0, "attune": 1, "command": 0, "consort": 0, "sway": 0}, "playbookId": "lurk", "abilities": ["ambush"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 1, "prowess": 2, "resolve": 1}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
eb882025-6fd7-4120-9778-a81e8e8716f7	Эльф 2044 (Томас)		<p>Я был тем ребёнком, который “вечно всё ломает”. На самом деле я просто хотел понять, как устроены вещи. В ту ночь я услышал тихий щелчок — как у замка, который не должен открываться сам. Я пошёл на кухню и увидел, что окно приоткрыто, хотя отец всегда проверял защёлку дважды. На подоконнике лежал маленький инструмент — как миниатюрная отвёртка из набора игрушек. Я взял её, и сразу из‑под стола выскользнула рука в перчатке, резко — и мир свернулся в мешок.</p><p>Когда я пришёл в себя, руки уже были в тонких перчатках, а пальцы — ловкие, чужие. Я не чувствовал голода. Я почувствовал другое: желание довести механизм до идеала. Это пугает сильнее, чем не спать.</p>	\N	\N	64ec78a3-4fa8-40f2-8915-89305f1d9e62	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 0, "study": 1, "survey": 0, "tinker": 2, "finesse": 0, "prowl": 0, "skirmish": 0, "wreck": 2, "attune": 1, "command": 0, "consort": 0, "sway": 0}, "playbookId": "leech", "abilities": ["engineer"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 2, "prowess": 1, "resolve": 1}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
4dfb0393-c9f5-4819-87ab-395bd26bea39	Эльф 7710 (Аиша)		<p>Я жила с мамой вдвоём, и у нас всё было “на словах”: обещания, извинения, уговоры. Я умела говорить так, чтобы люди соглашались — иногда даже не замечали, что уже согласились. В ту ночь я не спала: ждала сообщение от мамы, она задерживалась на работе. В прихожей раздался звук, как будто кто‑то аккуратно поставил сапоги. Я открыла дверь — никого. Только на коврике лежала записка: “Скажи, чего ты хочешь”.</p><p>Я прошептала в пустоту: “Чтобы мама пришла домой”. И в этот момент кто‑то ответил из-за спины: “Договор”. Меня как будто обняли воздухом, и я провалилась во тьму.</p><p>Очнулась уже эльфом. На коже — странный знак, будто клякса от чернил. Есть и спать не хочется. Но я теперь чувствую: слова — это не просто слова. Они цепляются к миру.</p>	\N	\N	8a7e6824-7bd2-4d1f-a1e6-baf0cf5377a9	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 0, "study": 1, "survey": 0, "tinker": 0, "finesse": 0, "prowl": 0, "skirmish": 1, "wreck": 0, "attune": 0, "command": 1, "consort": 2, "sway": 1}, "playbookId": "spider", "abilities": ["ghost_contract"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 1, "prowess": 1, "resolve": 3}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
d2e54b2e-a184-4559-8e0f-5dac77b62ea6	Эльф 1182 (Клара)		<p>Я всегда замечала мелочи: кто соврал, кто прячет руки, кто смотрит не туда. В ночь похищения я увидела, что гирлянда мигает не по рисунку — как будто кто‑то передаёт сигнал. Я пошла к ёлке и увидела под ветками следы снега. Снег в комнате. Я наклонилась — и меня подняли, как игрушку. Я услышала спокойный голос: “Тсс. Будет быстрее, если не сопротивляться.”</p><p>Очнулась на фабрике и поняла: я не чувствую голода. Не чувствую сон. Зато чувствую, где кто стоит, даже если не вижу. Как будто меня подключили к чему‑то большому и холодному.</p>	\N	\N	09f56fbe-b08e-458d-9f96-7f82ee0ea4ee	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 2, "study": 0, "survey": 2, "tinker": 0, "finesse": 1, "prowl": 0, "skirmish": 2, "wreck": 0, "attune": 0, "command": 0, "consort": 0, "sway": 0}, "playbookId": "hound", "abilities": ["scout"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 2, "prowess": 2, "resolve": 0}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
1dcb4854-e91c-4ae1-ae08-75cf5d7dcfb7	Эльф 6621 (Хоакин)		<p>Я рос в месте, где шум — это фон, а тишина пугает. В ту ночь стало слишком тихо, и я пошёл проверить, не отключили ли электричество. У ёлки стоял маленький колокольчик, которого раньше не было. Я дотронулся — и он не зазвенел, а как будто втянул звук в себя. Сзади меня накрыла ткань, пахнущая снегом и старым деревом. Я бился, но ткань только сильнее затягивалась.</p><p>Проснулся уже с острыми ушами. И с чувством, что могу “проскользнуть” туда, куда обычные не могут. Как будто меня сделали тенью.</p><p></p>	\N	\N	f4632fa1-6cb6-4438-bdb1-14315d951e86	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 1, "study": 0, "survey": 0, "tinker": 0, "finesse": 2, "prowl": 2, "skirmish": 0, "wreck": 0, "attune": 2, "command": 0, "consort": 0, "sway": 0}, "playbookId": "lurk", "abilities": ["ghost_form"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 1, "prowess": 2, "resolve": 1}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
d829ccaf-86d7-4f05-a361-db498fd32359	Эльф 5820 (Надя)		<p>Я была “маминой помощницей”. Всегда держала дом, пока мама работала. В ночь похищения я услышала, что кто‑то возится с замком входной двери. Я схватила швабру как копьё и пошла. Дверь сама открылась внутрь. На пороге — мешок, и на мешке — наш адрес, как на посылке. Я ткнула шваброй, и мешок “поймал” швабру, как рот. Потом поймал меня.</p><p>На фабрике я поняла: я могу держаться, даже когда всё болит. Но боли… стало меньше. Как будто меня сделали стойкой. Удобной. Я хочу быть стойкой для своих — не для них.</p>	\N	\N	73841bdb-5b12-45b6-b484-1c1bbf1dbde1	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 1, "study": 0, "survey": 0, "tinker": 0, "finesse": 0, "prowl": 1, "skirmish": 2, "wreck": 1, "attune": 0, "command": 2, "consort": 0, "sway": 0}, "playbookId": "cutter", "abilities": ["bodyguard"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 1, "prowess": 3, "resolve": 1}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
b7b28e0e-b136-4e8b-825b-7387fa3530d1	Эльф 7403 (Леон)		<p>Я был тем, кого в школе называли “придурком” — потому что я постоянно шутил. Шутки были проще, чем признаться, что мне тяжело. В ночь похищения я устроил себе “квест”: найти все подарки до утра. Я крался по дому, смеялся беззвучно, и вдруг увидел на лестнице следы копыт… в снегу. Я наклонился, чтобы рассмотреть, и почувствовал удар по затылку — мягкий, как подушка. Я очнулся в мешке и услышал сверху голос: “Не шевелись. Так будет быстрее.”</p><p>На фабрике я понял: руками я теперь могу делать вещи быстрее, чем успеваю подумать. А думать я успеваю всегда. Я не сплю. Я не ем. Я работаю. Я ненавижу это.</p>	\N	\N	b981af8d-5c59-47f1-bf1b-03baf7476f92	\N	515d2aaa-768b-4456-a837-bb160cf473a8	\N	{"actions": {"hunt": 0, "study": 1, "survey": 0, "tinker": 2, "finesse": 1, "prowl": 1, "skirmish": 0, "wreck": 2, "attune": 0, "command": 0, "consort": 0, "sway": 0}, "playbookId": "leech", "abilities": ["saboteur"], "stress": 0, "traumas": [], "load": null, "harm": {"l1": [null, null], "l2": [null, null], "l3": null}, "items": [], "derived": {"attributes": {"insight": 2, "prowess": 3, "resolve": 0}, "loadValue": null, "defaultItemQualityUsed": 0, "traumaCount": 0}}
fdb4855d-9bed-445b-81d2-40c4b626372f	aAA	\N	\N	\N	\N	\N	\N	6e80882a-4f37-4970-b475-d1650e8b32dc	\N	{"kind": "pc", "tags": ["stone", "hold", "metal", "thrust", "runes"], "traits": [{"id": "fix_shoddy_work", "text": "\\u041a\\u043e\\u0433\\u0434\\u0430 \\u0432\\u0438\\u0436\\u0443 \\u0445\\u0430\\u043b\\u0442\\u0443\\u0440\\u0443 \\u2014 \\u044f \\u043e\\u0431\\u044f\\u0437\\u0430\\u043d \\u0438\\u0441\\u043f\\u0440\\u0430\\u0432\\u0438\\u0442\\u044c \\u0438\\u043b\\u0438 \\u043f\\u0443\\u0431\\u043b\\u0438\\u0447\\u043d\\u043e \\u043e\\u0431\\u043e\\u0437\\u043d\\u0430\\u0447\\u0438\\u0442\\u044c, \\u0438\\u043d\\u0430\\u0447\\u0435 \\u043f\\u043b\\u0430\\u0447\\u0443 \\u0446\\u0435\\u043d\\u0443."}], "tracks": {"hp": 6, "eq": 3, "fat": 0, "conc": 0, "grudge": 0}, "trackMax": {"hp": 6, "eq": 3, "fat": 6, "conc": 3, "grudge": 6}, "economy": {"main": 1, "move": 1, "defense": 1}, "items": [], "passives": [{"id": "passive_rune_discipline", "enabled": true, "level": "none", "matches": 0}], "derived": {}}
b0cc4329-83b0-45ca-8553-cb28b5abbf37	test	\N	\N	\N	\N	\N	\N	e7b83145-6dda-43d7-8bf8-295223d2ba30	\N	{"profession": "aaa"}
\.


--
-- Data for Name: requirement; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.requirement (id, skill_value, threshold, skill_id, action_id) FROM stdin;
08700c83-abbe-446d-a72d-3ee065430c89	3	t	b4dd88a7-1b12-48d9-a668-3fbcaf5481f4	2749a041-bfd8-4dc8-86e3-a22094df53e7
413974c4-704d-47a3-9adf-1d60f51b41eb	3	t	6a85419e-4dcc-4231-952f-60bd21b3bc53	ed00cfac-a11d-436b-9fa0-13c87ab14186
8567357a-a80c-4625-a50b-e5d87a85b827	3	t	47cebc54-4b11-46da-a0ca-f8d457bec45f	4cb9b350-9ac0-4c1c-9262-565f18071e28
d33bfe5b-b962-4c8f-a06a-9a690e63e692	3	t	7cea763f-e313-40ed-bd18-9c79bdcef64e	517b71a8-432e-4109-842f-015e66a0212c
68f12416-5eb8-4514-b63f-541db96d38c4	3	t	b4dd88a7-1b12-48d9-a668-3fbcaf5481f4	7cd26283-292f-45e0-89fc-eb89d4a2d89f
34934af9-831e-4b0f-b122-43500d955be7	3	t	d0605f5c-f5c1-4220-909e-5647b63b8d5c	f960976c-d187-491b-82f0-1644faa1a543
c46628d9-a7e3-47ca-a437-beb40f63e454	3	t	d0605f5c-f5c1-4220-909e-5647b63b8d5c	38f1a111-81e8-4aec-9e85-dba5b569779d
f6ae4745-00f8-4c57-9093-b501f856fb7f	3	t	431f4009-d1ca-4df9-8179-70a8f2084bd1	38f1a111-81e8-4aec-9e85-dba5b569779d
8efcf997-1f80-4f39-b22d-9f8ff1a067f3	4	t	e2f9a87b-122d-430b-968f-59eb9d19f49a	00c0666b-8ea7-4500-8dc3-8dd45d5fab08
\.


--
-- Data for Name: scenario; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.scenario (id, name, intro, max_players, created, icon_url, user_id, rule_id_str, data) FROM stdin;
584f6a2a-b5dd-424b-a459-ed291d213995	Вьетнам (ЗК)		6	2025-08-06 12:32:46.571226+00	\N	6aac36c0-0d37-4670-a082-61a6ffe39eca	\N	{}
515d2aaa-768b-4456-a837-bb160cf473a8	Северный полюс		6	2025-12-05 13:11:51.360398+00	\N	8be0377e-80f1-4029-9f21-6a57d3d9ad19	blades_in_the_dark	{}
6e80882a-4f37-4970-b475-d1650e8b32dc	Тест Дворфы		4	2026-02-09 11:12:38.020552+00	\N	8be0377e-80f1-4029-9f21-6a57d3d9ad19	im_bitter_and_i_keep_records	{}
6dab957a-c992-4e42-a23c-598cb3eb1893	Убивая не забудь обчистить труп		4	2025-10-04 08:55:57.61471+00	\N	8be0377e-80f1-4029-9f21-6a57d3d9ad19	gumshoe	{}
52978346-3a5d-4a67-b39b-bb666fe70aed	test gumshoe	asd	4	2026-01-16 15:00:24.604262+00	\N	8be0377e-80f1-4029-9f21-6a57d3d9ad19	gumshoe	{}
e7b83145-6dda-43d7-8bf8-295223d2ba30	TEST John		4	2026-02-15 12:02:27.268703+00	\N	8be0377e-80f1-4029-9f21-6a57d3d9ad19	everyone_is_john	{}
\.


--
-- Data for Name: scenario_template_set_link; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.scenario_template_set_link (id, scenario_id, template_set_id, enabled, order_num) FROM stdin;
\.


--
-- Data for Name: scene_exposure; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.scene_exposure (id, scenario_id, name, order_num, location_id, story_beat_id) FROM stdin;
3a62c998-4c2e-47c9-a45a-9b63d99e7934	52978346-3a5d-4a67-b39b-bb666fe70aed	FFF	0	f0b26a81-6853-49fa-b3d2-146ae5d25b81	\N
fc219e50-6a3c-49a5-a64d-a0d17cb28967	52978346-3a5d-4a67-b39b-bb666fe70aed	Новая экспозиция	1	f0b26a81-6853-49fa-b3d2-146ae5d25b81	\N
af2b1ae9-d772-4813-a43f-b2c190cdcdb6	52978346-3a5d-4a67-b39b-bb666fe70aed	ASA	0	\N	fe0b6380-8401-4d91-8c72-c373aef5736a
\.


--
-- Data for Name: scene_exposure_item; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.scene_exposure_item (scene_exposure_id, item_id) FROM stdin;
3a62c998-4c2e-47c9-a45a-9b63d99e7934	a98e2727-c09a-4f9d-b6dd-35c7bf167be4
3a62c998-4c2e-47c9-a45a-9b63d99e7934	7ab21c8a-69a6-470a-b71e-2fd48c818b51
af2b1ae9-d772-4813-a43f-b2c190cdcdb6	a98e2727-c09a-4f9d-b6dd-35c7bf167be4
\.


--
-- Data for Name: scene_exposure_npc; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.scene_exposure_npc (scene_exposure_id, npc_id) FROM stdin;
3a62c998-4c2e-47c9-a45a-9b63d99e7934	316149e8-c48c-4348-b04e-48481e887d63
af2b1ae9-d772-4813-a43f-b2c190cdcdb6	316149e8-c48c-4348-b04e-48481e887d63
\.


--
-- Data for Name: scene_exposure_obstacle; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.scene_exposure_obstacle (scene_exposure_id, obstacle_id) FROM stdin;
3a62c998-4c2e-47c9-a45a-9b63d99e7934	95d8d0b6-7e94-4a49-b313-409af8267ca2
\.


--
-- Data for Name: story_beat; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.story_beat (id, scenario_id, name, order_num, text_for_master, text_for_players, show_once, is_shown, img_url, parent_story_beat_id) FROM stdin;
fe0b6380-8401-4d91-8c72-c373aef5736a	52978346-3a5d-4a67-b39b-bb666fe70aed	ASD	0	\N	\N	f	f	\N	\N
\.


--
-- Data for Name: story_beat_location; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.story_beat_location (story_beat_id, location_id) FROM stdin;
\.


--
-- Data for Name: story_beat_npc; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.story_beat_npc (story_beat_id, npc_id) FROM stdin;
\.


--
-- Data for Name: unique_body; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.unique_body (id, name, scenario_id) FROM stdin;
\.


--
-- Data for Name: unique_stat; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.unique_stat (id, body_id, skill_id, init_value) FROM stdin;
\.


--
-- Data for Name: where_object; Type: TABLE DATA; Schema: scenario; Owner: postgres
--

COPY scenario.where_object (id, npc_id, location_id) FROM stdin;
61d134d5-7bc2-403a-8cf4-918768aa038a	7922c9c4-bc66-4ecf-b5b1-f4dee2ef243a	153c743a-e31c-40ec-8d44-8d7177c79d41
21acd0b8-a64f-4392-8e2d-8c503f5baeb6	ae7abd5e-4ef7-4d14-ac57-12b3d73e2ee0	bc7da00a-e5de-4cb5-8bb1-112aa4fff024
4657d3e0-6310-4f1d-8f1e-f2b8a24bcb91	37bf032e-c160-4366-9a1c-46d25fa10361	bc7da00a-e5de-4cb5-8bb1-112aa4fff024
aad122fa-377d-4d9c-b4ae-62f3b72f14c0	999f9354-3b0e-4362-8211-cdc90ab12d06	8386be19-a500-419f-9d6c-eb88c1737116
c7780db8-5280-469c-9487-89796f52b84e	058e8324-7bf0-426c-9b0f-495107817afe	6c1b61b2-823f-43f8-a158-e52588ed6aa8
8c27c303-96f8-4457-ad1c-3bcbbdac946b	0cb5139e-36f4-4bb8-9893-8ff94946acab	dba9f3b2-23a3-4973-bbdd-a900c4a6ba3f
c71175f5-ae64-410c-b009-0058bf8d5887	4dfdc4e9-c324-4e1b-9dc3-e0c6101e7c3b	85376fd3-e098-4497-b51a-9cbaae403f88
d90636c1-3318-4e69-be3f-b08db5e7ae51	1e4ac5a0-ba1c-4971-b635-e2b5dc354d25	29bc9a83-1124-430c-9d9d-40aaf25d9d29
e899732a-7367-4203-9165-2f1671f1f317	b6323c5f-23be-451f-bc4c-9f6d489afb17	29bc9a83-1124-430c-9d9d-40aaf25d9d29
0967ef43-bde3-412a-a252-ecdad88b45e6	70642f84-12dd-4478-9373-6923e336b838	8fadcf1e-fb0d-4c77-b1f3-6488a80c1b60
82252d0d-bea4-4404-9a69-82917dfb4eb8	d2281f56-6535-4434-8ac0-b70b882cffe3	5d67269e-17e7-44dc-9676-14c8de528bd8
65e877a3-23bf-4b5f-b1e2-639609633cf8	4528fe70-cf0f-4e1c-b54e-566be29ff782	2d8bad06-a5d6-49fe-bc46-5c9a8fb07b79
177ec68a-6a5b-4788-89b6-ffc02f3dc89a	ef481936-98b4-48c2-be25-6200760f2c0e	01541e3e-e37c-43c1-8920-fc0031824dc7
be2b56ca-ac1c-4a4b-ad07-0282f480e412	d3252266-7308-4537-9cb6-26dfd8ffbf03	01541e3e-e37c-43c1-8920-fc0031824dc7
07f05146-f032-4811-a545-55023ddab9ee	adc6f718-0090-4448-af64-bd5a892278ab	01541e3e-e37c-43c1-8920-fc0031824dc7
c4a0da0b-3bf7-434d-8a45-f954cac0f04e	bc69f807-fdb8-48d6-9252-49109c7c32ec	82b2e48e-4f5a-4260-b360-1c60531ea520
77bb35df-315e-450f-a7e2-306b66a48a64	45391d4a-64d5-4954-a488-5a621e140174	82b2e48e-4f5a-4260-b360-1c60531ea520
1a5efb81-4715-49b9-b8b5-80f0a51191eb	ef3cb871-6393-4ad8-9938-b1041d53333a	82b2e48e-4f5a-4260-b360-1c60531ea520
b0ced9cd-3c48-4bd2-b14a-88963b59d3ba	a8fad81a-4b77-43bb-9b37-c388e95a8159	82b2e48e-4f5a-4260-b360-1c60531ea520
90c7eef1-bf40-43d4-8284-9b4aaafcae72	71a46179-d826-43d8-90df-7162f659016d	82b2e48e-4f5a-4260-b360-1c60531ea520
cb0b5b59-9c94-4bb3-b74e-66897bb95d32	27e0ee98-3e58-4fbf-be2a-b9f9d88f02ef	82b2e48e-4f5a-4260-b360-1c60531ea520
9a2c6408-37c6-4a32-9b36-9c8441274192	415d83e8-1e75-455d-91b3-ac2b0456b44d	82b2e48e-4f5a-4260-b360-1c60531ea520
8f8f0ceb-125c-438c-a0a7-fb09a1ddef6b	31fe002f-6e22-4a20-b959-d22596db3f53	82b2e48e-4f5a-4260-b360-1c60531ea520
71f389dc-22c1-4170-92ad-84d1ca05ca90	e5200fff-37f8-4b06-b3b5-5f23b5c9caa1	edafce06-67b8-4c2c-8ed3-6dec8369486f
2da38f98-bde1-4693-9657-b8750a973a53	d2281f56-6535-4434-8ac0-b70b882cffe3	3c75bbcb-accd-4be3-bbb6-fe766d95c19b
\.


--
-- Name: on_use_item on_use_item_pkey; Type: CONSTRAINT; Schema: common; Owner: postgres
--

ALTER TABLE ONLY common.on_use_item
    ADD CONSTRAINT on_use_item_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: game_session game_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.game_session
    ADD CONSTRAINT game_session_pkey PRIMARY KEY (id);


--
-- Name: master_group master_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_group
    ADD CONSTRAINT master_group_name_key UNIQUE (name);


--
-- Name: master_group master_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_group
    ADD CONSTRAINT master_group_pkey PRIMARY KEY (id);


--
-- Name: master_group_rule_access master_group_rule_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_group_rule_access
    ADD CONSTRAINT master_group_rule_access_pkey PRIMARY KEY (master_group_id, rule_id);


--
-- Name: master_group_scenario_access master_group_scenario_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_group_scenario_access
    ADD CONSTRAINT master_group_scenario_access_pkey PRIMARY KEY (master_group_id, scenario_id);


--
-- Name: player_action player_action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_action
    ADD CONSTRAINT player_action_pkey PRIMARY KEY (id);


--
-- Name: player player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_pkey PRIMARY KEY (id);


--
-- Name: user_master_group user_master_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_master_group
    ADD CONSTRAINT user_master_group_pkey PRIMARY KEY (user_id, master_group_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user user_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_telegram_id_key UNIQUE (telegram_id);


--
-- Name: rule_character_template rule_character_template_pkey; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_character_template
    ADD CONSTRAINT rule_character_template_pkey PRIMARY KEY (id);


--
-- Name: rule_item_contained_template rule_item_contained_template_pkey; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_contained_template
    ADD CONSTRAINT rule_item_contained_template_pkey PRIMARY KEY (id);


--
-- Name: rule_item_ownership_template rule_item_ownership_template_pkey; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_ownership_template
    ADD CONSTRAINT rule_item_ownership_template_pkey PRIMARY KEY (id);


--
-- Name: rule_item_template rule_item_template_pkey; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_template
    ADD CONSTRAINT rule_item_template_pkey PRIMARY KEY (id);


--
-- Name: rule_npc_template rule_npc_template_pkey; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_npc_template
    ADD CONSTRAINT rule_npc_template_pkey PRIMARY KEY (id);


--
-- Name: rule_template_set rule_template_set_pkey; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_template_set
    ADD CONSTRAINT rule_template_set_pkey PRIMARY KEY (id);


--
-- Name: scenario_template_set_link scenario_template_set_link_pkey; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.scenario_template_set_link
    ADD CONSTRAINT scenario_template_set_link_pkey PRIMARY KEY (id);


--
-- Name: tag tag_pkey; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (id);


--
-- Name: rule_item_contained_template uq_rule_item_contained_pair; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_contained_template
    ADD CONSTRAINT uq_rule_item_contained_pair UNIQUE (owner_item_template_id, item_template_id);


--
-- Name: scenario_template_set_link uq_scenario_template_set_link; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.scenario_template_set_link
    ADD CONSTRAINT uq_scenario_template_set_link UNIQUE (scenario_id, template_set_id);


--
-- Name: tag uq_tag_code; Type: CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.tag
    ADD CONSTRAINT uq_tag_code UNIQUE (code, entity_type);


--
-- Name: where_object _npc_location_uc; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.where_object
    ADD CONSTRAINT _npc_location_uc UNIQUE (npc_id, location_id);


--
-- Name: counter counter_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.counter
    ADD CONSTRAINT counter_pkey PRIMARY KEY (id);


--
-- Name: game_item game_item_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.game_item
    ADD CONSTRAINT game_item_pkey PRIMARY KEY (id);


--
-- Name: game_time_event game_time_event_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.game_time_event
    ADD CONSTRAINT game_time_event_pkey PRIMARY KEY (id);


--
-- Name: item_ownership item_ownership_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.item_ownership
    ADD CONSTRAINT item_ownership_pkey PRIMARY KEY (id);


--
-- Name: location location_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.location
    ADD CONSTRAINT location_pkey PRIMARY KEY (id);


--
-- Name: map_object_polygon map_object_polygon_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.map_object_polygon
    ADD CONSTRAINT map_object_polygon_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: npc npc_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.npc
    ADD CONSTRAINT npc_pkey PRIMARY KEY (id);


--
-- Name: obstacle obstacle_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.obstacle
    ADD CONSTRAINT obstacle_pkey PRIMARY KEY (id);


--
-- Name: player_action player_action_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.player_action
    ADD CONSTRAINT player_action_pkey PRIMARY KEY (id);


--
-- Name: player_character player_character_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.player_character
    ADD CONSTRAINT player_character_pkey PRIMARY KEY (id);


--
-- Name: requirement requirement_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.requirement
    ADD CONSTRAINT requirement_pkey PRIMARY KEY (id);


--
-- Name: scenario scenario_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scenario
    ADD CONSTRAINT scenario_pkey PRIMARY KEY (id);


--
-- Name: scenario_template_set_link scenario_template_set_link_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scenario_template_set_link
    ADD CONSTRAINT scenario_template_set_link_pkey PRIMARY KEY (id);


--
-- Name: scene_exposure_item scene_exposure_item_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure_item
    ADD CONSTRAINT scene_exposure_item_pkey PRIMARY KEY (scene_exposure_id, item_id);


--
-- Name: scene_exposure_npc scene_exposure_npc_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure_npc
    ADD CONSTRAINT scene_exposure_npc_pkey PRIMARY KEY (scene_exposure_id, npc_id);


--
-- Name: scene_exposure_obstacle scene_exposure_obstacle_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure_obstacle
    ADD CONSTRAINT scene_exposure_obstacle_pkey PRIMARY KEY (scene_exposure_id, obstacle_id);


--
-- Name: scene_exposure scene_exposure_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure
    ADD CONSTRAINT scene_exposure_pkey PRIMARY KEY (id);


--
-- Name: story_beat_location story_beat_location_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.story_beat_location
    ADD CONSTRAINT story_beat_location_pkey PRIMARY KEY (story_beat_id, location_id);


--
-- Name: story_beat_npc story_beat_npc_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.story_beat_npc
    ADD CONSTRAINT story_beat_npc_pkey PRIMARY KEY (story_beat_id, npc_id);


--
-- Name: story_beat story_beat_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.story_beat
    ADD CONSTRAINT story_beat_pkey PRIMARY KEY (id);


--
-- Name: unique_body unique_body_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.unique_body
    ADD CONSTRAINT unique_body_pkey PRIMARY KEY (id);


--
-- Name: unique_stat unique_stat_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.unique_stat
    ADD CONSTRAINT unique_stat_pkey PRIMARY KEY (id);


--
-- Name: character_tag uq_character_tag; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.character_tag
    ADD CONSTRAINT uq_character_tag PRIMARY KEY (character_id, tag_id);


--
-- Name: item_ownership uq_item_ownership_item; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.item_ownership
    ADD CONSTRAINT uq_item_ownership_item UNIQUE (item_id);


--
-- Name: item_tag uq_item_tag; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.item_tag
    ADD CONSTRAINT uq_item_tag PRIMARY KEY (item_id, tag_id);


--
-- Name: location_tag uq_location_tag; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.location_tag
    ADD CONSTRAINT uq_location_tag PRIMARY KEY (location_id, tag_id);


--
-- Name: npc_tag uq_npc_tag; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.npc_tag
    ADD CONSTRAINT uq_npc_tag PRIMARY KEY (npc_id, tag_id);


--
-- Name: scenario_template_set_link uq_scenario_template_set_link; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scenario_template_set_link
    ADD CONSTRAINT uq_scenario_template_set_link UNIQUE (scenario_id, template_set_id);


--
-- Name: where_object where_object_pkey; Type: CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.where_object
    ADD CONSTRAINT where_object_pkey PRIMARY KEY (id);


--
-- Name: ix_on_use_item_id; Type: INDEX; Schema: common; Owner: postgres
--

CREATE INDEX ix_on_use_item_id ON common.on_use_item USING btree (id);


--
-- Name: ix_game_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_game_session_id ON public.game_session USING btree (id);


--
-- Name: ix_game_session_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_game_session_name ON public.game_session USING btree (name);


--
-- Name: ix_player_action_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_action_id ON public.player_action USING btree (id);


--
-- Name: ix_player_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_player_id ON public.player USING btree (id);


--
-- Name: ix_user_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_user_email ON public."user" USING btree (email);


--
-- Name: ix_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_id ON public."user" USING btree (id);


--
-- Name: ix_user_tg; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_user_tg ON public."user" USING btree (tg);


--
-- Name: ix_rule_rule_character_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_character_template_id ON rule.rule_character_template USING btree (id);


--
-- Name: ix_rule_rule_character_template_template_set_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_character_template_template_set_id ON rule.rule_character_template USING btree (template_set_id);


--
-- Name: ix_rule_rule_item_contained_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_item_contained_template_id ON rule.rule_item_contained_template USING btree (id);


--
-- Name: ix_rule_rule_item_contained_template_item_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_item_contained_template_item_template_id ON rule.rule_item_contained_template USING btree (item_template_id);


--
-- Name: ix_rule_rule_item_contained_template_owner_item_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_item_contained_template_owner_item_template_id ON rule.rule_item_contained_template USING btree (owner_item_template_id);


--
-- Name: ix_rule_rule_item_ownership_template_character_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_item_ownership_template_character_template_id ON rule.rule_item_ownership_template USING btree (character_template_id);


--
-- Name: ix_rule_rule_item_ownership_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_item_ownership_template_id ON rule.rule_item_ownership_template USING btree (id);


--
-- Name: ix_rule_rule_item_ownership_template_item_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_item_ownership_template_item_template_id ON rule.rule_item_ownership_template USING btree (item_template_id);


--
-- Name: ix_rule_rule_item_ownership_template_npc_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_item_ownership_template_npc_template_id ON rule.rule_item_ownership_template USING btree (npc_template_id);


--
-- Name: ix_rule_rule_item_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_item_template_id ON rule.rule_item_template USING btree (id);


--
-- Name: ix_rule_rule_item_template_template_set_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_item_template_template_set_id ON rule.rule_item_template USING btree (template_set_id);


--
-- Name: ix_rule_rule_npc_template_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_npc_template_id ON rule.rule_npc_template USING btree (id);


--
-- Name: ix_rule_rule_npc_template_template_set_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_npc_template_template_set_id ON rule.rule_npc_template USING btree (template_set_id);


--
-- Name: ix_rule_rule_template_set_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_template_set_id ON rule.rule_template_set USING btree (id);


--
-- Name: ix_rule_rule_template_set_rule_id_str; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_template_set_rule_id_str ON rule.rule_template_set USING btree (rule_id_str);


--
-- Name: ix_rule_rule_template_set_scenario_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_rule_template_set_scenario_id ON rule.rule_template_set USING btree (scenario_id);


--
-- Name: ix_rule_scenario_template_set_link_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_scenario_template_set_link_id ON rule.scenario_template_set_link USING btree (id);


--
-- Name: ix_rule_scenario_template_set_link_scenario_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_scenario_template_set_link_scenario_id ON rule.scenario_template_set_link USING btree (scenario_id);


--
-- Name: ix_rule_scenario_template_set_link_template_set_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_scenario_template_set_link_template_set_id ON rule.scenario_template_set_link USING btree (template_set_id);


--
-- Name: ix_rule_tag_id; Type: INDEX; Schema: rule; Owner: postgres
--

CREATE INDEX ix_rule_tag_id ON rule.tag USING btree (id);


--
-- Name: ix_game_item_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_game_item_id ON scenario.game_item USING btree (id);


--
-- Name: ix_game_time_event_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_game_time_event_id ON scenario.game_time_event USING btree (id);


--
-- Name: ix_location_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_location_id ON scenario.location USING btree (id);


--
-- Name: ix_map_object_polygon_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_map_object_polygon_id ON scenario.map_object_polygon USING btree (id);


--
-- Name: ix_note_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_note_id ON scenario.note USING btree (id);


--
-- Name: ix_npc_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_npc_id ON scenario.npc USING btree (id);


--
-- Name: ix_player_action_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_player_action_id ON scenario.player_action USING btree (id);


--
-- Name: ix_player_character_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_player_character_id ON scenario.player_character USING btree (id);


--
-- Name: ix_scenario_counter_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_counter_id ON scenario.counter USING btree (id);


--
-- Name: ix_scenario_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_id ON scenario.scenario USING btree (id);


--
-- Name: ix_scenario_item_ownership_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_item_ownership_id ON scenario.item_ownership USING btree (id);


--
-- Name: ix_scenario_obstacle_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_obstacle_id ON scenario.obstacle USING btree (id);


--
-- Name: ix_scenario_obstacle_scenario_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_obstacle_scenario_id ON scenario.obstacle USING btree (scenario_id);


--
-- Name: ix_scenario_scenario_template_set_link_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_scenario_template_set_link_id ON scenario.scenario_template_set_link USING btree (id);


--
-- Name: ix_scenario_scenario_template_set_link_scenario_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_scenario_template_set_link_scenario_id ON scenario.scenario_template_set_link USING btree (scenario_id);


--
-- Name: ix_scenario_scenario_template_set_link_template_set_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_scenario_template_set_link_template_set_id ON scenario.scenario_template_set_link USING btree (template_set_id);


--
-- Name: ix_scenario_scene_exposure_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_scene_exposure_id ON scenario.scene_exposure USING btree (id);


--
-- Name: ix_scenario_scene_exposure_location_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_scene_exposure_location_id ON scenario.scene_exposure USING btree (location_id);


--
-- Name: ix_scenario_scene_exposure_scenario_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_scene_exposure_scenario_id ON scenario.scene_exposure USING btree (scenario_id);


--
-- Name: ix_scenario_scene_exposure_story_beat_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_scene_exposure_story_beat_id ON scenario.scene_exposure USING btree (story_beat_id);


--
-- Name: ix_scenario_story_beat_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_story_beat_id ON scenario.story_beat USING btree (id);


--
-- Name: ix_scenario_story_beat_parent_story_beat_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_story_beat_parent_story_beat_id ON scenario.story_beat USING btree (parent_story_beat_id);


--
-- Name: ix_scenario_story_beat_scenario_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_story_beat_scenario_id ON scenario.story_beat USING btree (scenario_id);


--
-- Name: ix_scenario_unique_body_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_unique_body_id ON scenario.unique_body USING btree (id);


--
-- Name: ix_scenario_unique_stat_id; Type: INDEX; Schema: scenario; Owner: postgres
--

CREATE INDEX ix_scenario_unique_stat_id ON scenario.unique_stat USING btree (id);


--
-- Name: on_use_item on_use_item_item_id_fkey; Type: FK CONSTRAINT; Schema: common; Owner: postgres
--

ALTER TABLE ONLY common.on_use_item
    ADD CONSTRAINT on_use_item_item_id_fkey FOREIGN KEY (item_id) REFERENCES scenario.game_item(id);


--
-- Name: game_session game_session_master_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.game_session
    ADD CONSTRAINT game_session_master_id_fkey FOREIGN KEY (master_id) REFERENCES public."user"(id);


--
-- Name: game_session game_session_scenario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.game_session
    ADD CONSTRAINT game_session_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id);


--
-- Name: master_group_rule_access master_group_rule_access_master_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_group_rule_access
    ADD CONSTRAINT master_group_rule_access_master_group_id_fkey FOREIGN KEY (master_group_id) REFERENCES public.master_group(id);


--
-- Name: master_group_scenario_access master_group_scenario_access_master_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_group_scenario_access
    ADD CONSTRAINT master_group_scenario_access_master_group_id_fkey FOREIGN KEY (master_group_id) REFERENCES public.master_group(id);


--
-- Name: master_group_scenario_access master_group_scenario_access_scenario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.master_group_scenario_access
    ADD CONSTRAINT master_group_scenario_access_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id);


--
-- Name: player_action player_action_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_action
    ADD CONSTRAINT player_action_item_id_fkey FOREIGN KEY (item_id) REFERENCES scenario.game_item(id);


--
-- Name: player_action player_action_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_action
    ADD CONSTRAINT player_action_location_id_fkey FOREIGN KEY (location_id) REFERENCES scenario.location(id);


--
-- Name: player_action player_action_npc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_action
    ADD CONSTRAINT player_action_npc_id_fkey FOREIGN KEY (npc_id) REFERENCES scenario.npc(id);


--
-- Name: player_action player_action_triggers_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_action
    ADD CONSTRAINT player_action_triggers_note_id_fkey FOREIGN KEY (triggers_note_id) REFERENCES scenario.note(id);


--
-- Name: player player_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_character_id_fkey FOREIGN KEY (character_id) REFERENCES scenario.player_character(id);


--
-- Name: player player_game_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_game_session_id_fkey FOREIGN KEY (game_session_id) REFERENCES public.game_session(id) ON DELETE CASCADE;


--
-- Name: player player_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_master_group user_master_group_master_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_master_group
    ADD CONSTRAINT user_master_group_master_group_id_fkey FOREIGN KEY (master_group_id) REFERENCES public.master_group(id);


--
-- Name: user_master_group user_master_group_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_master_group
    ADD CONSTRAINT user_master_group_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: rule_character_template rule_character_template_template_set_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_character_template
    ADD CONSTRAINT rule_character_template_template_set_id_fkey FOREIGN KEY (template_set_id) REFERENCES rule.rule_template_set(id) ON DELETE CASCADE;


--
-- Name: rule_item_contained_template rule_item_contained_template_item_template_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_contained_template
    ADD CONSTRAINT rule_item_contained_template_item_template_id_fkey FOREIGN KEY (item_template_id) REFERENCES rule.rule_item_template(id) ON DELETE CASCADE;


--
-- Name: rule_item_contained_template rule_item_contained_template_owner_item_template_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_contained_template
    ADD CONSTRAINT rule_item_contained_template_owner_item_template_id_fkey FOREIGN KEY (owner_item_template_id) REFERENCES rule.rule_item_template(id) ON DELETE CASCADE;


--
-- Name: rule_item_ownership_template rule_item_ownership_template_character_template_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_ownership_template
    ADD CONSTRAINT rule_item_ownership_template_character_template_id_fkey FOREIGN KEY (character_template_id) REFERENCES rule.rule_character_template(id) ON DELETE CASCADE;


--
-- Name: rule_item_ownership_template rule_item_ownership_template_item_template_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_ownership_template
    ADD CONSTRAINT rule_item_ownership_template_item_template_id_fkey FOREIGN KEY (item_template_id) REFERENCES rule.rule_item_template(id) ON DELETE CASCADE;


--
-- Name: rule_item_ownership_template rule_item_ownership_template_npc_template_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_ownership_template
    ADD CONSTRAINT rule_item_ownership_template_npc_template_id_fkey FOREIGN KEY (npc_template_id) REFERENCES rule.rule_npc_template(id) ON DELETE CASCADE;


--
-- Name: rule_item_template rule_item_template_template_set_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_item_template
    ADD CONSTRAINT rule_item_template_template_set_id_fkey FOREIGN KEY (template_set_id) REFERENCES rule.rule_template_set(id) ON DELETE CASCADE;


--
-- Name: rule_npc_template rule_npc_template_template_set_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_npc_template
    ADD CONSTRAINT rule_npc_template_template_set_id_fkey FOREIGN KEY (template_set_id) REFERENCES rule.rule_template_set(id) ON DELETE CASCADE;


--
-- Name: rule_template_set rule_template_set_scenario_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.rule_template_set
    ADD CONSTRAINT rule_template_set_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id) ON DELETE CASCADE;


--
-- Name: scenario_template_set_link scenario_template_set_link_scenario_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.scenario_template_set_link
    ADD CONSTRAINT scenario_template_set_link_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id) ON DELETE CASCADE;


--
-- Name: scenario_template_set_link scenario_template_set_link_template_set_id_fkey; Type: FK CONSTRAINT; Schema: rule; Owner: postgres
--

ALTER TABLE ONLY rule.scenario_template_set_link
    ADD CONSTRAINT scenario_template_set_link_template_set_id_fkey FOREIGN KEY (template_set_id) REFERENCES rule.rule_template_set(id) ON DELETE CASCADE;


--
-- Name: character_tag character_tag_character_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.character_tag
    ADD CONSTRAINT character_tag_character_id_fkey FOREIGN KEY (character_id) REFERENCES scenario.player_character(id) ON DELETE CASCADE;


--
-- Name: counter counter_character_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.counter
    ADD CONSTRAINT counter_character_id_fkey FOREIGN KEY (character_id) REFERENCES scenario.player_character(id) ON DELETE CASCADE;


--
-- Name: counter counter_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.counter
    ADD CONSTRAINT counter_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id) ON DELETE CASCADE;


--
-- Name: game_item game_item_character_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.game_item
    ADD CONSTRAINT game_item_character_id_fkey FOREIGN KEY (character_id) REFERENCES scenario.player_character(id);


--
-- Name: game_item game_item_location_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.game_item
    ADD CONSTRAINT game_item_location_id_fkey FOREIGN KEY (location_id) REFERENCES scenario.location(id);


--
-- Name: game_item game_item_npc_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.game_item
    ADD CONSTRAINT game_item_npc_id_fkey FOREIGN KEY (npc_id) REFERENCES scenario.npc(id);


--
-- Name: game_item game_item_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.game_item
    ADD CONSTRAINT game_item_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id);


--
-- Name: game_time_event game_time_event_note_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.game_time_event
    ADD CONSTRAINT game_time_event_note_id_fkey FOREIGN KEY (note_id) REFERENCES scenario.note(id);


--
-- Name: game_time_event game_time_event_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.game_time_event
    ADD CONSTRAINT game_time_event_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id);


--
-- Name: item_ownership item_ownership_character_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.item_ownership
    ADD CONSTRAINT item_ownership_character_id_fkey FOREIGN KEY (character_id) REFERENCES scenario.player_character(id) ON DELETE CASCADE;


--
-- Name: item_ownership item_ownership_item_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.item_ownership
    ADD CONSTRAINT item_ownership_item_id_fkey FOREIGN KEY (item_id) REFERENCES scenario.game_item(id) ON DELETE CASCADE;


--
-- Name: item_ownership item_ownership_npc_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.item_ownership
    ADD CONSTRAINT item_ownership_npc_id_fkey FOREIGN KEY (npc_id) REFERENCES scenario.npc(id) ON DELETE CASCADE;


--
-- Name: item_ownership item_ownership_owner_item_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.item_ownership
    ADD CONSTRAINT item_ownership_owner_item_id_fkey FOREIGN KEY (owner_item_id) REFERENCES scenario.game_item(id) ON DELETE CASCADE;


--
-- Name: item_tag item_tag_item_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.item_tag
    ADD CONSTRAINT item_tag_item_id_fkey FOREIGN KEY (item_id) REFERENCES scenario.game_item(id) ON DELETE CASCADE;


--
-- Name: location location_parent_location_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.location
    ADD CONSTRAINT location_parent_location_id_fkey FOREIGN KEY (parent_location_id) REFERENCES scenario.location(id);


--
-- Name: location location_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.location
    ADD CONSTRAINT location_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id);


--
-- Name: location_tag location_tag_location_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.location_tag
    ADD CONSTRAINT location_tag_location_id_fkey FOREIGN KEY (location_id) REFERENCES scenario.location(id) ON DELETE CASCADE;


--
-- Name: map_object_polygon map_object_polygon_source_location_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.map_object_polygon
    ADD CONSTRAINT map_object_polygon_source_location_id_fkey FOREIGN KEY (source_location_id) REFERENCES scenario.location(id);


--
-- Name: map_object_polygon map_object_polygon_target_location_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.map_object_polygon
    ADD CONSTRAINT map_object_polygon_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES scenario.location(id);


--
-- Name: note note_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.note
    ADD CONSTRAINT note_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id);


--
-- Name: npc npc_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.npc
    ADD CONSTRAINT npc_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id);


--
-- Name: npc_tag npc_tag_npc_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.npc_tag
    ADD CONSTRAINT npc_tag_npc_id_fkey FOREIGN KEY (npc_id) REFERENCES scenario.npc(id) ON DELETE CASCADE;


--
-- Name: obstacle obstacle_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.obstacle
    ADD CONSTRAINT obstacle_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id) ON DELETE CASCADE;


--
-- Name: player_action player_action_item_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.player_action
    ADD CONSTRAINT player_action_item_id_fkey FOREIGN KEY (item_id) REFERENCES scenario.game_item(id);


--
-- Name: player_action player_action_location_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.player_action
    ADD CONSTRAINT player_action_location_id_fkey FOREIGN KEY (location_id) REFERENCES scenario.location(id);


--
-- Name: player_action player_action_npc_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.player_action
    ADD CONSTRAINT player_action_npc_id_fkey FOREIGN KEY (npc_id) REFERENCES scenario.npc(id);


--
-- Name: player_action player_action_riggers_note_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.player_action
    ADD CONSTRAINT player_action_riggers_note_id_fkey FOREIGN KEY (triggers_note_id) REFERENCES scenario.note(id);


--
-- Name: player_character player_character_location_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.player_character
    ADD CONSTRAINT player_character_location_id_fkey FOREIGN KEY (location_id) REFERENCES scenario.location(id);


--
-- Name: player_character player_character_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.player_character
    ADD CONSTRAINT player_character_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id);


--
-- Name: requirement requirement_action_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.requirement
    ADD CONSTRAINT requirement_action_id_fkey FOREIGN KEY (action_id) REFERENCES scenario.player_action(id) ON DELETE CASCADE;


--
-- Name: scenario_template_set_link scenario_template_set_link_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scenario_template_set_link
    ADD CONSTRAINT scenario_template_set_link_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id) ON DELETE CASCADE;


--
-- Name: scenario_template_set_link scenario_template_set_link_template_set_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scenario_template_set_link
    ADD CONSTRAINT scenario_template_set_link_template_set_id_fkey FOREIGN KEY (template_set_id) REFERENCES rule.rule_template_set(id) ON DELETE CASCADE;


--
-- Name: scenario scenario_user_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scenario
    ADD CONSTRAINT scenario_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: scene_exposure_item scene_exposure_item_item_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure_item
    ADD CONSTRAINT scene_exposure_item_item_id_fkey FOREIGN KEY (item_id) REFERENCES scenario.game_item(id) ON DELETE CASCADE;


--
-- Name: scene_exposure_item scene_exposure_item_scene_exposure_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure_item
    ADD CONSTRAINT scene_exposure_item_scene_exposure_id_fkey FOREIGN KEY (scene_exposure_id) REFERENCES scenario.scene_exposure(id) ON DELETE CASCADE;


--
-- Name: scene_exposure scene_exposure_location_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure
    ADD CONSTRAINT scene_exposure_location_id_fkey FOREIGN KEY (location_id) REFERENCES scenario.location(id) ON DELETE CASCADE;


--
-- Name: scene_exposure_npc scene_exposure_npc_npc_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure_npc
    ADD CONSTRAINT scene_exposure_npc_npc_id_fkey FOREIGN KEY (npc_id) REFERENCES scenario.npc(id) ON DELETE CASCADE;


--
-- Name: scene_exposure_npc scene_exposure_npc_scene_exposure_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure_npc
    ADD CONSTRAINT scene_exposure_npc_scene_exposure_id_fkey FOREIGN KEY (scene_exposure_id) REFERENCES scenario.scene_exposure(id) ON DELETE CASCADE;


--
-- Name: scene_exposure_obstacle scene_exposure_obstacle_obstacle_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure_obstacle
    ADD CONSTRAINT scene_exposure_obstacle_obstacle_id_fkey FOREIGN KEY (obstacle_id) REFERENCES scenario.obstacle(id) ON DELETE CASCADE;


--
-- Name: scene_exposure_obstacle scene_exposure_obstacle_scene_exposure_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure_obstacle
    ADD CONSTRAINT scene_exposure_obstacle_scene_exposure_id_fkey FOREIGN KEY (scene_exposure_id) REFERENCES scenario.scene_exposure(id) ON DELETE CASCADE;


--
-- Name: scene_exposure scene_exposure_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure
    ADD CONSTRAINT scene_exposure_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id) ON DELETE CASCADE;


--
-- Name: scene_exposure scene_exposure_story_beat_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.scene_exposure
    ADD CONSTRAINT scene_exposure_story_beat_id_fkey FOREIGN KEY (story_beat_id) REFERENCES scenario.story_beat(id) ON DELETE CASCADE;


--
-- Name: story_beat_location story_beat_location_location_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.story_beat_location
    ADD CONSTRAINT story_beat_location_location_id_fkey FOREIGN KEY (location_id) REFERENCES scenario.location(id) ON DELETE CASCADE;


--
-- Name: story_beat_location story_beat_location_story_beat_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.story_beat_location
    ADD CONSTRAINT story_beat_location_story_beat_id_fkey FOREIGN KEY (story_beat_id) REFERENCES scenario.story_beat(id) ON DELETE CASCADE;


--
-- Name: story_beat_npc story_beat_npc_npc_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.story_beat_npc
    ADD CONSTRAINT story_beat_npc_npc_id_fkey FOREIGN KEY (npc_id) REFERENCES scenario.npc(id) ON DELETE CASCADE;


--
-- Name: story_beat_npc story_beat_npc_story_beat_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.story_beat_npc
    ADD CONSTRAINT story_beat_npc_story_beat_id_fkey FOREIGN KEY (story_beat_id) REFERENCES scenario.story_beat(id) ON DELETE CASCADE;


--
-- Name: story_beat story_beat_parent_story_beat_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.story_beat
    ADD CONSTRAINT story_beat_parent_story_beat_id_fkey FOREIGN KEY (parent_story_beat_id) REFERENCES scenario.story_beat(id);


--
-- Name: story_beat story_beat_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.story_beat
    ADD CONSTRAINT story_beat_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id) ON DELETE CASCADE;


--
-- Name: unique_body unique_body_scenario_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.unique_body
    ADD CONSTRAINT unique_body_scenario_id_fkey FOREIGN KEY (scenario_id) REFERENCES scenario.scenario(id) ON DELETE CASCADE;


--
-- Name: unique_stat unique_stat_body_id_fkey; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.unique_stat
    ADD CONSTRAINT unique_stat_body_id_fkey FOREIGN KEY (body_id) REFERENCES scenario.unique_body(id) ON DELETE CASCADE;


--
-- Name: where_object where_object_location_id_fkey1; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.where_object
    ADD CONSTRAINT where_object_location_id_fkey1 FOREIGN KEY (location_id) REFERENCES scenario.location(id) ON DELETE CASCADE;


--
-- Name: where_object where_object_npc_id_fkey1; Type: FK CONSTRAINT; Schema: scenario; Owner: postgres
--

ALTER TABLE ONLY scenario.where_object
    ADD CONSTRAINT where_object_npc_id_fkey1 FOREIGN KEY (npc_id) REFERENCES scenario.npc(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict e5Fvrhllsog5z4zcdbV8Tzc95hHfNFNxGbZNJoJouEtyuDJinI8p0mYLhGOhPmy

